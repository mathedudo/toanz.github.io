var c, ctx;
function missingValuesUsingTheMean() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = true;
    var item = itemPicker("small");
    var totalMean, meanPerPacket, meanPerBox;
    while (totalMean != Math.round(totalMean) || meanPerPacket == meanPerBox) {
        var packets = getRandom(5, 25);
        var boxes = getRandom(5, 25);
        meanPerPacket = getRandom(5, 30);
        meanPerBox = getRandom(5, 30);
        var totalInPackets = packets * meanPerPacket;
        var totalInBoxes = boxes * meanPerBox;
        var total = totalInPackets + totalInBoxes;
        totalMean = total / (packets + boxes);
    }
    problem.question = "<p>There are " + packets + " packets of " + item + "s and " + boxes + " boxes of " + item + "s in a delivery parcel.</p>";
    problem.question += "<p>The mean number of " + item + "s in all the packets and boxes is " + totalMean + ".</p>";
    problem.question += "<p>The mean number of " + item + "s in all the packets is " + meanPerPacket + ".</p>";
    problem.question += "<p>Work out the mean number of " + item + "s in the boxes.";
    problem.answer = "<p>Total " + item + "s = " + totalMean + " &#215; (" + packets + " + " + boxes + ") = " + total + "</p>";
    problem.answer += "<p>Total " + item + "s in packets = " + meanPerPacket + " &#215; " + packets + " = " + totalInPackets + "</p>";
    problem.answer += "<p>Total " + item + "s in boxes = " + total + " - " + totalInPackets + " = " + totalInBoxes + "</p>";
    problem.answer += "<p>Mean " + item + "s per box = " + totalInBoxes + " &divide; " + boxes + " = " + meanPerBox + "</p>";
    return problem;
}
function repeatedPercentageChange() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = true;
    var person = namePicker();
    var original = 1000 * getRandom(4, 40);
    var percentage = 5 * getRandom(1, 4);
    var time = getRandom(2, 5);
    var newValue = Math.round(original * Math.pow((100 - percentage) / 100, time));
    problem.question = "<p>" + person.name + " buys a car for &pound;" + original + ".</p>";
    problem.question += "<p>The value of the car depreciates by " + percentage + "% each year.</p>";
    problem.question += "<p>Work out the value of the car after " + time + " years.</p>"
    problem.answer = "<p>" + original + " &#215; " + (100 - percentage) / 100 + "<sup>" + time + "</sup> = &pound;" + newValue + "</p>";
    return problem;
}
function tangentsToCircles() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = false;
    var p, m;
    while (Math.round(10 * p) / 10 != p || Math.round(10 * m) / 10 != m) {
        var x = getRandom(1, 8);
        var y = getRandom(1, 8);
        if (Math.random() < 0.3) {
            x = -x;
        }
        if (Math.random() < 0.3) {
            y = -y;
        }
        var radiusSquared = x * x + y * y;
        m = y / x;
        p = -1 / m;
    }
    var c = y - (p * x);
    problem.question = "<p>The line L is a tangent to the circle x<sup>2</sup> + y<sup>2</sup> = " + radiusSquared;
    problem.question += " at the point (" + x + ", " + y + ").</p>";
    problem.question += "<p>Line L crosses the x-axis at the point P.</p>";
    problem.question += "<p>Work out the coordinates of P.";
    problem.answer = "<p>Gradient from origin to point (" + x + ", " + y + ") is " + y + " &divide; " + x + " = " + m + ".</p>";
    problem.answer += "<p>Gradient of L is -1 &divide; " + m + " = " + p + ".</p>";
    problem.answer += "<p>Equation of L is of the form y = " + p + "x + c.</p>";
    problem.answer += "<p>Substituting in (" + x + ", " + y + ") gives c = " + c + ".</p>";
    problem.answer += "<p>Equation of L is y = " + p + "x + " + c + ".</p>";
    problem.answer += "<p>When y = 0, x = " + (-c / p) + " so P is the point (" + (-c / p) + ", 0).</p>";
    return problem;
}
function bestValue() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = true;
    var option1 = new Object;
    option1.unitPrice = getRandom(20, 50) / 100;
    option1.quantity = 4 * getRandom(1, 5);
    option1.cost = roundError(option1.unitPrice * option1.quantity);
    var option2 = new Object;
    option2.unitPrice = option1.unitPrice + (getRandom(-6, 6) / 100);
    if (option2.unitPrice == option1.unitPrice) {
        option2.unitPrice++;
    }
    option2.quantity = 9 * getRandom(1, 3);
    option2.cost = roundError(option2.unitPrice * option2.quantity);
    problem.question = "<p>A pack of " + option1.quantity + " toilet rolls costs &pound;" + option1.cost.toFixed(2) + ".</p>";
    problem.question += "<p>A pack of " + option2.quantity + " toilet rolls costs &pound;" + option2.cost.toFixed(2) + ".</p>";
    problem.question += "<p>Which pack gives the better value for money?</p>";
    problem.question += "<p>Show how you decide.</p>";
    problem.answer = "<p>The first option costs &pound;" + option1.cost.toFixed(2) + " &divide; " + option1.quantity + " = &pound;" + option1.unitPrice.toFixed(2) + " per roll.</p>";
    problem.answer += "<p>The second option costs &pound;" + option2.cost.toFixed(2) + " &divide; " + option2.quantity + " = &pound;" + option2.unitPrice.toFixed(2) + " per roll.</p>";
    if (option1.unitPrice < option2.unitPrice) {
        problem.answer += "<p>The pack of " + option1.quantity + " is the best value for money.</p>";
    } else {
        problem.answer += "<p>The pack of " + option2.quantity + " is the best value for money.</p>";
    }
    if (option1.unitPrice < option2.unitPrice) {

    }
    return problem;
}
function sumProductDifference() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = false;
    var limit = "largest";
    if (Math.random() < 0.5) {
        limit = "smallest";
    }
    var a, b, c, d, e, f;
    a = getRandom(10, 20);
    b = getRandom(10, 20);
    c = getRandom(3, 9);
    d = getRandom(3, 9);
    e = getRandom(50, 100);
    f = e - getRandom(10, 30);
    problem.question = "<p>Which of these calculations has the " + limit + " answer?";
    problem.question += "<p>The sum of " + a + " and " + b + ".</p>";
    problem.question += "<p>The product of " + c + " and " + d + ".</p>";
    problem.question += "<p>The difference between " + e + " and " + f + ".</p>";
    problem.question += "<p>Show how you decide.</p>";
    problem.answer = "<p>" + a + " + " + b + " = " + (a + b) + "</p>";
    problem.answer += "<p>" + c + " &#215; " + d + " = " + (c * d) + "</p>";
    problem.answer += "<p>" + e + " - " + f + " = " + (e - f) + "</p>";
    if (limit == "largest") {
        problem.answer += "<p>" + Math.max(Math.max((a + b), (c * d)), (e - f)) + " is the " + limit + ".</p>";
    } else {
        problem.answer += "<p>" + Math.min(Math.min((a + b), (c * d)), (e - f)) + " is the " + limit + ".</p>";
    }

    return problem;
}
function factorSumProblem() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    var a = getRandom(3, 8);
    var b = getRandom(3, 8);
    while (a == b) {
        b = getRandom(3, 8);
    }
    var multiplier = getRandom(2, 3);
    var seed = a * b * multiplier;
    var sum = a + b;
    problem.question = "<p>Two numbers are added together to give " + sum + ".</p>";
    problem.question += "<p>Both of the numbers are factors of " + seed + ".</p>";
    problem.question += "<p>Both numbers are greater than 2.</p>";
    problem.question += "<p>What are the two numbers?</p>";
    problem.answer = "<p>" + a + " is a factor of " + seed + " since " + seed + " &divide; " + a + " = " + (seed / a) + ".</p>";
    problem.answer += "<p>" + b + " is a factor of " + seed + " since " + seed + " &divide; " + b + " = " + (seed / b) + ".</p>";
    problem.answer += "<p>" + a + " + " + b + " = " + sum + ".</p>";
    return problem;
}
function percentageDecrease() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    var price = 20 * getRandom(6, 20);
    var percentage = 5 + 10 * getRandom(1, 3);
    var deposit = price * percentage / 100;
    var person = namePicker();
    var item = itemPicker("large");
    problem.question = "<p>" + person.name + " is going to buy a new " + item + ".</p>";
    problem.question += "<p>The " + item + " has a price of &pound;" + price + ".</p>";
    problem.question += "<p>" + person.name + " pays a deposit of " + percentage + "% of the price of the " + item + ".</p>";
    problem.question += "<p>How much money does " + person.name + " pay as a deposit?</p>";
    problem.answer = "<p>10% of " + price + " = " + (price / 10) + ".</p>";
    problem.answer += "<p>5% of " + price + " = " + (price / 20) + ".</p>";
    problem.answer += "<p>" + percentage + "% of " + price + " = " + deposit + ".</p>";
    problem.answer += "<p>" + person.name + " pays a &pound;" + deposit + " deposit on the " + item + ".</p>";
    return problem;
}
function buyingCheese() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = false;
    var pricePerKilo = (10 * getRandom(21, 60)) / 100;
    var pricePer100g = pricePerKilo / 10;
    var amount = getRandom(2, 9);
    if (amount == 5) {
        amount++;
    }
    amount *= 100;
    var person = namePicker();
    problem.question = "<p>One kilogram of cheese costs &pound;" + pricePerKilo.toFixed(2) + ".</p>";
    problem.question += "<p>" + person.name + " buys " + amount + " g of cheese.</p>";
    problem.question += "<p>Work out how much " + person.name + " pays.</p>";
    problem.answer = "<p>1 kg = 1000g.</p>";
    problem.answer += "<p>100 g costs &pound;" + pricePerKilo.toFixed(2) + " &divide; " + " 10 =  &pound;" + pricePer100g.toFixed(2) + ".</p>";
    problem.answer += "<p>" + amount + " g costs &pound;" + pricePer100g.toFixed(2) + " &#215; " + amount / 100 + " = &pound;" + (pricePer100g * amount / 100).toFixed(2) + ".</p>"
    return problem;
}
function lengthOfStick() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    var a = getRandom(1, 15);
    var b = getRandom(1, 15);
    var c = getRandom(1, 15);
    var total = a + b + c;
    problem.question = "<img src='/media/gcseQuestions/9.jpg'>";
    problem.question += "<p>Here is a picture of a stick. The length of the stick is in 3 parts, A, B and C.</p>";
    problem.question += "<p>The total length of the stick is " + total + " cm.</p>";
    problem.question += "<p>Part A is " + a + " cm long and part B is " + b + " cm long.</p>";
    problem.question += "<p>Work out the length of part C.</p>";
    problem.answer = "<p>C = " + total + " - " + "(" + a + " + " + b + ")</p>";
    problem.answer += "<p>C = " + c + " cm.</p>";
    return problem;
}
function squareRectanglePerimeters() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F";
    problem.calc = false;
    var x = getRandom(1, 6);
    var y = getRandom(1, 6);
    while (x == y) {
        y = getRandom(1, 6);
    }
    var length = 2 * x;
    var width = 2 * y;
    var perimeter = 2 * (length + width);
    var squareSide = perimeter / 4;
    problem.question = "<p>The diagram shows a rectangle and a square.</p>";
    problem.question += "<img src='/media/gcseQuestions/10.jpg'>";
    problem.question += "<p>The rectangle is " + length + " cm long and " + width + " cm wide.</p>";
    problem.question += "<p>The perimeter of the rectangle is the same as the perimeter of the square.</p>";
    problem.question += "<p>Work out the length of one side of the square.</p>";
    problem.answer = "<p>Perimeter of rectangle is 2(" + length + " + " + width + ") = " + perimeter + " cm.</p>";
    problem.answer += "<p>Perimeter of square is also " + perimeter + " cm.</p>";
    problem.answer += "<p>Length of side of square is " + perimeter + " &divide; 4 = " + squareSide + " cm.</p>";
    return problem;
}
function findOriginalGivenHcfLcm() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "H";
    problem.calc = false;
    var x, y, multiple;
    multiple = getRandom(2, 7);
    x = multiple * getRandom(2, 5);
    y = multiple * getRandom(2, 5);
    while (y % x == 0 || x % y == 0) {
        y = multiple * getRandom(2, 5);
    }
    var hcf = HCF(x, y);
    var lcm = x * y / hcf;
    problem.question = "<p>x and y are two positive integers greater than " + hcf + ".</p>";
    problem.question += "<p>The highest common factor (HCF) of x and y is " + hcf + ".</p>";
    problem.question += "<p>The lowest common multiple (LCM) of x and y is " + lcm + ".</p>";
    problem.question += "<p>Find the value of x and y.</p>";
    problem.answer = "<p>" + x + " and " + y + ".</p>";
    return problem;
}
function readingFuel() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    var choice = getRandom(0, 2);
    var tankCapacity = 8 * getRandom(4, 12);
    var scale = new Array("3", "5", "7");
    var fraction = "<sup>" + scale[choice] + "</sup>/<sub>8</sub>";
    problem.question = "<p>A petrol tank holds " + tankCapacity + " litres of petrol when it is full.</p>";
    problem.question += "<img src='/media/gcseQuestions/12-" + choice + ".jpg'>";
    problem.question += "<p>The scale shows information about how much petrol there is in the petrol tank.</p>";
    problem.question += "<p>Work out the number of litres of petrol in the petrol tank.</p>";
    problem.answer = "<p>The tank is " + fraction + " full.</p>";
    problem.answer += "<p>" + fraction + " of " + tankCapacity + " = " + tankCapacity + " &divide; 8 &#215; " + scale[choice] + ".</p>";
    problem.answer += "<p>The tank has " + (tankCapacity / 8 * scale[choice]) + " litres of petrol remaining.</p>"
    return problem;
}
function gcse13() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F/H";
    problem.calc = true;
    var unitsPerHour = 2 * getRandom(10, 30);
    var hours = 0.5 + getRandom(5, 12);
    var days = getRandom(4, 6);
    var boxCapacity = 2 * getRandom(3, 8);
    var totalUnits = unitsPerHour * hours * days;
    var boxes = Math.round(1000 * totalUnits / boxCapacity) / 1000;
    problem.question = "A factory produces " + unitsPerHour + " units every hour.<p>";
    problem.question += "The factory makes units for " + hours + " hours each day, for " + days + " days per week.</p>";
    problem.question += "The units are packed into boxes. Each box holds " + boxCapacity + " units.</p>";
    problem.question += "How many boxes are needed for all the units made in a week?</p>";
    problem.answer = "Total units per week = " + unitsPerHour + " &#215; " + hours + " &#215; " + days + " = " + totalUnits + ".</p>";
    problem.answer += "Boxes needed = " + totalUnits + " &divide; " + boxCapacity + " = " + boxes + ".</p>";
    problem.answer += "<p>" + Math.ceil(boxes) + " boxes are needed.</p>";
    return problem;
}
function basicPythagoras() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = true;
    if (Math.random() < 0.5) {
        var units = "cm";
    } else {
        units = "m";
    }
    if (Math.random() < 0.5) {
        var findingHyp = true;
    } else {
        findingHyp = false;
    }
    var ac, ab, bc;
    problem.question = "<img src='/media/gcseQuestions/14-" + getRandom(0, 2) + ".jpg'>";
    problem.question += "<p>ABC is a right angled triangle.</p>";
    if (findingHyp) {
        ac = getRandom(2, 40) / 2;
        bc = getRandom(2, 40) / 2;
        ab = Math.round(10 * Math.sqrt((ac * ac) + (bc * bc))) / 10;
        problem.question += "<p>AC = " + ac + " " + units + " and BC = " + bc + " " + units + ".</p>";
        problem.question += "<p>Find the length of AB.</p>"
        problem.answer = "<p>By Pythagoras Theorem AB&sup2; = AC&sup2; + BC&sup2;.</p>";
        problem.answer += "<p>AB = &#8730;(" + ac + "&sup2; + " + bc + "&sup2;)</p>";
        problem.answer += "<p>AB = " + ab + " " + units + ".</p>";
    } else {
        ac = getRandom(2, 40) / 2;
        ab = ac + getRandom(2, 20) / 2;
        bc = Math.round(10 * Math.sqrt((ab * ab) - (ac * ac))) / 10;
        problem.question += "<p>AB = " + ab + " " + units + " and AC = " + ac + " " + units + ".</p>";
        problem.question += "<p>Find the length of BC.</p>"
        problem.answer = "<p>By Pythagoras Theorem BC&sup2; = AB&sup2; - AC&sup2;.</p>";
        problem.answer += "<p>BC = &#8730;(" + ab + "&sup2; - " + ac + "&sup2;)</p>";
        problem.answer += "<p>BC = " + bc + " " + units + ".</p>";
    }
    problem.question += "<p>Give your answer to 1 decimal place.</p>";
    return problem;
}
function gcse15() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F/H";
    problem.calc = true;
    var counter1 = {};
    var counter2 = {}
    counter1.colour = colourPicker();
    counter2.colour = colourPicker();
    while (counter1.colour == counter2.colour) {
        counter2.colour = colourPicker();
    }
    var total = 5 * getRandom(3, 8);
    counter1.quantity = getRandom(5, total - 5);
    counter2.quantity = total - counter1.quantity;
    var denominator = total * (total - 1);
    var c1c1 = counter1.quantity * (counter1.quantity - 1);
    var c1c2 = counter1.quantity * counter2.quantity;
    var c2c1 = counter2.quantity * counter1.quantity;
    var c2c2 = counter2.quantity * (counter2.quantity - 1);
    problem.question = "<p>There are " + total + " counters in a bag.</p>";
    problem.question += "<p>" + counter1.quantity + " of the counters are " + counter1.colour + ".</p>";
    problem.question += "<p>" + counter2.quantity + " of the counters are " + counter2.colour + ".</p>";
    problem.question += "<p>" + namePicker().name + " takes two of the counters at random.</p>";
    switch (getRandom(0, 2)) {
        case 0:
            problem.question += "<p>Work out the probability that the two counters are different colours.</p>";
            problem.answer = "<p>P(" + counter1.colour + " and " + counter2.colour + ") = <sup>" + counter1.quantity + "</sup>/<sub>" + total + "</sub> &#215; <sup>" + counter2.quantity + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c1c2 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(" + counter2.colour + " and " + counter1.colour + ") = <sup>" + counter2.quantity + "</sup> /<sub>" + total + "</sub> &#215; <sup>" + counter1.quantity + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c2c1 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(different colours) = <sup>" + (c1c2 + c2c1) + "</sup>/<sub>" + denominator + "</sub></p>";
            break;
        case 1:
            problem.question += "<p>Work out the probability that the two counters are the same colours.</p>";
            problem.answer = "<p>P(" + counter1.colour + " and " + counter1.colour + ") = <sup>" + counter1.quantity + "</sup>/<sub>" + total + "</sub> &#215; <sup>" + (counter1.quantity - 1) + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c1c1 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(" + counter2.colour + " and " + counter2.colour + ") = <sup>" + counter2.quantity + "</sup> /<sub>" + total + "</sub> &#215; <sup>" + (counter2.quantity - 1) + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c2c2 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(same colours) = <sup>" + (c1c1 + c2c2) + "</sup>/<sub>" + denominator + "</sub></p>";
            break;
        case 2:
            problem.question += "<p>Work out the probability that at least one counter is " + counter1.colour + ".</p>";
            problem.answer = "<p>P(" + counter1.colour + " and " + counter1.colour + ") = <sup>" + counter1.quantity + "</sup>/<sub>" + total + "</sub> &#215; <sup>" + (counter1.quantity - 1) + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c1c1 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(" + counter1.colour + " and " + counter2.colour + ") = <sup>" + counter1.quantity + "</sup>/<sub>" + total + "</sub> &#215; <sup>" + counter2.quantity + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c1c2 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(" + counter2.colour + " and " + counter1.colour + ") = <sup>" + counter2.quantity + "</sup> /<sub>" + total + "</sub> &#215; <sup>" + counter1.quantity + "</sup>/<sub>" + (total - 1) + "</sub> = <sup>" + c2c1 + "</sup>/<sub>" + denominator + "</sub></p>";
            problem.answer += "<p>P(at least one " + counter1.colour + ") = <sup>" + (c1c1 + c1c2 + c2c1) + "</sup>/<sub>" + denominator + "</sub></p>";
            break;
    }
    return problem;
}
function directInverseProportion() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    problem.question = "";
    var type = "directly";
    if (Math.random() < 0.5) {
        type = "inversely"
    }
    var power = 1;
    if ((Math.random() < 0.5)) {
        power = 2;
    }
    var x = new Object;
    var y = new Object;
    var rnd = getRandom(0, 50);
    x.letter = letterPicker(rnd, true);
    y.letter = letterPicker(rnd + 1, true);

    y.value = getRandom(2, 10);
    var k = y.value * y.value * getRandom(2, 10);
    if (type == "directly") {
        x.value = k * y.value;
        if (power == 2) {
            x.value *= y.value;
        }
    } else {
        x.value = k / y.value;
        if (power == 2) {
            x.value /= y.value;
        }
    }

    y.newValue = getRandom(2, 20);
    while (y.value == y.newValue) {
        y.newValue = getRandom(2, 20);
    }
    if (power == 1) {
        problem.question = "<p>" + x.letter + " is " + type + " proportional to " + y.letter + ".</p>";
    } else {
        problem.question = "<p>" + x.letter + " is " + type + " proportional to the square of " + y.letter + ".</p>";
    }

    problem.question += "When " + x.letter + " = " + x.value + ", " + y.letter + " = " + y.value + ".</p>";
    problem.question += "Find the value of " + x.letter + " when " + y.letter + " = " + y.newValue + ".</p>";

    if (type == "directly") {
        if (power == 1) {
            problem.answer = "<p>" + x.letter + " &alpha; " + y.letter + " so " + x.letter + " = k" + y.letter + "</p>";
            problem.answer += "<p>" + x.value + " = " + y.value + "k &there4; k = " + k + "</p>";
            problem.answer += "<p>" + x.letter + " = " + k + y.letter + "</p>";
            problem.answer += "<p>When " + y.letter + " = " + y.newValue + ", " + x.letter + " = " + k + "(" + y.newValue + ")</p>";
            problem.answer += "<p>" + x.letter + " = " + (k * y.newValue) + ".</p>";
        } else {
            problem.answer = "<p>" + x.letter + " &alpha; " + y.letter + " so " + x.letter + " = k" + y.letter + "&sup2;</p>";
            problem.answer += "<p>" + x.value + " = " + y.value * y.value + "k &there4; k = " + k + "</p>";
            problem.answer += "<p>" + x.letter + " = " + k + y.letter + "&sup2;</p>";
            problem.answer += "<p>When " + y.letter + " = " + y.newValue + ", " + x.letter + " = " + k + "(" + y.newValue + ")&sup2;</p>";
            problem.answer += "<p>" + x.letter + " = " + (k * y.newValue * y.newValue) + ".</p>";
        }
    } else {
        if (power == 1) {
            problem.answer = "<p>" + x.letter + " &alpha; <sup>1</sup>/<sub>" + y.letter + "</sub> so " + x.letter + " = <sup>k</sup>/<sub>" + y.letter + "</sub></p>";
            problem.answer += "<p>" + x.value + " = <sup>k</sup>/<sub>" + y.value + "</sub> &there4; k = " + k + "</p>";
            problem.answer += "<p>" + x.letter + " = <sup>" + k + "</sup>/<sub>" + y.letter + "</sub></p>";
            problem.answer += "<p>When " + y.letter + " = " + y.newValue + ", " + x.letter + " = <sup>" + k + "</sup>/<sub>" + y.newValue + "</sub></p>";
            problem.answer += "<p>" + x.letter + " = " + (k / y.newValue).toFixed(2) + ".</p>";
        } else {
            problem.answer = "<p>" + x.letter + " &alpha; <sup>1</sup>/<sub>" + y.letter + "&sup2;</sub> so " + x.letter + " = <sup>k</sup>/<sub>" + y.letter + "&sup2;</sub></p>";
            problem.answer += "<p>" + x.value + " = <sup>k</sup>/<sub>" + y.value * y.value + "</sub> &there4; k = " + k + "</p>";
            problem.answer += "<p>" + x.letter + " = <sup>" + k + "</sup>/<sub>" + y.letter + "&sup2;</sub></p>";
            problem.answer += "<p>When " + y.letter + " = " + y.newValue + ", " + x.letter + " = <sup>" + k + "</sup>/<sub>" + y.newValue + "&sup2;</sub></p>";
            problem.answer += "<p>" + x.letter + " = " + (k / (y.newValue * y.newValue)).toFixed(2) + ".</p>";
        }
    }
    return problem;
}
function speedDistanceTime() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = false;
    var person = namePicker();
    var departHour = getRandom(5, 10);
    var departMinute = 15 * getRandom(1, 3);
    var speed = 40 + 10 * getRandom(1, 3);
    var totalDistance = (speed / 2) * getRandom(8, 18);
    var hours = (1 + 2 * getRandom(1, 2)) / 2;
    var distance = speed * hours;
    var totalTime = totalDistance / speed;
    var totalHours = Math.floor(totalTime);
    var totalMinutes = (totalTime - totalHours) * 60;
    var arriveMinute = departMinute + totalMinutes;
    var arriveHour = departHour + totalHours;
    if (arriveMinute >= 60) {
        arriveMinute -= 60;
        arriveHour++;
    }
    if (arriveMinute == 0) {
        arriveMinute = "00";
    }
    if (departHour < 10) {
        departHour = "0" + departHour;
    }
    problem.question = "<p>" + person.name + " is driving to France for " + person.owner + " holiday.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " will drive a total distance of " + totalDistance + " miles.</p>";
    problem.question += "<p>" + person.name + " sets off at " + departHour + ":" + departMinute + ".</p>";
    problem.question += "<p>It takes " + person.object + " " + hours + " hours to travel the first " + distance + " miles.</p>";
    problem.question += "<p>Use this information to estimate the time " + person.name + " will arrive.</p>";
    problem.answer = "Speed = " + distance + " &divide; " + hours + " = " + speed + " mph.</p>";
    problem.answer += "Total time = " + totalDistance + " &divide; " + speed + " = " + totalTime + " hours.</p>";
    problem.answer += "<p>" + person.name + "'s estimated arrival time is " + arriveHour + ":" + arriveMinute + ".</p>";
    return problem;
}
function sharingRatioWithFDP() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F/H";
    problem.calc = false;
    var n = getRandom(0, 1000);
    var person1 = namePicker(n);
    var person2 = namePicker(n + 1);
    var person3 = namePicker(n + 2);
    var num = getRandom(1, 4);
    var remaining = 100 - (num * 10);
    var r1 = getRandom(1, 4);
    var r2 = 5 - r1;
    var perPart = remaining / (r1 + r2);
    problem.question = "<p>" + person1.name + ", " + person2.name + " and " + person3.name + " share some money.</p>";
    problem.question += "<p>" + person1.name + " takes <sup>" + num + "</sup>/<sub>10</sub> of the money.</p>";
    problem.question += "<p>" + person2.name + " and " + person3.name + " share the rest of the money in the ratio " + r1 + ":" + r2 + ".</p>";
    problem.answer = "<p>After " + person1.name + " takes " + person1.owner + " share there is " + remaining + "% left.</p>";
    problem.answer += "<p>There " + r1 + " + " + r2 + " = " + (r1 + r2) + " parts to share between " + person2.name + " and " + person3.name + ".</p>";
    problem.answer += "<p>" + remaining + "% &divide; " + (r1 + r2) + " = " + perPart + "% per part.</p>";
    if (Math.random() < 0.5) {
        problem.question += "<p>What percentage does " + person2.name + " receive?</p>";
        problem.answer += "<p>" + person2.name + " receives " + perPart + " &#215; " + r1 + " = " + (perPart * r1) + "% of the money.</p>";

    } else {
        problem.question += "<p>What percentage does " + person3.name + " receive?</p>";
        problem.answer += "<p>" + person3.name + " receives " + perPart + " &#215; " + r2 + " = " + (perPart * r2) + "% of the money.</p>";

    }
    return problem;
}
function linearInequalities() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    var x = letterPicker();
    var co = new Array(4);
    co[0] = co[1] = co[2] = co[3] = 0;
    var answer = (co[3] - co[1]) / (co[0] - co[2]);
    while (answer != Math.round(10 * answer) / 10 || answer % 1 == 0) {
        co[0] = getRandom(1, 10);
        co[1] = getRandom(-10, 5);
        co[2] = getRandom(-10, 5);
        co[3] = getRandom(-5, 20);
        while (co[0] == 0 || co[2] == 0) {
            co[0] = getRandom(1, 10);
            co[2] = getRandom(-10, 5);
        }
        while (Math.abs(co[0] - co[2]) < 2) {
            co[2] = getRandom(-10, 10);
        }
        while (co[1] == co[3]) {
            co[3] = getRandom(-10, 10);
        }
        answer = (co[3] - co[1]) / (co[0] - co[2]);
    }
    if (Math.random() < 0.5) {
        var sign = " < ";
        var adj = "largest";
        answer = Math.floor(answer);
    } else {
        sign = " > ";
        adj = "smallest";
        answer = Math.ceil(answer);
    }
    problem.question = "<p>Work out the " + adj + " integer value of " + x + " that satisfies the inequality:</p>";
    problem.question += "<p>" + fixTerm(co[0], x, 1) + fixTerm(co[1], "") + sign + fixTerm(co[2], x, 1) + fixTerm(co[3], "") + "</p>";
    problem.answer = "<p>" + fixTerm(co[0] - co[2], x, 1) + sign + fixTerm(co[3] - co[1], "", 1) + "</p>";
    problem.answer += "<p>" + x + sign + "<sup>" + fixTerm(co[3] - co[1], "", 1) + "</sup>/<sub>" + fixTerm(co[0] - co[2], "", 1) + "</sub></p>";
    problem.answer += "<p>" + x + sign + Math.round(1000 * (co[3] - co[1]) / (co[0] - co[2])) / 1000 + "</p>";
    problem.answer += "<p>The " + adj + " value of " + x + " to satisfy the inequality is " + answer + ".</p>";
    return problem;
}
function savingPercentageOfWages() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F";
    problem.calc = true;
    var wage = 20 * getRandom(6, 14);
    var cost = 2 * getRandom(100, 200);
    var percentage = 5 * getRandom(1, 3);
    var perWeek = wage * percentage / 100;
    var person = namePicker();
    var item = itemPicker("large");
    problem.question = "<p>" + person.name + "'s wages are &pound;" + wage + " per week.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " wants to save some money to buy a " + item + ".</p>";
    problem.question += "<p>The " + item + " costs &pound;" + cost + ".</p>";
    problem.question += "<p>" + person.name + " is going to save " + percentage + "% of " + person.owner + " wages each week.</p>";
    problem.question += "<p>How many weeks will it take " + person.object + " to save enough money to buy the " + item + "?<p>";
    problem.answer = "<p>&pound;" + wage + " &#215; " + percentage + " &divide; 100 = &pound;" + perWeek + " saved per week.</p>"
    problem.answer += "<p>" + cost + " &divide; " + perWeek + " = " + Math.round(10000 * cost / perWeek) / 10000 + ".</p>";
    problem.answer += "<p>" + person.name + " will have to save up for " + Math.ceil(cost / perWeek) + " weeks.</p>"
    return problem;
}
function circleWithinSemicircle() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "F/H";
    problem.calc = true;
    var units = unitPicker("length");
    var circleDiameter = 2 * getRandom(4, 12);
    var circleArea = (circleDiameter / 2) * (circleDiameter / 2);
    var semicircleArea = circleDiameter * circleDiameter / 2;
    var shadedArea = semicircleArea - circleArea;
    problem.question = "<img src='/media/gcseQuestions/21.jpg'>";
    problem.question += "<p>The diagram shows a circle inside a semicircle.</p>";
    problem.question += "<p>The circle has a diameter of " + circleDiameter + " " + units + ".</p>";
    problem.question += "<p>The semicircle has a diameter of " + (circleDiameter * 2) + " " + units + ".</p>";
    problem.question += "<p>Calculate the shaded area. Round your answer to 1 decimal place.</p>";
    problem.answer = "<p>Area of the circle is &pi; &#215; " + (circleDiameter / 2) + "&sup2; = " + circleArea + "&pi; " + units + "&sup2;.</p>";
    problem.answer += "<p>Area of the semicircle is &pi; &#215; " + circleDiameter + "&sup2; &divide; 2 = " + semicircleArea + "&pi; " + units + "&sup2;.</p>";
    problem.answer += "<p>" + semicircleArea + "&pi; - " + circleArea + "&pi; = " + shadedArea + "&pi;.</p>";
    problem.answer += "<p>Shaded area = " + Math.round(10 * shadedArea * Math.PI) / 10 + " " + units + "&sup2 (1 d.p.).</p>";
    return problem;
}
function cafeMenuChangeProblem() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = true;
    var person = namePicker(getRandom(0, 1000));
    var item = new Array("cup of tea", "cup of coffee", "fruit juice", "burger", "hot dog", "chips");
    var price = new Array(75, 95, 60, 245, 185, 95);
    var pick1 = {};
    var pick2 = {};
    var pick3 = {};
    var choice = getRandom(0, item.length - 1);
    pick1.name = item[choice];
    pick1.price = price[choice];
    pick1.quantity = getRandom(1, 3);
    pick1.total = pick1.price * pick1.quantity / 100;
    choice = getRandom(0, item.length - 1);
    pick2.name = item[choice];
    while (pick2.name == pick1.name) {
        choice = getRandom(0, item.length - 1);
        pick2.name = item[choice];
    }
    pick2.price = price[choice];
    pick2.quantity = getRandom(1, 3);
    pick2.total = pick2.price * pick2.quantity / 100;
    choice = getRandom(0, item.length - 1);
    pick3.name = item[choice];
    while (pick2.name == pick3.name || pick1.name == pick3.name) {
        choice = getRandom(0, item.length - 1);
        pick3.name = item[choice];
    }
    pick3.price = price[choice];
    pick3.quantity = getRandom(1, 3);
    pick3.total = pick3.price * pick3.quantity / 100;
    var grandTotal = pick1.total + pick2.total + pick3.total;
    var cash = 5 * getRandom(1, 2);
    if (grandTotal > 10) {
        cash = 10;
    }
    problem.question = "<p>Here is a caf&eacute; menu.</p>";
    problem.question += "<img src='/media/gcseQuestions/22.jpg'>";
    problem.question += "<p>" + person.name + " wants to buy ";
    problem.question += pick1.quantity + " x " + pick1.name + " ";
    problem.question += pick2.quantity + " x " + pick2.name + " and ";
    problem.question += pick3.quantity + " x " + pick3.name + ". ";
    problem.question += person.subject + " has a &pound;" + cash + " note.</p>";
    problem.question += "<p>Does " + person.name + " have enough money?</p>";
    problem.question += "<p>You must give reasons for your answer.</p>";
    problem.answer = "<p>" + pick1.quantity + " &#215; " + pick1.name + ": " + pick1.quantity + " &#215; " + (pick1.price / 100).toFixed(2) + " = &pound;" + pick1.total.toFixed(2) + ".</p>";
    problem.answer += "<p>" + pick2.quantity + " &#215; " + pick2.name + ": " + pick2.quantity + " &#215; " + (pick2.price / 100).toFixed(2) + " = &pound;" + pick2.total.toFixed(2) + ".</p>";
    problem.answer += "<p>" + pick3.quantity + " &#215; " + pick3.name + ": " + pick3.quantity + " &#215; " + (pick3.price / 100).toFixed(2) + " = &pound;" + pick3.total.toFixed(2) + ".</p>";
    problem.answer += "<p>Total = &pound;" + (grandTotal).toFixed(2) + ".</p>";
    if (grandTotal > cash) {
        problem.answer += "<p>No, " + person.name + " only has &pound;" + cash + " so " + person.subject.toLowerCase() + " doesn't have enough money.</p>";
    } else {
        problem.answer += "<p>Yes, " + person.name + " has &pound;" + cash + " so " + (person.subject).toLowerCase() + " does have enough money.</p>";
    }
    return problem;
}
function thinkOfANumber() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = true;
    var person = namePicker(getRandom(0, 1000));
    var x = getRandom(1, 10);
    var multiplier = getRandom(2, 5);
    do {
        var shift = getRandom(-10, 10);
    } while (shift === 0);
    var answer = x * multiplier + shift;
    problem.question = "<p>" + person.name + " thinks of a number.</p>";
    switch (multiplier) {
        case 2:
            problem.question += "<p>" + capitalFirst(person.subject) + " doubles the number.</p>";
            break;
        case 3:
            problem.question += "<p>" + capitalFirst(person.subject) + " trebles the number.</p>";
            break;
        case 4:
            problem.question += "<p>" + capitalFirst(person.subject) + " multiplies the number by four.</p>";
            break;
        case 5:
            problem.question += "<p>" + capitalFirst(person.subject) + " multiplies the number by five.</p>";
            break;
    }
    if (shift < 0) {
        problem.question += "<p>" + capitalFirst(person.subject) + " then subtracts " + Math.abs(shift) + ".</p>";
        problem.answer = "<p>" + multiplier + "x - " + Math.abs(shift) + " = " + answer + "</p>";
    } else {
        problem.question += "<p>" + capitalFirst(person.subject) + " then adds " + shift + ".</p>";
        problem.answer = "<p>" + multiplier + "x + " + shift + " = " + answer + "</p>";
    }
    problem.question += "<p>" + person.name + "'s answer is " + answer + ".</p>";
    problem.question += "<p>What number did " + person.subject + " think of?</p>";
    problem.answer += "<p>" + multiplier + "x = " + (x * multiplier) + "</p>";
    problem.answer += "<p>x = <sup>" + (x * multiplier) + "</sup>/<sub>" + multiplier + "</sub></p>";
    problem.answer += "<p>x = " + x + ".</p>";
    return problem;
}
function holidayLoan() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F";
    problem.calc = true;
    var person = namePicker(getRandom(0, 1000));
    var loan = 200 * getRandom(1, 4);
    var interest = 5 * getRandom(1, 5);
    var totalCost = loan + (interest * loan / 100);
    problem.question = "<p>" + person.name + " is going on holiday.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " is going to take out a loan of &pound;" + loan + " to help pay for the holiday.</p>";
    problem.question += "<p>" + person.name + " will have to pay back the &pound;" + loan + " plus " + interest + "% interest over 12 months.";
    problem.question += "<p>" + capitalFirst(person.subject) + " will pay back the same amount of money each month.</p>";
    problem.question += "<p>How much money will " + person.name + " pay back each month?</p>";
    problem.answer = "<p>" + interest + "% of &pound;" + loan + " = " + loan + " &#215 0." + interest + " = &pound;" + (loan * interest / 100) + ".</p>";
    problem.answer += "<p>Total cost of loan is &pound;" + loan + " + &pound;" + (loan * interest / 100) + " = &pound;" + totalCost + ".</p>";
    problem.answer += "<p>Monthly payment will be &pound;" + totalCost + " &divide; 12 = &pound;" + (totalCost / 12).toFixed(2) + ".</p>";
    return problem;
}
function equationOfPerpendiculars() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = false;
    function Coordinate(x, y) {
        this.x = x;
        this.y = y;
    }
    var m = getRandom(2, 5);
    var p = -1 / m;
    var yIntercept = 0.12345;
    while (yIntercept !== Math.round(yIntercept)) {
        var a = new Coordinate(getRandom(-10, 10), getRandom(-10, 10));
        var step = getRandom(1, 5);
        var b = new Coordinate(a.x + step, a.y + (m * step));
        var c = new Coordinate(getRandom(-10, 10), getRandom(-10, 10));
        yIntercept = c.y - p * c.x;
    }
    problem.question = "<p>Point A has coordinates (" + a.x + ", " + a.y + ").</p>";
    problem.question += "<p>Point B has coordinates (" + b.x + ", " + b.y + ").</p>";
    problem.question += "<p>Point C has coordinates (" + c.x + ", " + c.y + ").</p>";
    problem.question += "<p>Find an equation of the line that passes through C and is perpendicular to AB.</p>";
    problem.question += "<p>Give your equation in the form ax + by = c where a and b are integers.</p>";
    problem.answer = "<p>Gradient of AB is " + (b.y - a.y) + " &divide; " + (b.x - a.x) + " = " + m + ".</p>";
    problem.answer += "<p>Gradient of line perpendicular to AB is <sup>-1</sup>/<sub>" + m + "</sub>.</p>";
    problem.answer += "<p>Equation of perpendicular is of the form y = <sup>-1</sup>/<sub>" + m + "</sub>x + c</p>";
    problem.answer += "<p>At the point C, (" + c.y + ") = <sup>-1</sup>/<sub>" + m + "</sub>(" + c.x + ") + c.</p>"
    problem.answer += "<p>c = " + yIntercept + ".</p>";
    problem.answer += "<p>x + " + m + "y = " + m * yIntercept + ".</p>";
    return problem;
}
function anglesInTetrahedron() {
    var problem = {};
    problem.marks = 6;
    problem.tier = "H";
    problem.calc = true;
    var units = unitPicker("length");
    var AB = getRandom(2, 10);
    var AC = getRandom(2, 10);
    var AD = getRandom(2, 10);
    var BCBC = AB * AB + AC * AC;
    var BDBD = AB * AB + AD * AD;
    var CDCD = AC * AC + AD * AD;
    var numAnswer = BDBD + CDCD - BCBC;
    var denAnswer = 2 * Math.sqrt(BDBD) * Math.sqrt(CDCD);
    var finalAnswer = Math.acos(numAnswer / denAnswer) * (180 / Math.PI);
    problem.question = "<p>The diagram shows a tetrahedron.</p>";
    problem.question += "<img src='/media/gcseQuestions/26.jpg'>";
    problem.question += "<p>AD is perpendicular to both AB and AC.</p>";
    problem.question += "<p>AB = " + AB + " " + units + ", ";
    problem.question += "AC = " + AC + " " + units + " and ";
    problem.question += "AD = " + AD + " " + units + ".</p>";
    problem.question += "<p>Angle BAC = 90&deg;.</p>";
    problem.question += "<p>Calculate the size of angle BDC.</p>";
    problem.question += "<p>Give your answer correct to 1 decimal place.</p>";
    problem.answer = "<p>BC = &radic;(" + AB * AB + " + " + AC * AC + ") = &radic;" + BCBC + ".</p>";
    problem.answer += "<p>BD = &radic;(" + AB * AB + " + " + AD * AD + ") = &radic;" + BDBD + ".</p>";
    problem.answer += "<p>CD = &radic;(" + AC * AC + " + " + AD * AD + ") = &radic;" + CDCD + ".</p>";
    problem.answer += "<p>cos BDC = (" + BDBD + " + " + CDCD + " - " + BCBC + ") &divide; (2&#215;&radic;" + BDBD + "&#215;&radic;" + CDCD + ")</p>";
    problem.answer += "<p>Angle BDC = cos<sup>-1</sup>(" + numAnswer + " &divide; 2&#215;&radic;" + BDBD + "&#215;&radic;" + CDCD + ")</p>";
    problem.answer += "<p>BDC = " + Math.round(10 * finalAnswer) / 10 + "&deg; (1 d.p.)</p>"
    return problem;
}
function angleAndAreaOfTriangles() {
    var problem = {};
    problem.marks = 6;
    problem.tier = "H";
    problem.calc = true;
    var units = unitPicker("length");
    var AB = getRandom(6, 11);
    var AC = getRandom(6, 11);
    var BC = getRandom(6, 11);
    var angle = Math.acos(((AB * AB + BC * BC) - AC * AC) / (2 * AB * BC)) * (180 / Math.PI);
    var area = AB * BC * Math.sin(toRadians(angle)) / 2;
    problem.question = "<p>The diagram shows a triangle ABC.</p>";
    problem.question += "<img src='/media/gcseQuestions/27-" + getRandom(0, 1) + ".jpg'>";
    problem.question += "<p>AB = " + AB + " " + units + ", ";
    problem.question += "AC = " + AC + " " + units + " and ";
    problem.question += "BC = " + BC + " " + units + ".</p>";
    problem.question += "<p>a) Work out the size of angle B.</p>";
    problem.question += "<p>b) Work out the area of triangle ABC.</p>";
    problem.question += "Give your answers correct to 1 decimal place.";
    problem.answer = "<p>a) " + AC + "&sup2; = " + AB + "&sup2; + " + BC + "&sup2 - 2(" + AB + ")(" + BC + ")cos(B)</p>";
    problem.answer += "<p>" + AC * AC + " = " + (AB * AB + BC * BC) + " - " + 2 * AB * BC + "cos(B)</p>";
    problem.answer += "<p>B = cos<sup>-1</sup>(" + ((AB * AB + BC * BC) - AC * AC) + " &divide; " + 2 * AB * BC + ")</p>";
    problem.answer += "<p>B = " + angle.toFixed(1) + "&deg (1 d.p.)</p>";
    problem.answer += "<p>b) Area of ABC = <sup>1</sup>/<sub>2</sub>(" + AB + ")(" + BC + ")sin(" + angle.toFixed(1) + ")</p>";
    problem.answer += "<p>Area = " + area.toFixed(1) + " " + units + "&sup2 (1 d.p.)</p>";
    return problem;
}
function sideLengthOfEquilateral() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    var units = unitPicker("length");
    var area = getRandom(10, 150);
    var x = Math.sqrt(area * 2 / Math.sin(toRadians(60)));
    var accuracy = getRandom(2, 3);
    problem.question = "<p>The diagram shows an equilateral triangle.</p>";
    problem.question += "<img src='/media/gcseQuestions/28.jpg'>";
    problem.question += "<p>The area of the triangle is " + area + " " + units + "&sup2;.</p>";
    problem.question += "<p>Find the length of x.</p>";
    problem.question += "<p>Round your answer to " + accuracy + " significant figures.</p>";
    problem.answer = "<p>" + area + " = <sup>1</sup>/<sub>2</sub>x&sup2;sin(60)</p>";
    problem.answer += "<p>x&sup2; = " + (area * 2) + " &divide; sin(" + 60 + ")</p>";
    problem.answer += "<p>x = " + (x.toPrecision(accuracy) - 0) + " " + units + " (" + accuracy + " s.f.)</p>";
    return problem;
}
function mixingDensities() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    var a = {};
    var b = {};
    var c = {};
    do {
        a.density = getRandom(5, 30) / 10;
        b.density = getRandom(5, 30) / 10;
        a.mass = getRandom(50, 150) * 2;
        b.mass = getRandom(50, 150) * 2;
        a.volume = a.mass / a.density;
        b.volume = b.mass / b.density;
        c.mass = a.mass + b.mass;
        c.volume = a.volume + b.volume;
        c.density = Math.round(1000 * c.mass / c.volume) / 1000;
    } while (a.volume != (100 * Math.round(a.volume) / 100) || b.volume != (100 * Math.round(b.volume) / 100) || a.density == b.density);
    problem.question = "<p>Liquid A has a density of " + a.density + " g/cm<sup>3</sup>.</p>";
    problem.question += "<p>Liquid B has a density of " + b.density + " g/cm<sup>3</sup>.</p>";
    problem.question += "<p>" + a.mass + " g of liquid A and " + b.mass + " g of liquid B are mixed to make liquid C.</p>";
    problem.question += "<p>Work out the density of liquid C.</p>";
    problem.answer = "<p>Mass of C is " + a.mass + " + " + b.mass + " = " + c.mass + " g.</p>";
    problem.answer += "<p>Volume of A is " + a.mass + " &divide; " + a.density + " = " + a.volume + " cm<sup>3</sup>.</p>";
    problem.answer += "<p>Volume of B is " + b.mass + " &divide; " + b.density + " = " + b.volume + " cm<sup>3</sup>.</p>";
    problem.answer += "<p>Volume of C is " + a.volume + " + " + b.volume + " = " + c.volume + " cm<sup>3</sup>.</p>";
    problem.answer += "<p>Liquid C has a density of " + c.mass + " &divide " + c.volume + " = " + c.density + " g/cm<sup>3</sup>.</p>";
    return problem;
}
function estimatingPopulations() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    if (Math.random() < 0.3) {
        var person = "farmer";
        var animal = "rabbits";
        var place = "on his farm";
    } else if (Math.random() < 0.5) {
        person = "fisherman";
        animal = "fish";
        place = "in his pond";
    } else {
        person = "gardener";
        animal = "snails";
        place = "in his garden";
    }
    var firstCatch = getRandom(50, 200);
    var secondCatch = getRandom(50, 200);
    var tagged = getRandom(10, secondCatch / 2);
    var taggedFraction = "<sup>" + tagged + "</sup>&frasl;<sub>" + secondCatch + "</sub>";
    var population = Math.round(firstCatch * secondCatch / tagged);
    problem.question = "<p>A " + person + " wants to estimate the number of " + animal + " " + place + ".</p>";
    problem.question += "<p>One day he catches " + firstCatch + " " + animal + ". He puts a tag on each " + animal + " then releases them.</p>";
    problem.question += "<p>Then next day the " + person + " catches " + secondCatch + " " + animal + ".</p>";
    problem.question += "<p>" + tagged + " of these " + animal + " have a tag on them.</p>";
    problem.question += "<p>Work out an estimate for the total number of " + animal + " " + place + ".</p>";
    problem.question += "<p>Write down any assumptions you have made.</p>";
    problem.answer = "<p>Estimate that " + firstCatch + " of the " + animal + " make up " + taggedFraction + " of the population.</p>";
    problem.answer += "<p>Assuming the population hasn't changed over night, the estimated population is ";
    problem.answer += firstCatch + " &#215; " + secondCatch + " &divide; " + tagged + " = " + population + " " + animal + ".</p>";
    return problem;
}
function expandingCubics() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    var letter = letterPicker();
    var a = {};
    var b = {};
    var c = {};
    a.xCo = getRandom(1, 4);
    a.co = getRandom(-10, 10);
    a.display = "(" + fixTerm(a.xCo, letter, true) + fixTerm(a.co, "", false) + ")";
    b.xCo = getRandom(1, 4);
    b.co = getRandom(-10, 10);
    b.display = "(" + fixTerm(b.xCo, letter, true) + fixTerm(b.co, "", false) + ")";
    c.xCo = getRandom(1, 4);
    c.co = getRandom(-10, 10);
    c.display = "(" + fixTerm(c.xCo, letter, true) + fixTerm(c.co, "", false) + ")";
    var expression = a.display + b.display + c.display;
    var firstExpansion = "(" + fixTerm(a.xCo * b.xCo, letter + "&sup2;", true) + fixTerm(a.xCo * b.co + a.co * b.xCo, letter, false) + fixTerm(a.co * b.co, "", false) + ")" + c.display;
    var cubedTerm = fixTerm(a.xCo * b.xCo * c.xCo, letter + "&sup3;", true);
    var squaredTerm = fixTerm((a.xCo * b.co + a.co * b.xCo) * c.xCo + (a.xCo * b.xCo * c.co), letter + "&sup2;", false);
    var linearTerm = fixTerm((a.xCo * b.co + a.co * b.xCo) * c.co + (a.co * b.co * c.xCo), letter, false);
    var constant = fixTerm(a.co * b.co * c.co, "", false);
    problem.question = "<p>Expand: " + expression + "</p>";
    problem.question += "<p>Give your answer in its simplest form.</p>";
    problem.answer = "<p>Expanding and simplyfying the first two pairs of brackets gives:</p>";
    problem.answer += "<p>" + firstExpansion + ".</p>";
    problem.answer += "<p>Now expand and simplify to get:</p>";
    problem.answer += "<p>" + cubedTerm + squaredTerm + linearTerm + constant + ".</p>";
    return problem;
}
function nthTermOfQuadratic() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    var terms = [];
    var secondDiff = [];
    var subtractedTerms = [];
    do {
        var a = getRandom(-3, 5);
    } while (a == 0);
    var b = getRandom(-8, 8);
    var c = getRandom(-20, 25);
    for (var i = 1; i <= 5; i++) {
        terms.push((a * i * i) + (b * i) + (c));
        secondDiff.push(a * i * i);
        subtractedTerms.push((b * i) + (c));
    }
    problem.question = "<p>The first 5 terms of a quadratic sequence are: " + terms + ".</p>";
    problem.question += "<p>Find an expression, in terms of n, for the nth term of this quadratic sequence.</p>";
    problem.answer = "<p>Second difference is " + (a * 2) + " so the coefficient of the n&sup2; term must be " + a + ".</p>";
    problem.answer += "<p>The sequence " + fixTerm(a, "n&sup2;", true) + " goes " + secondDiff + ", ...</p>";
    problem.answer += "<p>Subtracing this from our our original sequence gives " + subtractedTerms + ", ...</p>";
    problem.answer += "<p>This linear sequence has the form " + fixTerm(b, "n", true) + " " + fixTerm(c, "", false) + ".</p>";
    problem.answer += "<p>Combining these gives nth term = ";
    var firstTerm = true;
    problem.answer += fixTerm(a, "n&sup2;", firstTerm);
    if (a != 0) {
        firstTerm = false;
    }
    problem.answer += fixTerm(b, "n", firstTerm);
    if (b != 0) {
        firstTerm = false;
    }
    problem.answer += fixTerm(c, "", firstTerm);
    problem.answer += ".</p>";
    return problem;
}
function proofs() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    switch (getRandom(0, 9)) {
        case 0:
            problem.question = "<p>The product of two consecutive positive integers is added to the larger of the two integers.</p>";
            problem.question += "<p>Prove the result is always a square number.</p>";
            problem.answer = "<p>Let the two consecutive positive integers be n and n + 1.</p>";
            problem.answer += "<p>Adding their product to the larger of the integers gives n(n + 1) + (n + 1) = n&sup2; + 2n + 1.</p>";
            problem.answer += "<p>Now n&sup2 + 2n + 1 = (n + 1)&sup2; so the result must always be a square number.</p>"
            break;
        case 1:
            problem.question = "<p>Prove that the difference between the squares of any two consecutive integers is equal to the sum of these two integers.</p>";
            problem.answer = "<p>Let the two consecutive positive integers be n and n + 1.</p>";
            problem.answer += "<p>The sum of these is n + n + 1 = 2n + 1.</p>";
            problem.answer += "<p>The difference between the squares is given by (n + 1)&sup2; - n&sup2; = (n&sup2 + 2n + 1) - n&sup2;.</p>";
            problem.answer += "<p>The n&sup2; terms cancel leaving 2n + 1 hence the difference between the squares is equal to their sum..</p>";
            break;
        case 2:
            problem.question = "<p>Prove that the sum of four consecutive whole numbers is always even.</p>";
            problem.answer = "<p>Let the four consectutive numbers be n, n + 1, n + 2 and n + 3.</p>";
            problem.answer += "<p>Adding these gives n + n + 1 + n + 2 + n + 3 = 4n + 6.</p>";
            problem.answer += "<p>Now 4n + 6 = 2(2n + 3) therefore must be even since 2 is a factor.</p>";
            break;
        case 3:
            problem.question = "<p>Prove the square of any even number must be an even number.</p>";
            problem.answer = "<p>Let n be any integer then 2n must be even.</p>";
            problem.answer += "<p>Now (2n)&sup2; = 4n&sup2 so must be a multiple of 4.</p>";
            problem.answer += "<p>All multiples of 4 are even.</p>";
            break;
        case 4:
            problem.question = "<p>Prove the square of any odd number must be an odd number.</p>";
            problem.answer = "<p>Let n be any integer then 2n + 1 must be odd.</p>";
            problem.answer += "<p>Squaring gives (2n + 1)&sup2; = 4n&sup2 + 4n + 1.</p>";
            problem.answer += "<p>Now 4n&sup2 + 4n + 1 = 2(2n&sup2 + 2n) + 1 so is 1 more than a multiple of 2, hence odd.</p>";
            problem.answer += "<p>Therefore (2n + 1)&sup2; must be odd.</p>";
            break;
        case 5:
            problem.question = "<p>Prove the sum of any 5 consecutive numbers is always a multiple of 5.</p>";
            problem.answer = "<p>Let the five consectutive numbers be n, n + 1, n + 2, n + 3 and n + 4.</p>";
            problem.answer += "<p>Adding these gives n + n + 1 + n + 2 + n + 3 + n + 4 = 5n + 10.</p>";
            problem.answer += "<p>Now 5n + 10 = 5(n + 2) therefore must be a multple of 5.</p>";
            break;
        case 6:
            problem.question = "<p>Prove that the sum of the squares of any two consecutive even numbers is always a multiple of 4.</p>";
            problem.answer = "<p>Let n be any integer then 2n is even and the next even number is 2n + 2.</p>";
            problem.answer += "<p>Adding the squares of these gives (2n&sup2;) + (2n + 2)&sup2; = 4n&sup2 + (4n&sup2; + 8n + 4).</p>";
            problem.answer += "This simplifies to 8n&sup2; + 8n + 4 = 4(2n&sup2; + 2n + 1) hence is a multiple of 4.</p>";
            break;
        case 7:
            problem.question = "<p>Take any two-digit number. Now reverse the digits and add to your original number.</p>";
            problem.question += "<p>Prove that the answer is always a multiple of 11.</p>";
            problem.answer = "<p>A two digit number with digits a and b can be written as 10a + b.</p>";
            problem.answer += "<p>Reversing the digits gives 10b + a.</p>";
            problem.answer += "<p>Adding these gives 10a + b + 10b + a = 11a + 11b.</p>";
            problem.answer += "<p>This factorises to 11(a + b) therefore must be a multiple of 11.</p>";
            break;
        case 8:
            problem.question = "<p>Prove that the difference between the squares of any two consecutive numbers is always an odd number.</p>";
            problem.answer = "<p>Let the two consecutive positive integers be n and n + 1.</p>";
            problem.answer += "<p>The difference between the squares is given by (n + 1)&sup2; - n&sup2; = (n&sup2 + 2n + 1) - n&sup2;.</p>";
            problem.answer += "<p>This simplifies to 2n + 1. Now since 2n is a multiple of 2 and therefore even, 2n + 1 must be odd.</p>";
            break;
        case 9:
            problem.question = "<p>Prove that the sum of the squares of any two consecutive odd numbers cannot be a multiple of 4.</p>";
            problem.answer = "<p>Let n be any integer then 2n + 1 is odd and the next odd number is 2n + 3.</p>";
            problem.answer += "<p>The sum of their squares is given by (2n + 1)&sup2; + (2n + 3)&sup2; = 4n&sup2; + 4n + 1 + 4n&sup2; + 12n + 9.</p>";
            problem.answer += "<p>This simplifies to 8n&sup2; + 16n + 10 = 4(2n&sup2; + 4n) + 10.</p>";
            problem.answer += "<p>This is 10 more than a multiple of 4 and is therefore cannot be a multiple of 4 itself.</p>";
            break;
    }
    return problem;
}
function errorIntervals() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F/H";
    problem.calc = false;
    var person = namePicker();
    var letter = letterPicker();
    var accuracy = getRandom(-3, 3);
    var value = (getRandom(100, 1000) / Math.pow(10, accuracy));
    var lowerBound = roundError(value - (1 / Math.pow(10, accuracy)) / 2);
    var upperBound = roundError(value + (1 / Math.pow(10, accuracy)) / 2);
    var plural = "";
    if (accuracy > 1) {
        plural = "s";
    }
    if (accuracy > 0) {
        value = value.toFixed(accuracy);
    }
    problem.question = "<p>" + person.name + " rounds a number, " + letter + ", to "
    if (accuracy == 0) {
        problem.question += " the nearest whole number";
    } else if (accuracy > 0) {
        problem.question += accuracy + " decimal place" + plural;
    } else {
        problem.question += " the nearest " + Math.pow(10, Math.abs(accuracy));
    }
    problem.question += ".</p>";
    problem.question += "<p>The result is " + value + ".</p>";
    problem.question += "<p>Write down the error interval for " + letter + ".</p>";
    problem.answer = "<p>" + lowerBound + " &le; " + letter + " < " + upperBound + ".</p>";
    return problem;
}
function pressureForceArea() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = true;
    var pressure = 4 * getRandom(3, 24);
    var force = pressure * getRandom(3, 39) / 2;
    var area = force / pressure;
    problem.question = "<p>A box exerts a force of " + force + " newtons on a floor.</p>";
    problem.question += "<p>The pressure on the floor is " + pressure + " newtons/m&sup2;.</p>";
    problem.question += "<p>Calculate the area of the box that is in contact with the floor.</p>";
    problem.question += "<p>Pressure = Force &divide; Area.</p>"
    problem.answer = "<p>First rearrange the formula to give:</p>";
    problem.answer += "<p>Area = Force &divide; Pressure.</p>";
    problem.answer += "<p>Now substituting in gives " + force + " &divide; " + pressure + " = " + area + " m&sup2;.</p>";
    return problem;
}
function boxOfPens() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F/H";
    problem.calc = false;
    var pen1 = {};
    var pen2 = {};
    var pen3 = {};
    var seed = getRandom(0, 100);
    pen1.colour = colourPicker(seed);
    pen2.colour = colourPicker(seed + 1);
    pen3.colour = colourPicker(seed + 2);
    pen1.multiplier = getRandom(2, 5);
    pen2.multiplier = getRandom(2, 5);
    problem.question = "<p>There are " + pen1.multiplier + " times as many " + pen1.colour + " pens as " + pen2.colour + " pens ";
    problem.question += "and " + pen2.multiplier + " times as many " + pen2.colour + " pens as " + pen3.colour + " pens in a box.</p>";
    problem.question += "<p>Write down the ratio of the number of " + pen1.colour + " pens to " + pen2.colour + " pens to " + pen3.colour + " pens.</p>";
    problem.answer = "<p>The ratio of " + pen1.colour + " pens to " + pen2.colour + " pens is " + pen1.multiplier + ":1.</p>";
    problem.answer += "<p>The ratio of " + pen2.colour + " pens to " + pen3.colour + " pens is " + pen2.multiplier + ":1.</p>";
    problem.answer += "<p>So the ratio of " + pen1.colour + " pens to " + pen2.colour + " pens to " + pen3.colour + " pens is ";
    problem.answer += pen1.multiplier * pen2.multiplier + ":" + pen2.multiplier + ":1.</p>";
    return problem;
}
function convertingSpeeds() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = true;
    var kph = 9 * getRandom(1, 20);
    var mps = kph * 1000 / (60 * 60);
    problem.question = "<p>Convert " + kph + " km/h into metres per second.</p>";
    problem.answer = "<p>There are 1000 metres in a kilometre and 60 &#215; 60 = 3600 seconds in a hour.</p>";
    problem.answer += "<p>" + kph + " &#215; <sup>1000</sup>&frasl;<sub>3600</sub> = " + mps + " m/s.</p>";
    return problem;
}
function comparingPuzzleTimes() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F";
    problem.calc = false;
    switch (getRandom(0, 2)) {
        case 0:
            var game = "game";
            break;
        case 1:
            game = "jigsaw";
            break;
        case 2:
            game = "puzzle";
            break;
    }
    do {
        var p1 = namePicker();
        var p2 = namePicker();
    } while (p1.name == p2.name);
    p1.time = getRandom(100, 400);
    p2.time = 2 * p1.time + getRandom(-15, 15);
    if (p1.time == p2.time) {
        p1.time++;
    }
    p1.minutes = Math.floor(p1.time / 60);
    p2.minutes = Math.floor(p2.time / 60);
    p1.seconds = p1.time % 60;
    p2.seconds = p2.time % 60;
    problem.question = "<p>" + p1.name + " completed a " + game + " in " + p1.minutes + " minutes " + p1.seconds + " seconds.</p>";
    problem.question += "<p>" + p2.name + " did the same " + game + " in " + p2.minutes + " minutes " + p2.seconds + " seconds.";
    problem.question += "<p>" + p1.name + " says, &quot;I completed the " + game + " in less than half the time than " + p2.name + " did.&quot;</p>";
    problem.question += "<p>Is " + p1.name + " right? You must show all your working.</p>";
    problem.answer = "<p>" + p1.name + " completed the " + game + " in " + p1.minutes + " &#215; 60 + " + p1.seconds + " = " + p1.time + " seconds.</p>";
    problem.answer += "<p>" + p2.name + " completed the " + game + " in " + p2.minutes + " &#215; 60 + " + p2.seconds + " = " + p2.time + " seconds.</p>";
    problem.answer += "<p>Half of " + p2.name + "'s time is " + p2.time + " &divide; 2 = " + (p2.time / 2) + " seconds.</p>";
    if (p2.time / 2 > p1.time) {
        problem.answer += "<p>Yes, " + p1.name + " completed the " + game + " in less than half the time of " + p2.name + ".</p>";
    } else {
        problem.answer += "<p>No, " + p1.name + " did not complete the " + game + " in less than half the time of " + p2.name + ".</p>";
    }
    return problem;
}
function exactTrigValues() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var units = unitPicker("length");
    var type = getRandom(0, 1);
    var x = getRandom(3, 40);
    var knownSide, missingSide, answer, angle, ratio, ratioValue;
    switch (getRandom(0, 2)) {
        case 0:
            angle = 30;
            ratio = "sin";
            ratioValue = 0.5;
            switch (type) {
                case 0:
                    knownSide = "AC";
                    missingSide = "AB";
                    break;
                case 1:
                    knownSide = "AB";
                    missingSide = "AC";
                    break;
            }
            break;
        case 1:
            angle = 45;
            ratio = "tan";
            ratioValue = 1;
            switch (type) {
                case 0:
                    knownSide = "AC";
                    missingSide = "BC";
                    break;
                case 1:
                    knownSide = "BC";
                    missingSide = "AC";
                    break;
            }
            break;
        case 2:
            angle = 60;
            ratio = "cos";
            ratioValue = 0.5;
            switch (type) {
                case 0:
                    knownSide = "BC";
                    missingSide = "AB";
                    break;
                case 1:
                    knownSide = "AB";
                    missingSide = "BC";
                    break;
            }
            break;
    }
    problem.answer = "<p>By trigonometry ";
    switch (type) {
        case 0:
            answer = x / ratioValue;
            problem.answer += "" + ratio + "(" + angle + "&deg;) = <sup>" + x + "</sup>&frasl;<sub>" + missingSide + "</sub></p>";
            break;
        case 1:
            answer = x * ratioValue;
            problem.answer += "" + ratio + "(" + angle + "&deg;) = <sup>" + missingSide + "</sup>&frasl;<sub>" + x + "</sub></p>";
            break;
    }
    problem.question = "<img src='/media/gcseQuestions/39-" + getRandom(0, 2) + ".jpg'>";
    problem.question += "<p>In the diagram " + knownSide + " = " + x + " " + units + " and angle ABC = " + angle + "&deg;.</p>";
    problem.question += "<p>Find the length of " + missingSide + ".</p>";
    problem.answer += "<p>The exact value of " + ratio + "(" + angle + "&deg;) = " + ratioValue + ".</p>";
    problem.answer += "<p>So " + missingSide + " = " + answer + " " + units + ".</p>";
    return problem;
}
function fruitProblem() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = true;
    fruit1 = {};
    fruit2 = {};
    do {
        fruit1.name = fruitPicker();
        fruit2.name = fruitPicker();
    } while (fruit1.name == fruit2.name);
    fruit1.price = 2 * getRandom(20, 60);
    fruit2.price = 2 * getRandom(20, 60);
    fruit1.weight = (2 * getRandom(0, 3) + 1) / 2;
    fruit2.weight = (2 * getRandom(0, 3) + 1) / 2;
    fruit1.cost = fruit1.price * fruit1.weight;
    fruit2.cost = fruit2.price * fruit2.weight;
    var multiplier = getRandom(2, 5);
    var totalCost = fruit1.cost * multiplier + fruit2.cost;
    problem.question = "<p>The cost of " + fruit1.weight + " kg of " + fruit1.name + "s is " + toPounds(fruit1.cost) + ".</p>";
    problem.question += "<p>The total cost of " + fruit1.weight * multiplier + " kg of " + fruit1.name + "s and ";
    problem.question += fruit2.weight + " kg of " + fruit2.name + "s is " + toPounds(totalCost) + ".</p>";
    problem.question += "<p>Work out the cost of 1 kg of " + fruit2.name + "s.</p>";
    problem.answer = "<p>" + fruit1.weight * multiplier + " kg of " + fruit1.name + "s costs " + toPounds(fruit1.cost) + " &#215; " + multiplier + " = " + toPounds(fruit1.cost * multiplier) + ".</p>";
    problem.answer += "<p>" + fruit2.weight + " kg of " + fruit2.name + "s costs " + toPounds(totalCost) + " - " + toPounds(fruit1.cost * multiplier) + " = " + toPounds(fruit2.cost) + ".</p>";
    problem.answer += "<p>1 kg of " + fruit2.name + "s costs " + toPounds(fruit2.price) + ".</p>";
    return problem;
}
function proportionalDivision() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = true;
    var noun = {};
    noun.name = itemPicker("small");
    noun.cost = 2 * getRandom(4, 29) + 1;
    noun.quantity = getRandom(5, 15);
    noun.newQuantity = noun.quantity + 1 + getRandom(1, 15);
    noun.total = toPounds(noun.cost * noun.quantity);
    noun.newTotal = toPounds(noun.cost * noun.newQuantity);
    problem.question = "<p>" + noun.quantity + " " + noun.name + "s costs " + noun.total + ".</p>";
    problem.question += "<p>Work out the cost of " + noun.newQuantity + " of these " + noun.name + "s.</p>";

    problem.answer = "<p>1 " + noun.name + " costs " + noun.total + " &divide; " + noun.quantity + " = " + toPounds(noun.cost) + ".</p>";
    problem.answer += "<p>So " + noun.newQuantity + " " + noun.name + "s will cost " + toPounds(noun.cost) + " &#215; " + noun.newQuantity + " = " + noun.newTotal + ".</p>";
    return problem;
}
function quadraticInequalities() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = false;
    switch (getRandom(0, 3)) {
        case 0:
            var sign = "&lt;";
            break;
        case 1:
            sign = "&le;";
            break;
        case 2:
            sign = "&gt;";
            break;
        case 3:
            sign = "&ge;";
            break;
    }
    var eq = {};
    eq.let = letterPicker();
    do {
        eq.r1 = getRandom(-12, 12);
        eq.r2 = getRandom(-12, 12);
    } while (Math.abs(eq.r1) == Math.abs(eq.r2) || (eq.r1 * eq.r2) == 0);
    eq.xTerm = fixTerm(eq.r1 + eq.r2, eq.let, false);
    eq.constant = fixTerm(eq.r1 * eq.r2, "", false);
    if (Math.random() < 0.5) {
        problem.question = "<p>Solve the inequality " + eq.let + "&sup2; " + eq.xTerm + " " + sign + " " + (-eq.constant) + ".</p>";
    } else {
        problem.question = "<p>Solve the inequality " + eq.let + "&sup2; " + sign + " " + fixTerm(-(eq.r1 + eq.r2), eq.let, true) + (fixTerm(-eq.r1 * eq.r2, "", false)) + ".</p>";
    }
    problem.answer = "<p>Rearranging gives " + eq.let + "&sup2; " + eq.xTerm + " " + eq.constant + " " + sign + " 0.</p>";
    problem.answer += "<p>Factorise to get (" + eq.let + fixTerm(Math.min(eq.r1, eq.r2), "", false) + ")(" + eq.let + fixTerm(Math.max(eq.r1, eq.r2), "", false) + ") " + sign + " 0.</p>";
    switch (sign) {
        case "&lt;":
            problem.answer += "<p>Therefore " + eq.let + " &gt; " + -Math.max(eq.r1, eq.r2) + " and " + eq.let + " &lt; " + -Math.min(eq.r1, eq.r2) + ".</p>";
            break;
        case "&le;":
            problem.answer += "<p>Therefore " + eq.let + " &ge; " + -Math.max(eq.r1, eq.r2) + " and " + eq.let + " &le; " + -Math.min(eq.r1, eq.r2) + ".</p>";
            break;
        case "&gt;":
            problem.answer += "<p>Therefore " + eq.let + " &lt; " + -Math.max(eq.r1, eq.r2) + " and " + eq.let + " &gt; " + -Math.min(eq.r1, eq.r2) + ".</p>";
            break;
        case "&ge;":
            problem.answer += "<p>Therefore " + eq.let + " &le; " + -Math.max(eq.r1, eq.r2) + " and " + eq.let + " &ge; " + -Math.min(eq.r1, eq.r2) + ".</p>";
            break;
    }
    return problem;
}
function cardCombinations() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "H";
    problem.calc = true;
    var x = getRandom(0, 100);
    var person1 = namePicker(x);
    var person2 = namePicker(x + 1);
    var person3 = namePicker(x + 2);
    var cards = getRandom(11, 49);
    problem.question = "<p>" + person1.name + " has " + cards + " cards.</p>";
    problem.question += "<p>Each card has a different symbol on it.</p>";
    problem.question += "<p>" + person1.name + " gives one card to " + person2.name + " and one card to " + person3.name + ".</p>";
    problem.question += "<p>In how many ways can " + person1.name + " do this?";
    problem.answer = "<p>There are " + cards + " &#215; " + (cards - 1) + " = " + (cards * (cards - 1)) + " possible ways.</p>";
    return problem;
}
function turningPoints() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = false;
    do {
        var a = 1;
        //if (Math.random() < 0.5) {
        //    a = -a;
        //}
        var b = getRandom(-10, 10);
        var c = getRandom(-10, 10);
    } while (b * b - 4 * a * c < 0 || b == 0);
    var d = b / 2;
    var e = c - d * d;

    var equation = fixTerm(a, "x&sup2;", true) + fixTerm(b, "x", false) + fixTerm(c, "", false);
    var squared = "(x " + fixTerm(d, "", false) + ")&sup2; " + fixTerm(e, "", false);
    problem.question = "<p>Find the coordinates of the turning point of f(x) = " + equation + ".</p>"
    problem.question += "<p>Work out the coordinates of any intercepts with the coordinate axes.</p>";
    problem.answer = "<p>f(0) = " + c + ", so the graph crosses the f(x) axis at (0, " + c + ").</p>";
    problem.answer += "<p>Completing the square gives f(x) = " + squared + " so ";
    problem.answer += "<p>the coordinates of the turning point (minimum) are (" + (-d) + ", " + e + ").</p>";
    problem.answer += "<p>The graph crosses the x axis when " + squared + " = 0.</p>";
    problem.answer += "<p>Solving gives x = " + fixTerm(-d, "", false) + " &plusmn;&radic;" + (-e) + ".</p>";
    problem.answer += "<p>The graph crosses the x axis at (" + fixTerm(-d, "", true) + "-&radic;" + (-e) + ", 0) and (" + fixTerm(-d, "", true) + "+&radic;" + (-e) + ", 0).</p>"
    return problem;
}
function boyGirlCombinations() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    var boys = getRandom(8, 16);
    var girls = getRandom(28, 34) - boys;
    var person = namePicker();
    var bgb = boys * girls * (boys - 1);
    var gbg = girls * boys * (girls - 1);
    problem.question = "<p>There are " + boys + " boys and " + girls + " girls in " + person.name + "'s class.</p>";
    problem.question += "<p>" + person.name + " is going to pick three different students from " + person.owner + " class and write their names in a list in order.</p>";
    problem.question += "<p>The order will be boy, girl, boy or girl, boy, girl.</p>"
    problem.question += "<p>How many different lists can " + person.name + " write?</p>";
    problem.answer = "<p>Total 'boy, girl, boy' lists is " + boys + " &#215; " + girls + " &#215; (" + boys + " - 1) = " + bgb + ".</p>";
    problem.answer += "<p>Total 'girl, boy, girl' lists is " + girls + " &#215; " + boys + " &#215; (" + girls + " - 1) = " + gbg + ".</p>";
    problem.answer += "<p>In total " + person.name + " can write " + bgb + " + " + gbg + " = " + (bgb + gbg) + " different lists.</p>"
    return problem;
}
function gardenSlugs() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    var choice = new Array("slugs", "snails", "bees", "caterpillars", "butterflies", "ladybirds", "wasps");
    var creature = choice[getRandom(0, choice.length - 1)];
    var letter = creature.charAt(0);
    var p = [];
    p[0] = 10 * getRandom(5, 20);
    var multiplier = roundError(1 + getRandom(3, 15) / 100);
    var days = getRandom(3, 6);
    problem.answer = "<ul>";
    for (var i = 0; i <= days; i++) {
        p[i + 1] = p[i] * multiplier;
        problem.answer += "<li>" + letter + "<sub>" + i + "</sub> = " + Math.round(10000 * p[i]) / 10000 + "</li>";
    }
    problem.question = "<p>The number of " + creature + " in a garden t days from now is " + letter + "<sub>t</sub> where:</p>";
    problem.question += "<p>" + letter + "<sub>0</sub> = " + p[0] + " and ";
    problem.question += "" + letter + "<sub>t + 1</sub> = " + multiplier + "" + letter + "<sub>t</sub>.</p>";
    problem.question += "<p>Work out the number of " + creature + " in the garden " + days + " days from now.</p>";
    problem.answer += "</ul><p>After " + days + " days there will be " + Math.round(p[i - 1]) + " " + creature + " in the garden.</p>";
    return problem;
}
function reverseProbabilityWithRatio() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = false;
    var person1 = namePicker();
    var colour1 = colourPicker();
    do {
        var person2 = namePicker();
        var colour2 = colourPicker();
    } while (person2.name == person1.name || colour1 == colour2);
    var c1 = getRandom(5, 25);
    var multiplier = getRandom(2, 5);
    var c2 = c1 * multiplier;
    var total = c1 + c2;
    var num = c1 * (c1 - 1);
    var den = total * (total - 1);
    var hcf = HCF(num, den);
    num /= hcf;
    den /= hcf;
    problem.question = "<p>" + person1.name + " puts some " + colour1 + " counters and some " + colour2 + " counters into an empty box.</p>";
    problem.question += "<p>The ratio of the number of " + colour1 + " counters to the number of " + colour2 + " counters is 1:" + multiplier + ".</p>";
    problem.question += "<p>" + person2.name + " takes at random 2 counters from the box.</p>";
    problem.question += "<p>The probability that " + person2.subject + " takes 2 " + colour1 + " counters is <sup>" + num + "</sup>&frasl;<sub>" + den + "</sub>.</p>";
    problem.question += "<p>How many counters of each colour did " + person1.name + " put into the box?</p>";
    problem.answer = "<p>If there are x " + colour1 + " counters there must be " + multiplier + "x " + colour2 + " counters.</p>";
    problem.answer += "<p><sup>1</sup>&frasl;<sub>" + (multiplier + 1) + "</sub> &#215; <sup>(x - 1)</sup>&frasl;<sub>(" + (multiplier + 1) + "x - 1)</sub> = <sup>" + num + "</sup>&frasl;<sub>" + den + "</sub>.</p>";
    problem.answer += "<p>" + den + "(x - 1) = " + (multiplier + 1) * num + "(" + (multiplier + 1) + "x - 1).</p>";
    problem.answer += "<p>Solving gives x = " + c1 + ".</p>";
    problem.answer += "<p>" + c1 + " " + colour1 + " and " + c2 + " " + colour2 + " counters were put into the box.</p>";
    return problem;
}
function railcardDiscounts() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F";
    problem.calc = false;
    var city = new Array("Leeds", "Sheffield", "Kettering", "London", "Bristol");
    var location = city[getRandom(0, city.length - 1)];
    var children = getRandom(2, 4);
    do {
        var adultPrice = 2 * getRandom(10, 30);
        var adultDecrease = getRandom(3, 6);
    } while (adultPrice % adultDecrease != 0);
    var reducedAdult = adultPrice - (adultPrice / adultDecrease);
    var childPrice = (adultPrice / 2);
    var childDecrease = 10 * getRandom(2, 6);
    var reducedChild = roundError(childPrice * (100 - childDecrease) / 100).toFixed(2);
    var total = reducedAdult + (children * reducedChild);
    var person = namePicker();
    problem.question = "<p>" + person.name + " and " + person.owner + " " + children + " children are going to " + location + " by train.</p>";
    problem.question += "<p>An adult ticket costs &pound;" + adultPrice + " and a child ticket costs &pound;" + childPrice + ".</p>";
    problem.question += "<p>" + person.name + " has a family railcard which gives <sup>1</sup>&frasl;<sub>" + adultDecrease + "</sub> off adult tickets and " + childDecrease + "% off child tickets.</p>"
    problem.question += "<p>Work out the total cost of the tickets when " + person.name + " uses " + person.owner + " family railcard.</p>";
    problem.answer = "<p><sup>1</sup>&frasl;<sub>" + adultDecrease + "</sub> of &pound;" + adultPrice + " is &pound;" + adultPrice / adultDecrease;
    problem.answer += " so an adult ticket costs &pound;" + adultPrice + " - &pound;" + adultPrice / adultDecrease + " = &pound;" + reducedAdult + ".</p>";
    problem.answer += "<p>" + childDecrease + "% of &pound;" + childPrice + " is &pound;" + roundError(childPrice * (childDecrease / 100)).toFixed(2);
    problem.answer += " so a child ticket costs &pound;" + childPrice + " - &pound;" + roundError(childPrice * (childDecrease / 100)).toFixed(2) + " = &pound;" + reducedChild + ".</p>";
    problem.answer += "<p>The total cost of the tickets is &pound;" + reducedAdult + " + (" + children + " &#215; &pound;" + reducedChild + ") = &pound;" + total.toFixed(2) + ".</p>";
    return problem;
}
function orderingFDPCalc() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = true;
    var descending = false;
    if (Math.random() < 0.5) {
        descending = true;
    }
    var numberList = [];
    var totalNumbers = getRandom(4, 6);
    var base = getRandom(20, 80);
    problem.question = "<p>Here are " + totalNumbers + " numbers.</p><p>";
    for (var i = 0; i < totalNumbers; i++) {
        numberList.push((base + getRandom(-5, 5)) / 100);
        switch (getRandom(0, 3)) {
            case 0:
                problem.question += "" + numberList[i];
                break;
            case 1:
                problem.question += "" + toPercentage(numberList[i]);
                break;
            default:
                problem.question += "" + toFraction(numberList[i]);
                break;
        }
        if (i < totalNumbers) {
            problem.question += ", ";
        }
    }
    problem.question += "</p><p>Write these numbers in ";
    if (descending) {
        problem.question += "descending";
    } else {
        problem.question += "ascending";
    }
    problem.question += " order of size.</p>";
    if (descending) {
        numberList.sort(function (a, b) {
            return b - a;
        });
    } else {
        numberList.sort(function (a, b) {
            return a - b;
        });
    }
    problem.answer = "<p>" + numberList + ".</p>";
    return problem;
}
function exchangeRates() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = true;
    var firstYear = 2000 + getRandom(0, 13);
    var secondYear = firstYear + getRandom(1, 3);
    var ex1 = roundError(1 + getRandom(20, 50) / 100);
    do {
        var ex2 = roundError(1 + getRandom(15, 60) / 100)
    } while (ex1 == ex2);
    var amount = 100 * getRandom(2, 15);
    var euroAmount = amount * ex1;
    var amount2 = euroAmount / ex2;
    var person = namePicker();
    problem.question = "<p>" + person.name + " travels from the UK to France every year.</p>";
    problem.question += "<p>In " + firstYear + ", the exchange rate was &pound;1 = " + ex1 + "&euro;.</p>";
    problem.question += "<p>In " + secondYear + ", the exchange rate was &pound;1 = " + ex2 + "&euro;.</p>";
    problem.question += "<p>In " + firstYear + " " + person.name + " changed &pound;" + amount + " into euros.</p>";
    problem.question += "<p>How many pounds did " + person.name + " have to change in " + secondYear + " to get the same number of euros as " + person.subject + " did in " + firstYear + "?</p>";
    problem.answer = "<p>Total euros in " + firstYear + " was " + amount + " &#215; " + ex1 + " = " + euroAmount.toFixed(2) + "&euro;.</p>";
    problem.answer += "<p>Total pounds needed in " + secondYear + " was " + euroAmount.toFixed(2) + " &divide " + ex2 + " = &pound;" + amount2.toFixed(2) + ".</p>";
    return problem;
}
function sowingSeeds() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "FH";
    problem.calc = false;
    var person = namePicker();
    var seeds = 50 * getRandom(2, 15);
    var probability = getRandom(1, 9) / 10;
    var germinate = roundError(seeds * probability);
    problem.question = "<p>" + person.name + " sows " + seeds + " seeds.</p>";
    problem.question += "<p>The probability of a seed germinating is ";
    switch (getRandom(0, 2)) {
        case 0:
            problem.question += probability;
            break;
        case 1:
            problem.question += toPercentage(probability);
            break;
        case 2:
            problem.question += toFraction(probability);
            break;
    }
    problem.question += ".</p>";
    problem.question += "<p>Work out an estimate for the number of seeds that will germinate.</p>";
    problem.answer = "<p>" + seeds + " &#215; " + probability + " = " + germinate + "</p>";
    problem.answer += "<p>" + germinate + " seeds are estimated to  germinate.</p>";
    return problem;
}
function fibonacciAlgebra() {
    var problem = {};
    problem.marks = 6;
    problem.tier = "H";
    problem.calc = false;
    var x = {};
    var y = {};
    var rnd = getRandom(0, 50);
    x.letter = letterPicker(rnd);
    y.letter = letterPicker(rnd + 1);
    x.initial = getRandom(1, 5);
    y.initial = getRandom(1, 5);
    var t1 = {};
    var t2 = {}
    t1.pos = getRandom(3, 5);
    t2.pos = t1.pos + getRandom(2, 4);
    var fib = [];
    fib.push(1);
    fib.push(1);
    var totalTerms = getRandom(6, 12);
    var shownTerms = Math.round(totalTerms / 2);
    for (var i = 0; i < Math.max(totalTerms, t2.pos); i++) {
        fib.push(fib[i] + fib[i + 1]);
    }
    t1.value = fib[t1.pos - 1] * x.initial + fib[t1.pos] * y.initial;
    t2.value = fib[t2.pos - 1] * x.initial + fib[t2.pos] * y.initial;
    problem.question = "<p>Here are the first " + wordedNumber(shownTerms) + " terms of a Fibonacci sequence:</p>";
    problem.question += "<p>";
    for (i = 0; i < shownTerms; i++) {
        problem.question += fib[i] + ", ";
    }
    problem.question += " ...</p>";
    problem.question += "<p>In a Fibonacci sequence, the next term is the sum of the two previous terms.</p>";
    problem.question += "<p>a) Find the " + totalTerms + ordinal(totalTerms) + " term of this sequence.</p>";
    problem.question += "<p>The first three terms of a different Fibonacci sequence are " + x.letter + ", " + y.letter + ", " + x.letter + " + " + y.letter + ".</p>";
    problem.question += "<p>b) Show that the " + t2.pos + ordinal(t2.pos) + " term of this sequence is " + fib[t2.pos - 3] + x.letter + " + " + fib[t2.pos - 2] + y.letter + ".</p>";
    problem.question += "<p>c) Given that the " + t1.pos + ordinal(t1.pos) + " term is " + t1.value;
    problem.question += " and the " + t2.pos + ordinal(t2.pos) + " term is " + t2.value + ", find the value of " + x.letter + " and " + y.letter + ".</p>";
    problem.answer = "<p>a) ";
    for (i = 0; i < totalTerms; i++) {
        problem.answer += fib[i] + ", ";
    }
    problem.answer += "...</p>";
    problem.answer += "<ul>";
    problem.answer += "<li>1st term is 1" + x.letter + " + 0" + y.letter + "</li>";
    problem.answer += "<li>2nd term is 0" + x.letter + " + 1" + y.letter + "</li>";
    for (i = 0; i < t2.pos - 2; i++) {
        problem.answer += "<li>" + (i + 3) + ordinal(i + 2) + " term is " + fib[i] + x.letter + " + " + fib[i + 1] + y.letter + "</li>";
    }
    problem.answer += "</ul>";
    problem.answer += "<p>c) We have a pair a simultaneous equations:</p>";
    problem.answer += "<p> " + fib[t1.pos - 3] + x.letter + " + " + fib[t1.pos - 2] + y.letter + " = " + t1.value + "</p>";
    problem.answer += "<p> " + fib[t2.pos - 3] + x.letter + " + " + fib[t2.pos - 2] + y.letter + " = " + t2.value + "</p>";
    problem.answer += "<p>Solving these gives " + x.letter + " = " + (x.initial + y.initial) + " and " + y.letter + " = " + (x.initial + 2 * y.initial) + "</p>";
    return problem;
}
function probabilityPercentages() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    var places = new Array("nursery", "school", "party", "museum", "theme park", "cinema");
    var location = places[getRandom(0, places.length - 1)];
    var boys = 5 * getRandom(3, 18);
    var girls = 100 - boys;
    var carBoys = 5 * getRandom(3, 18);
    var carGirls = 5 * getRandom(3, 18);
    problem.question = "<p>Some of the children at a " + location + " arrive by car.</p>";
    problem.question += "<ul>";
    problem.question += "<li>" + boys + "% of the children at the " + location + " are boys.</li>"
    problem.question += "<li>" + carBoys + "% of the boys at the " + location + " arrive by car.</li>"
    problem.question += "<li>" + carGirls + "% of the girls at the " + location + " arrive by car.</li>"
    problem.question += "</ul>";
    problem.question += "<p>What is the probability that a child chosen at random arrives at the " + location + " by car?</p>";
    problem.answer = "<p>P(boy arrives by car) = " + boys / 100 + " &#215; " + carBoys / 100 + " = " + boys * carBoys / 100 + "%.</p>";
    problem.answer += "<p>P(girl arrives by car) = " + girls / 100 + " &#215; " + carGirls / 100 + " = " + girls * carGirls / 100 + "%.</p>";
    problem.answer += "<p>P(child arrives by car) = " + boys * carBoys / 100 + "% + " + girls * carGirls / 100 + "% = " + (boys * carBoys + girls * carGirls) / 100 + "%.</p>";
    return problem;
}
function concreteRatio() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = false;
    var cement = {};
    var sand = {};
    var gravel = {};
    var enough = true;
    cement.parts = getRandom(1, 2);
    sand.parts = getRandom(2, 4);
    gravel.parts = getRandom(3, 5);
    if (sand.parts == gravel.parts) {
        cement.parts = 1;
    }
    var parts = cement.parts + sand.parts + gravel.parts;
    var amount = parts * 5 * getRandom(5, 15);
    var amountPerPart = amount / parts;
    cement.required = amountPerPart * cement.parts;
    cement.owned = cement.required + 5 * getRandom(-2, 5);
    sand.required = amountPerPart * sand.parts;
    sand.owned = sand.required + 5 * getRandom(-2, 5);
    gravel.required = amountPerPart * gravel.parts;
    gravel.owned = gravel.required + 5 * getRandom(-2, 5);
    var person = namePicker();
    problem.question = "<p>" + person.name + " is going to make up some concrete by mixing cement, sand and gravel in the ratio " + cement.parts + ":" + sand.parts + ":" + gravel.parts + ".</p>";
    problem.question += "<p>" + person.name + " wants to make " + amount + " kg of concrete mix.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " has " + cement.owned + " kg of cement, " + sand.owned + " kg of sand and " + gravel.owned + " kg of gravel.</p>";
    problem.question += "<p>Does " + person.name + " have enough materials to make the concrete mix?</p>";

    problem.answer = "<p>The concrete is made from " + cement.parts + " + " + sand.parts + " + " + gravel.parts + " = " + parts + " parts.</p>";
    problem.answer += "<p>" + amount + " kg &divide; " + parts + " = " + amountPerPart + " kg per part.</p>";
    problem.answer += "<p>Cement needed: " + cement.parts + " &#215; " + amountPerPart + " = " + cement.required + " kg ";
    if (cement.owned >= cement.required) {
        problem.answer += "(enough.)";
    } else {
        problem.answer += "(not enough.)";
        enough = false;
    }
    problem.answer += "</p>";
    problem.answer += "<p>Sand needed: " + sand.parts + " &#215; " + amountPerPart + " = " + sand.required + " kg ";
    if (sand.owned >= sand.required) {
        problem.answer += "(enough.)";
    } else {
        problem.answer += "(not enough.)";
        enough = false;
    }
    problem.answer += "</p>";
    problem.answer += "<p>Gravel needed: " + gravel.parts + " &#215; " + amountPerPart + " = " + gravel.required + " kg ";
    if (gravel.owned >= gravel.required) {
        problem.answer += "(enough.)";
    } else {
        problem.answer += "(not enough.)";
        enough = false;
    }
    problem.answer += "</p>";
    if (enough) {
        problem.answer += "<p>Yes, " + person.name + " has enough materials.</p>";
    } else {
        problem.answer += "<p>No, " + person.name + " does not have enough materials.</p>";
    }
    return problem;
}
function sharingRatioWithPercentages() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = true;
    var ratio = {};
    ratio.a = getRandom(1, 5);
    ratio.b = getRandom(1, 5);
    ratio.c = ratio.a + getRandom(2, 5);
    var share = getRandom(20, 60);
    var p1 = namePicker();
    do {
        var p2 = namePicker();
        var p3 = namePicker();
    } while (p1.name == p2.name || p1.name == p3.name || p2.name == p3.name);
    p1.share = share * ratio.a;
    p2.share = share * ratio.b;
    p3.share = share * ratio.c;
    var total = p1.share + p2.share + p3.share;
    problem.question = "<p>" + p1.name + ", " + p2.name + " and " + p3.name + " share &pound;" + total + ".</p>";
    problem.question += "<p>The ratio of the amount of money " + p1.name + " gets to the amount of money " + p3.name + " gets is " + ratio.a + ":" + ratio.c + ".</p>";
    problem.question += "<p>" + p1.name + " gets &pound;" + parseInt(p3.share - p1.share) + " less than " + p3.name + " gets.</p>";
    problem.question += "<p>What percentage of the &pound;" + total + " does " + p2.name + " get?</p>";
    problem.answer = "<p>&pound;" + parseInt(p3.share - p1.share) + " is worth " + ratio.c + " - " + ratio.a + " = " + parseInt(ratio.c - ratio.a) + " parts.</p>";
    problem.answer += "<p>So 1 part is worth &pound;" + parseInt(p3.share - p1.share) + " &divide " + parseInt(ratio.c - ratio.a) + " = &pound;" + share + ".</p>";
    problem.answer += "<p>" + p1.name + "'s share is " + share + " &#215; " + ratio.a + " = &pound;" + p1.share + ".</p>";
    problem.answer += "<p>" + p3.name + "'s share is " + share + " &#215; " + ratio.c + " = &pound;" + p3.share + ".</p>";
    problem.answer += "<p>" + p2.name + "'s share is " + total + " - (" + p1.share + " + " + p3.share + ") = &pound;" + p2.share + ".</p>";
    problem.answer += "<p>(" + p2.share + " &divide " + total + ") &#215; 100 = " + Math.round(p2.share / total * 1000) / 10 + "%.</p>";
    return problem;
}
function proportionalRelationships() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    var rate = getRandom(2, 9);
    var machines = getRandom(3, 9);
    var days = getRandom(2, 9);
    do {
        var dayScalar = getRandom(2, 9);
    } while (days == dayScalar);

    var unitScalar = rate * dayScalar * getRandom(5, 30);
    problem.question = "<p>" + machines + " machines in a factory can produce " + rate * machines * days + " units in " + days + " days.</p>";
    problem.question += "<p>If the machines all work at the same rate, how many machines are needed to produce " + unitScalar + " units in " + dayScalar + " days?</p>";
    problem.answer = "<p>" + machines + " machines can produce " + rate * machines + " units in 1 day.</p>";
    problem.answer += "<p>1 machine can produce " + rate + " units in 1 day.</p>";
    problem.answer += "<p>" + unitScalar / rate + " machines can produce " + unitScalar + " units in 1 day.</p>";
    problem.answer += "<p>" + unitScalar / rate / dayScalar + " machines can produce " + unitScalar + " units in " + dayScalar + " days.</p>";
    return problem;
}
function combiningRatios() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = false;
    var seed = getRandom(0, 100);
    var x = letterPicker(seed);
    var y = letterPicker(seed + 1);
    var z = letterPicker(seed + 2);
    var a = getRandom(1, 10);
    var c = getRandom(1, 10);
    do {
        var b = getRandom(1, 10);
        var d = getRandom(1, 10);
    } while (a == b || c == d);
    problem.question = "<p>Given that " + x + " : " + y + " = " + a + " : " + b + " and " + y + " : " + z + " = " + c + " : " + d + ".</p>";
    problem.question += "<p>Find the ratio " + x + " : " + y + " : " + z + ".<p>";
    problem.question += "<p>Give your answer in its simplest form.<p>";
    problem.answer = "<p>" + a + " &#215 " + c + " : " + b + " &#215; " + c + " = " + a * c + " : " + b * c + ".</p>";
    problem.answer += "<p>" + b + " &#215 " + c + " : " + b + " &#215; " + d + " = " + b * c + " : " + b * d + ".</p>";
    problem.answer += "<p>So " + x + " : " + y + " : " + z + " = " + a * c + " : " + b * c + " : " + b * d + ".</p>";
    var hcf = HCF(HCF(a * c, b * c), b * d);
    if (hcf != 1) {
        problem.answer += "<p>This simplifies to " + a * c / hcf + " : " + b * c / hcf + " : " + b * d / hcf + ".</p>";
    }
    return problem;
}
function dimensionalScaleFactors() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    var a = {};
    var b = {};
    var temp = getRandom(0, 24);
    a.let = letterPicker(temp, 1);
    b.let = letterPicker(temp + 1, 1);
    a.lengthSF = getRandom(2, 5);
    do {
        b.lengthSF = getRandom(2, 5);
    } while (a.lengthSF == b.lengthSF);
    a.areaSF = a.lengthSF * a.lengthSF;
    b.areaSF = b.lengthSF * b.lengthSF;
    a.volumeSF = a.areaSF * a.lengthSF;
    b.volumeSF = b.areaSF * b.lengthSF;
    var multiplier = getRandom(5, 15);
    a.volume = a.volumeSF * multiplier;
    b.volume = b.volumeSF * multiplier;
    problem.question = "<p>Solid " + a.let + " and solid " + b.let + " are mathematically similar.</p>";
    problem.question += "<p>The ratio of the surface area of solid " + a.let + " to the surface area of solid ";
    problem.question += b.let + " is " + a.areaSF + ":" + b.areaSF + ".</p>";
    problem.question += "<p>The volume of solid " + b.let + " is " + b.volume + " cm&sup3.</p>";
    problem.question += "<p>What is the volume of solid " + a.let + "?</p>";
    problem.answer = "<p>Length scale factors are in the ratio " + a.lengthSF + ":" + b.lengthSF + ".</p>";
    problem.answer += "<p>Volume scale factors are in the ratio " + a.volumeSF + ":" + b.volumeSF + ".</p>";
    problem.answer += "<p>" + b.volume + " &divide; " + b.volumeSF + " = " + multiplier + ".</p>";
    problem.answer += "<p>Volume of solid " + a.let + " is " + multiplier + " &#215; " + a.volumeSF + " = " + a.volume + " cm&sup3.</p>";
    return problem;
}
function factorisingDiffOfTwoSquares() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "H";
    problem.calc = false;
    var multiplier = getRandom(2, 6);
    var square1 = getRandom(2, 5);
    do {
        var square2 = getRandom(2, 5);
    } while (square1 == square2);
    var temp = getRandom(0, 25);
    var letter1 = letterPicker(temp);
    var letter2 = letterPicker(temp + 1);
    switch (getRandom(0, 2)) {
        case 0:
            var expression = multiplier * square1 * square1 + letter1 + "&sup2; - " + multiplier * square2 * square2 + letter2 + "&sup2";
            problem.answer = "<p>" + expression + " = " + multiplier + "(" + square1 * square1 + letter1 + "&sup2; - " + square2 * square2 + letter2 + "&sup2)</p>";
            problem.answer += "<p>Factorising using difference of two squares gives: " + multiplier + "(" + square1 + letter1 + " + " + square2 + letter2 + ")(" + square1 + letter1 + " - " + square2 + letter2 + ").</p>";
            break;
        case 1:
            expression = multiplier * square1 * square1 + letter1 + "&sup2; - " + multiplier * square2 * square2;
            problem.answer = "<p>" + expression + " = " + multiplier + "(" + square1 * square1 + letter1 + "&sup2; - " + square2 * square2 + ")</p>";
            problem.answer += "<p>Factorising using difference of two squares gives: " + multiplier + "(" + square1 + letter1 + " + " + square2 + ")(" + square1 + letter1 + " - " + square2 + ").</p>";
            break;
        case 2:
            var expression = multiplier * square1 * square1 + " - " + multiplier * square2 * square2 + letter2 + "&sup2";
            problem.answer = "<p>" + expression + " = " + multiplier + "(" + square1 * square1 + " - " + square2 * square2 + letter2 + "&sup2)</p>";
            problem.answer += "<p>Factorising using difference of two squares gives: " + multiplier + "(" + square1 + " + " + square2 + letter2 + ")(" + square1 + " - " + square2 + letter2 + ").</p>";
            break;
    }
    problem.question = "<p>Factorise fully: " + expression + ".</p>";
    return problem;
}
function maxItemsSameQuantity() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = true;
    problem.question = "<table><tr><th>Item</th><th>Price &pound;</th></tr>";
    var person = namePicker();
    var totalObjects = getRandom(3, 5);
    var seed = getRandom(0, 100);
    var item = [];
    for (var i = 0; i < totalObjects; i++) {
        item[i] = {};
        item[i].name = itemPicker("small", seed + i);
        item[i].price = getRandom(5, 50) / 100;
        problem.question += "<tr><td>" + capitalFirst(item[i].name) + "</td><td>" + (item[i].price).toFixed(2) + "</td></tr>";
    }
    problem.question += "</table>";
    var choice1 = getRandom(0, totalObjects - 1);
    do {
        var choice2 = getRandom(0, totalObjects - 1);
    } while (choice2 === choice1);
    var total = 5 * getRandom(1, 5);
    var combined = item[choice1].price + item[choice2].price;

    problem.question += "<p>" + person.name + " has &pound;" + total + " to spend on " + item[choice1].name + "s and " + item[choice2].name + "s.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " has to buy the same number of " + item[choice1].name + "s as " + item[choice2].name + "s.</p>";
    problem.question += "<p>What is the greatest number of " + item[choice1].name + "s " + person.subject + " can buy?</p>";
    problem.answer = "<p>The total cost of a " + item[choice1].name + " and a " + item[choice2].name + " is ";
    problem.answer += "&pound;" + item[choice1].price.toFixed(2) + " + &pound;" + item[choice2].price.toFixed(2) + " = ";
    problem.answer += "&pound;" + (combined).toFixed(2) + "</p>";
    problem.answer += "<p>&pound;" + total + " &divide &pound;" + (combined).toFixed(2) + " = " + Math.round(1000000 * total / combined) / 1000000 + "</p>";
    problem.answer += "<p>" + person.name + " can buy " + Math.floor(total / combined) + " " + item[choice1].name + "s.</p>";
    return problem;
}
function algebraPolygonPerimeter() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    var polygon = polygonPicker(getRandom(5, 8));
    var unit = unitPicker("length");
    var letter = letterPicker();
    var co = getRandom(1, 10);
    var side = fixTerm(co, letter, true);
    problem.question = "<p>A regular " + polygon.name + " has a side length of " + side + " " + unit + ".</p>";
    problem.question += "<p>Write down an expression for the perimeter of the " + polygon.name + ".</p>";
    problem.answer = "<p>The regular " + polygon.name + " has " + polygon.sides + " sides of " + side + " " + unit + ".</p>"
    problem.answer += "<p>Its perimeter is therefore " + polygon.sides + " &#215; " + side + " = " + fixTerm(polygon.sides * co, letter, true) + " " + unit + ".</p>";
    return problem;
}
function oddEvenAlgebra() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = false;
    var n = getRandom(10, 30);
    problem.question = "<p>a) Write down the " + n + ordinal(n) + " positive odd number.</p>";
    problem.answer = "<p>a) The " + n + ordinal(n) + " positive odd number is " + (2 * n - 1) + ".</p>";
    if (Math.random() < 0.5) {
        var type = "even";
        var seed = 2 * getRandom(10, 30);
    } else {
        var type = "odd";
        var seed = 2 * getRandom(10, 30) - 1;
    }
    var sum = seed + seed + 2;
    var size = "smaller";
    if (Math.random() < 0.5) {
        size = "larger";
    }
    problem.question += "<p>The sum of two consecutive " + type + " numbers is " + sum + ".</p>";
    problem.question += "<p>b) Find the " + size + " of these two " + type + " numbers.</p>";
    problem.answer += "b) Let x be the 1st number, then x + 2 is the next consectutive " + type + " number.</p>";
    problem.answer += "<p>x + x + 2 = " + sum + ".</p>";
    problem.answer += "<p>2x + 2 = " + sum + ".</p>";
    problem.answer += "<p>2x = " + (sum - 2) + ".</p>";
    problem.answer += "<p>x = " + seed + ".</p>";
    if (size == "smaller") {
        problem.answer += "<p>The smaller number is " + seed + ".</p>";
    } else {
        problem.answer += "<p>The larger number is " + (seed + 2) + ".</p>";
    }
    return problem;
}
function linearSequences() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F/H";
    problem.calc = true;
    do {
        var a = getRandom(-10, 10);
        var d = getRandom(-15, 15);
    } while (Math.abs(a) < 2 || d === 0);
    var terms = getRandom(4, 6);
    var sequence = [];
    for (var i = 0; i < terms; i++) {
        sequence.push(a * (i + 1) + d);
    }
    var checkNumber = a * getRandom(10, 25) + d + getRandom(0, 1);
    var n = (checkNumber - d) / a;
    problem.question = "<p>Here are the first " + wordedNumber(terms) + " terms of an arithmetic sequence.</p>";
    problem.question += "<p>";
    for (i = 0; i < sequence.length - 1; i++) {
        problem.question += sequence[i] + ", ";
    }
    problem.question += sequence[i] + ", ...</p>";
    problem.question += "<p>a) Write down the nth term rule of the sequence.</p>";
    problem.question += "<p>b) Is " + checkNumber + " a term of this sequence?</p>";
    problem.question += "<p>Show how you get your answer.</p>";
    problem.answer = "<p>a) The common difference is " + a + ".</p>";
    problem.answer += "<p>The nth term rule is given by " + fixTerm(a, "n", true) + fixTerm(d, "", false) + ".</p>";
    problem.answer += "If " + checkNumber + " is in the sequence there is an integer value of n to satisfy " + fixTerm(a, "n", true) + fixTerm(d, "", false) + " = " + checkNumber + ".</p>";
    problem.answer += "<p>" + a + "n = " + (checkNumber - d) + ".</p>";
    problem.answer += "<p>n = " + Math.round(1000000 * n) / 1000000 + ".</p>";
    if (n === Math.round(n)) {
        problem.answer += "<p>Yes, " + checkNumber + " is in the sequence.</p>";
    } else {
        problem.answer += "<p>No, " + checkNumber + " is not in the sequence.</p>";
    }
    return problem;
}
function isoscelesAlgebra() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "F/H";
    problem.calc = false;
    var scalar = getRandom(2, 5);
    var letter = "x";
    var unit = unitPicker("length");
    var x = getRandom(2, 20);
    var bc = 2 * getRandom(4, 10);
    var perimeter = bc + 2 * (scalar * x);
    var side = "AC";
    if (Math.random() < 0.5) {
        side = "AB";
    }
    problem.question = "<img src='/media/gcseQuestions/64.jpg'>";
    problem.question += "<p>ABC is an isosceles triangle. All lengths are in " + unit + ".</p>";
    problem.question += "<p>" + side + " = " + scalar + letter + " and BC = " + bc + ".</p>";
    problem.question += "<p>The perimeter of the triangle is " + perimeter + " " + unit + ".</p>";
    problem.question += "<p>Find the value of " + letter + ".</p>";
    problem.answer = "<p>" + scalar + letter + " + " + scalar + letter + " + " + bc + " = " + perimeter + ".</p>";
    problem.answer += "<p>" + (2 * scalar) + letter + " + " + bc + " = " + perimeter + ".</p>";
    problem.answer += "<p>" + (2 * scalar) + letter + " = " + (perimeter - bc) + ".</p>";
    problem.answer += "<p>" + letter + " = " + x + " " + unit + ".</p>";
    return problem;
}
function algebraicTaxis() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F/H";
    problem.calc = true;
    var adj = new Array("Speedy", "Quick", "Rapid", "City", "Lightning", "Super", "Street", "Reliable", "Low-cost", "On-time");
    var seed = getRandom(0, adj.length - 3);
    var distance = 5 * getRandom(2, 10);
    var co = [];
    problem.question = "<p>The formulae below show the cost, &pound; C, of a taxi journey of x miles with three different companies.</p>";
    problem.answer = "";
    for (var i = 0; i < 3; i++) {
        co[i] = {};
        co[i].name = adj[seed + i] + " taxis";
        co[i].ppm = getRandom(100, 200) / 100;
        co[i].fixed = getRandom(1, 20) / 2;
        co[i].cost = distance * co[i].ppm + co[i].fixed;
        problem.question += "<p>" + co[i].name + ": C = " + fixTerm(co[i].ppm, "x", true) + " + " + co[i].fixed + ".</p>";
        problem.answer += "<p>" + co[i].name + " woul charge: " + co[i].ppm + "(" + distance + ") + " + co[i].fixed + " = &pound;" + co[i].cost.toFixed(2) + ".</p>";
    }
    problem.question += "<p>Which is the cheapest company to use for a journey of " + distance + " miles?</p>";
    problem.question += "<p>Show how you get your answer.</p>";
    var minCost = Math.min(co[0].cost, co[1].cost, co[2].cost);
    var cheapest = "";
    var unique = true;
    for (var i = 0; i < 3; i++) {
        if (co[i].cost === minCost) {
            if (unique) {
                cheapest += co[i].name;
                unique = false;
            } else {
                cheapest += " or " + co[i].name;
            }
        }
    }
    problem.answer += "<p>" + cheapest + " are the cheapest at &pound;" + minCost.toFixed(2) + ".</p>";
    return problem;
}
function numbersFromCards() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = true;
    var totalCards = getRandom(3, 6);
    var card = [];
    var even = true;
    var largest = true;
    if (Math.random() < 0.5) {
        even = false;
    }
    if (Math.random() < 0.5) {
        largest = false;
    }
    var allEven = true;
    var allOdd = true;
    while (allEven || allOdd) {
        allEven = true;
        allOdd = true;
        for (var i = 0; i < totalCards; i++) {
            card[i] = getRandom(1, 9);
            if (card[i] % 2 === 1) {
                allEven = false;
            } else {
                allOdd = false;
            }
        }
    }
    problem.question = "<p>Here are " + wordedNumber(totalCards) + " cards. There is a number on each card.</p>";
    problem.question += "<div>";
    for (var i = 0; i < totalCards; i++) {
        problem.question += "<span class='box'>" + card[i] + "</span>";
    }
    problem.question += "</div>";
    problem.question += "<p>a) Write down the ";
    if (largest) {
        problem.question += "largest";
    } else {
        problem.question += "smallest";
    }
    problem.question += " " + totalCards + "-digit number that can be made using each card only once.</p>";
    var ans1 = "";
    card.sort(function (a, b) {
        return b - a;
    });
    for (i = 0; i < totalCards; i++) {
        if (largest) {
            ans1 += card[i] + "";
        } else {
            ans1 += card[totalCards - i - 1] + "";
        }
    }
    largest = !largest;
    problem.question += "<p>b) Write down the ";
    if (largest) {
        problem.question += "largest";
    } else {
        problem.question += "smallest";
    }
    problem.question += " " + totalCards + "-digit ";
    if (even) {
        problem.question += "even";
    } else {
        problem.question += "odd";
    }
    problem.question += " number that can be made using each card only once.</p>";
    var ans2 = "";
    if (largest) {
        var temp = 10;
        for (i = 0; i < totalCards; i++) {
            if (even) {
                if (card[i] % 2 === 0 && card[i] < temp) {
                    temp = card[i];
                }
            } else {
                if (card[i] % 2 !== 0 && card[i] < temp) {
                    temp = card[i];
                }
            }
        }
    } else {
        temp = 0;
        for (i = 0; i < totalCards; i++) {
            if (even) {
                if (card[i] % 2 === 0 && card[i] > temp) {
                    temp = card[i];
                }
            } else {
                if (card[i] % 2 !== 0 && card[i] > temp) {
                    temp = card[i];
                }
            }
        }
    }
    card.splice(card.indexOf(temp), 1);
    card.sort(function (a, b) {
        if (largest) {
            return b - a;
        } else {
            return a - b;
        }
    });
    for (i = 0; i < card.length; i++) {
        ans2 += card[i] + "";
    }
    ans2 += temp;
    problem.answer = "<p>a) " + ans1 + ".</p>";
    problem.answer += "<p>b) " + ans2 + ".</p>";
    return problem;
}
function ratioDonatingShares() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var seed = getRandom(2, 10)
    var x = seed * getRandom(2, 8);
    do {
        var y = seed * getRandom(2, 8);
    } while (x === y);
    var hcf = HCF(x, y);
    var r1 = {};
    r1.x = x / hcf;
    r1.y = y / hcf;
    do {
        var donation = getRandom(1, x);
        var newX = x - donation;
        var newY = y + donation;
        hcf = HCF(newX, newY);
    } while (hcf < 2 || newX < 1);
    var r2 = {};
    r2.x = newX / hcf;
    r2.y = newY / hcf;
    var p1 = namePicker();
    do {
        var p2 = namePicker();
    } while (p1.name === p2.name);
    problem.question = "<p>The ratio of shares owned by " + p1.name + " and " + p2.name + " is in the ratio " + r1.x + " : " + r1.y + ".</p>";
    problem.question += "<p>If " + p1.name + " gives " + p2.name + " " + donation + " of " + p1.owner + " shares then the ratio will be " + r2.x + " : " + r2.y + ".</p>";
    problem.question += "<p>How many shares do they each have initially?</p>";
    problem.answer = "<p>Let x and y be the initial number of shares.</p>";
    problem.answer += "<p>" + r1.y + "x = " + r1.x + "y.</p>";
    problem.answer += "<p>" + r2.y + "(x - " + donation + ") = " + r2.x + "(y + " + donation + ").</p>";
    problem.answer += "<p>Solving these gives x = " + x + "  and y = " + y + ".</p>";
    return problem;
}
function functionSubAndSolve() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    var f = {};
    var g = {};
    do {
        f.m = -getRandom(1, 20) + getRandom(1, 20);
        f.c = -getRandom(1, 20) + getRandom(1, 20);
        g.m = -getRandom(1, 20) + getRandom(1, 20);
        g.c = -getRandom(1, 20) + getRandom(1, 20);
        var sol = (g.c - f.c) / (f.m - g.m);
    } while ((f.m - g.m) === 1 || f.m === 0 || g.m === 0 || f.m <= g.m || Math.round(100 * sol) / 100 !== sol);
    var x = getRandom(1, 25);
    var y = -getRandom(1, 25) / 2;
    f.func = fixTerm(f.m, "x", true) + fixTerm(f.c, "", false);
    g.func = fixTerm(g.m, "x", true) + fixTerm(g.c, "", false);
    problem.question = "<p>The functions f and g are such that f(x)=" + f.func + " and g(x)=" + g.func + ".</p>";
    problem.question += "<p>a) Find f(" + x + ").";
    problem.question += "<p>b) Find g(" + y + ").";
    problem.question += "<p>c) Solve f(x) = g(x).";
    problem.answer = "<p>a) f(" + x + ") = " + f.m + "(" + x + ")" + fixTerm(f.c, "", false) + " = " + (f.m * x + f.c) + ".</p>";
    problem.answer += "<p>b) g(" + y + ") = " + g.m + "(" + y + ")" + fixTerm(g.c, "", false) + " = " + (g.m * y + g.c) + ".</p>";
    problem.answer += "<p>c) " + f.func + " = " + g.func + ".</p>";
    problem.answer += "<p>" + (f.m - g.m) + "x = " + (g.c - f.c) + ".</p>";
    problem.answer += "<p>x = " + sol + ".</p>";
    return problem;
}
function compositeFunctions() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "H";
    problem.calc = true;
    var f = {};
    var g = {};
    var ff = {};
    var fg = {};
    do {
        f.m = -getRandom(1, 12) + getRandom(1, 12);
        f.c = -getRandom(1, 12) + getRandom(1, 12);
        g.m = -getRandom(1, 12) + getRandom(1, 12);
        g.c = -getRandom(1, 12) + getRandom(1, 12);
        fg.m = f.m * g.m;
        fg.c = f.m * g.c + f.c;
        ff.m = f.m * f.m;
        ff.c = f.m * f.c + f.c;
        var sol = (ff.c - fg.c) / (fg.m - ff.m)
    } while (f.m === 0 || g.m === 0 || f.m <= g.m || Math.round(100 * sol) / 100 !== sol);
    f.func = fixTerm(f.m, "x", true) + fixTerm(f.c, "", false);
    g.func = fixTerm(g.m, "x", true) + fixTerm(g.c, "", false);

    fg.func = fixTerm(fg.m, "x", true) + fixTerm(fg.c, "", false);
    ff.func = fixTerm(ff.m, "x", true) + fixTerm(ff.c, "", false);
    problem.question = "<p>The functions f and g are such that f(x)=" + f.func + " and g(x)=" + g.func + ".</p>";
    problem.question += "<p>a) Find fg(x).";
    problem.question += "<p>b) Find ff(x).";
    problem.question += "<p>c) Solve fg(x) = ff(x).";
    problem.answer = "<p>a) fg(x) = f(" + g.func + ").</p>";
    problem.answer += "<p>= " + f.m + "(" + g.func + ")" + fixTerm(f.c, "", false) + ".</p>";
    problem.answer += "<p>= " + fg.func + ".</p>";
    problem.answer += "<p>b) ff(x) = f(" + f.func + ")";
    problem.answer += "<p>= " + f.m + "(" + f.func + ")" + fixTerm(f.c, "", false) + ".</p>";
    problem.answer += "<p>= " + ff.func + ".</p>";
    problem.answer += "<p>c) " + fg.func + " = " + ff.func + ".</p>";
    problem.answer += "<p>" + (fg.m - ff.m) + "x = " + (ff.c - fg.c) + ".</p>";
    problem.answer += "<p>x = " + sol + ".</p>";
    return problem;
}
function inverseFunctions() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    var f = {};
    do {
        f.m = getRandom(2, 15);
        f.c = -getRandom(1, 20) + getRandom(1, 20);
        var sol = (-f.c - f.m * f.c) / (f.m * f.m - 1);
    } while (f.m === 0 || sol === 0 || Math.round(100 * sol) / 100 !== sol);
    f.func = fixTerm(f.m, "x", true) + fixTerm(f.c, "", false);
    f.inv = "<sup>(x" + fixTerm(-f.c, "", false) + ")</sup>&frasl;<sub>" + fixTerm(f.m, "", true) + "</sub>";
    problem.question = "<p>The function f is such that f(x)=" + f.func + ".</p>";
    problem.question += "<p>a) Find f<sup>-1</sup>(x).";
    problem.question += "<p>b) Solve f(x) = f<sup>-1</sup>(x).";
    problem.answer = "<p>a) f<sup>-1</sup>(x) = " + f.inv + ".</p>";
    problem.answer += "<p>b) " + f.func + " = " + f.inv + ".</p>";
    problem.answer += "<p>" + fixTerm(f.m * f.m, "x", true) + fixTerm(f.m * f.c, "", false) + " = x" + fixTerm(-f.c, "", false) + ".</p>";
    problem.answer += "<p>" + fixTerm(f.m * f.m - 1, "x", true) + " = " + fixTerm(-f.c - f.m * f.c, "", true) + ".</p>";
    problem.answer += "<p>x = " + sol + ".</p>";
    return problem;
}
function missingCardValuesUingMean() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = false;
    var mult = getRandom(2, 3);
    var totalCards = 4;
    var let = ["A", "B", "C", "D"];
    do {
        var d = getRandom(1, 20);
        var a = d * mult;
        var b = getRandom(1, 20);
        var c = b;
        var sum = a + b + c + d;
        var mean = sum / totalCards;
    } while (mean !== Math.round(mean));
    problem.question = "<p>Here are four cards.</p>";
    problem.question += "<div>";
    for (var i = 0; i < totalCards; i++) {
        problem.question += "<span class='box'>" + let[i] + "</span>";
    }
    problem.question += "</div>";
    problem.question += "<p>The mean of the " + wordedNumber(totalCards) + " is " + mean + ".</p>";
    problem.question += "<p>A, B and C add together to make " + (a + b + c) + ".</p>";
    if (mult === 2) {
        problem.question += "<p>A is twice the size of D.</p>";
    } else {
        problem.question += "<p>A is three times the size of D.</p>";
    }
    problem.question += "<p>The other two cards are the same number.</p>";
    problem.question += "<p>Find the value of each of the cards.</p>";
    problem.answer = "<p>The mean is " + mean + " so the four cards must sum to 4 &#215; " + mean + " = " + sum + ".</p>";
    problem.answer += "<p>D is " + sum + " - " + (a + b + c) + " = " + d + ".</p>";
    problem.answer += "A is " + mult + " &#215; " + d + " = " + a + ".</p>";
    problem.answer += "B and C sum to " + sum + " - (" + a + " + " + d + ") = " + (b + c) + ".</p>";
    problem.answer += "<p>So A = " + a + ", B = " + b + ", C = " + c + ", D = " + d + "</p>";
    return problem;
}
function equationOfPerpendicularsWithRatio() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "H";
    problem.calc = true;
    function Coordinate(x, y) {
        this.x = x;
        this.y = y;
    }
    do {
        var xShift = getRandom(1, 5);
        do {
            var yShift = getRandom(-5, 5);
        } while (yShift === 0);
        var hcf = HCF(xShift, yShift);
        xShift /= hcf;
        yShift /= hcf;
        var m = yShift / xShift;
        var p = -1 / m;
    } while (Math.abs(xShift) === Math.abs(yShift));
    var gradient = "<sup>" + yShift + "</sup>&frasl;<sub>" + xShift + "</sub>";
    if (yShift % xShift === 0) {
        gradient = yShift / xShift;
    }
    var perp = "<sup>" + -xShift + "</sup>&frasl;<sub>" + yShift + "</sub>";
    if (p > 0) {
        var perp = "<sup>" + Math.abs(xShift) + "</sup>&frasl;<sub>" + Math.abs(yShift) + "</sub>";
    }
    if (-xShift % yShift === 0) {
        perp = -xShift / yShift;
    }
    do {
        var a = new Coordinate(getRandom(-10, 10), getRandom(-10, 10));
        var step1 = getRandom(1, 5);
        do {
            var step2 = getRandom(1, 5);
        } while (step1 === step2);
        var b = new Coordinate(a.x + ((step1 + step2) * xShift), a.y + ((step1 + step2) * yShift));
        var mid = new Coordinate(a.x + (step1 * xShift), a.y + step1 * yShift);
        var c = mid.y - p * mid.x;
    } while (c !== Math.round(c))
    problem.question = "<p>Point A has coordinates (" + a.x + ", " + a.y + ").</p>";
    problem.question += "<p>Point B has coordinates (" + b.x + ", " + b.y + ").</p>";
    problem.question += "<p>M is the point on the line segment AB such that AM:MB = " + step1 + ":" + step2 + ".</p>";
    problem.question += "<p>Line L is perpendicular to the line segment AB and passes through M.</p>";
    problem.question += "<p>Find the equation of L.</p>";
    problem.answer = "<p>Gradient of AB is <sup>" + (b.y - a.y) + "</sup>&frasl;<sub>" + (b.x - a.x) + "</sub> = " + gradient + ".</p>";
    problem.answer += "<p>Gradient of L is " + perp + ".</p>";
    problem.answer += "<p>L is of the form y = " + perp + "x + c.</p>";
    problem.answer += "<p>M is the point (" + mid.x + ", " + mid.y + ").</p>";
    problem.answer += "<p>" + mid.y + " = " + perp + "(" + mid.x + ") + c.</p>";
    problem.answer += "<p>c = " + c + ".</p>";
    problem.answer += "<p>The equation of L is y = " + perp + "x";
    if (c < 0) {
        problem.answer += " - ";
    } else {
        problem.answer += " + ";
    }
    problem.answer += +Math.abs(c) + ".</p>";
    return problem;
}
function findingMidpointsWithRatio() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    function Coordinate(x, y) {
        this.x = x;
        this.y = y;
    }
    do {
        var xShift = getRandom(-3, 3);
        var yShift = getRandom(-3, 3);
    } while (xShift === 0 || yShift === 0 || Math.abs(xShift) === Math.abs(yShift));
    var a = new Coordinate(getRandom(-8, 8), getRandom(-8, 8));
    var step1 = getRandom(1, 4);
    do {
        var step2 = getRandom(1, 4);
    } while (step1 === step2);
    var b = new Coordinate(a.x + ((step1 + step2) * xShift), a.y + ((step1 + step2) * yShift));
    var mid = new Coordinate(a.x + (step1 * xShift), a.y + step1 * yShift);
    problem.question = "<p>M is the point on a line segment AB such that AM:MB = " + step1 + ":" + step2 + ".</p>";
    problem.answer = "<p>";
    for (var i = 0; i <= step1 + step2; i++) {
        if (i === 0) {
            problem.answer += "A";
        }
        if (i === step1) {
            problem.answer += "M";
        }
        if (i === step1 + step2) {
            problem.answer += "B";
        }
        problem.answer += "(" + (a.x + xShift * i) + ", " + (a.y + yShift * i) + "), ";
    }
    problem.answer = problem.answer.slice(0, -2);
    problem.answer += ".</p>";
    switch (getRandom(0, 2)) {
        case 0:
            problem.question += "<p>A is the point (" + a.x + ", " + a.y + ").</p>";
            problem.question += "<p>B is the point (" + b.x + ", " + b.y + ").</p>";
            problem.question += "<p>Find the coordinates of M.</p>";
            problem.answer += "<p>M is the point (" + mid.x + ", " + mid.y + ").</p>";
            break;
        case 1:
            problem.question += "<p>A is the point (" + a.x + ", " + a.y + ").</p>";
            problem.question += "<p>M is the point (" + mid.x + ", " + mid.y + ").</p>";
            problem.question += "<p>Find the coordinates of B.</p>";
            problem.answer += "<p>B is the point (" + b.x + ", " + b.y + ").</p>";
            break;
        case 2:
            problem.question += "<p>B is the point (" + b.x + ", " + b.y + ").</p>";
            problem.question += "<p>M is the point (" + mid.x + ", " + mid.y + ").</p>";
            problem.question += "<p>Find the coordinates of A.</p>";
            problem.answer += "<p>A is the point (" + a.x + ", " + a.y + ").</p>";
            break;
    }
    return problem;
}
function repeatedPercentageChangeInReverse() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    var choice = new Array("slugs", "snails", "bees", "caterpillars", "butterflies", "ladybirds", "wasps");
    var creature = choice[getRandom(0, choice.length - 1)];
    var years = getRandom(4, 15);
    var accuracy = getRandom(1, 3);
    var multiplier = Math.round(1000000 * Math.pow(0.5, 1 / years)) / 1000000;
    problem.question = "<p>The number of " + creature + " in a garden decreases by x% each year.</p>";
    problem.question += "<p>Given that the number of " + creature + " halves in " + years + " years, work out the value of x.</p>";
    problem.question += "<p>Give your answer correct to " + accuracy + " decimal place";
    if (accuracy > 1) {
        problem.question += "s";
    }
    problem.question += ".</p>";
    problem.answer = "<p>Let m be the percentage multiplier.</p>";
    problem.answer += "<p>100 &#215; m<sup>" + years + "</sup> = 50.</p>";
    problem.answer += "<p>m = <sub>" + years + "</sub>&radic;(<sup>50</sup>&frasl;<sub>100</sub>).</p>";
    problem.answer += "<p>As a decimal, x is given by 1 - " + multiplier + " = " + roundError(1 - multiplier) + ".</p>";
    problem.answer += "<p>x = " + roundError(100 * (1 - multiplier)).toFixed(accuracy) + "%.</p>";
    return problem;
}
function deliveringGoods() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = true;
    var person = namePicker();
    var time = roundError(getRandom(2, 6) + (getRandom(1, 3) * 25) / 100);
    var hours = Math.floor(time);
    var minutes = (time - hours) * 60;
    var before = getRandom(10001, 30000);
    var change = 5 * getRandom(15, 35);
    var after = before + change;
    var perHour = 2 * getRandom(20, 50) / 10;
    var perMile = getRandom(10, 40);
    var total = change * perMile / 100 + time * perHour;
    problem.question = "<p>" + person.name + " is going to deliver some goods.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " charges &pound;" + perHour.toFixed(2) + " per hour and " + perMile + "p per mile for delivery.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " writes down " + person.owner + " mileage before and after " + person.subject + " has made the journey.</p>";
    problem.question += "<table><tr><th>Before</th><th>After</th></tr>";
    problem.question += "<tr><td>" + before + "</td><td>" + after + "</td></tr></table>";
    problem.question += "<p>This journey takes " + hours + " hours and " + minutes + " minutes.</p>";
    problem.question += "<p>How much does " + person.subject + " charge to deliver these goods?</p>";
    problem.answer = "<p>(" + after + " - " + before + ") &#215; &pound;" + (perMile / 100).toFixed(2) + " = &pound;" + (change * perMile / 100).toFixed(2) + ".</p>";
    problem.answer += "<p>" + time + " hours &#215; &pound;" + perHour.toFixed(2) + " = &pound;" + (time * perHour).toFixed(2) + ".</p>";
    problem.answer += "<p>" + capitalFirst(person.owner) + " total charge for delivery is &pound;" + total.toFixed(2) + ".</p>";
    return problem;
}
function profitOnGoods() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    problem.question = "<p></p>";
    do {
        var original = 5 * getRandom(21, 49);
        var profit = 5 * getRandom(1, 8);
        var discount = 5 * getRandom(1, 8);
        var salePrice = roundError(original * (1 + profit / 100));
        var tagPrice = roundError(salePrice / ((100 - discount) / 100));
    } while (tagPrice !== Math.round(tagPrice));
    var item = itemPicker("large");
    var person = namePicker();
    problem.question = "<p>" + person.name + " buys a " + item + " for &pound" + original + ".</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " wants to put a tag with a price on the " + item + " so that in";
    problem.question += " the sale " + person.subject + " can give a discount of " + discount + "% off the price";
    problem.question += " on the tag and still make a profit of " + profit + "% on the price " + person.subject + " paid for the " + item + ".</p>";
    problem.question += "<p>Work out the price that " + person.name + " should put on the tag.</p>";
    problem.answer = "<p>" + capitalFirst(person.subject) + " needs to sell the " + item + " for " + original + " &#215 " + (1 + profit / 100) + " = &pound;" + salePrice + ".</p>";
    problem.answer += "<p>The tag price should be " + salePrice + " &divide; " + (100 - discount) / 100 + " = &pound;" + tagPrice + ".</p>";
    return problem;
}
function changingRatios() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = true;
    var p1 = getRandom(3, 6);
    var p2 = getRandom(1, p1 - 1);
    var parts = p1 + p2;
    do {
        var ml = 1000 * (parts + getRandom(4, 15));
    } while (ml % parts !== 0);
    var perPart = ml / parts;
    var person = namePicker();
    problem.question = "<p>" + person.name + " is mixing antifreeze and water.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " has " + ml / 1000 + " litres of a mixture of antifreeze and water in the ratio " + p1 + ":" + p2 + ".</p>";
    problem.question += "<p>How much water must " + person.subject + " add to make the ratio 1:1?</p>";
    problem.answer = "<p>" + ml / 1000 + " litres = " + ml + " millilitres.</p>";
    problem.answer += "<p>" + ml + " &divide; " + parts + " = " + perPart + " ml per part.</p>";
    problem.answer += "<p>The mixture is currently " + p1 * perPart + " ml antifreeze and " + p2 * perPart + " ml water.</p>";
    problem.answer += "<p>" + p1 * perPart + " - " + p2 * perPart + " = " + (p1 - p2) * perPart + ".</p>";
    problem.answer += "<p>" + (p1 - p2) * perPart + " ml of water are needed to make the ratio 1:1.</p>";
    return problem;
}
function estimatedProfit() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "FH";
    problem.calc = false;
    var sides = getRandom(3, 5);
    var prize1 = getRandom(5, 10);
    var prize2 = getRandom(1, 4);
    var outcomes = sides * 6;
    var p1 = 1 * 1;
    var p2 = 6 + sides - 1;
    var players = outcomes * getRandom(1, 4);
    var price = getRandom(1, 2);
    var person = namePicker();
    var choice = getRandom(1, sides - 1);
    var cost1 = prize1 * players * p1 / outcomes;
    var cost2 = prize2 * players * p2 / outcomes;
    var income = price * players;
    profit = income - cost1 - cost2;
    problem.question = "<p>" + person.name + " has designed a game.</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " uses a fair dice numbered 1 to 6 and a fair spinner numbered 1 to " + sides + ".</p>";
    problem.question += "<p>Each player rolls the dice once and spins the spinner once.</p>";
    problem.question += "<p>You win &pound;" + prize1 + " if you roll a " + sides + " and spin a " + sides + ".</p>";
    problem.question += "<p>You win &pound;" + prize2 + " if you roll a " + choice + " or spin a " + choice + " or both.</p>";
    problem.question += "<p>" + person.name + " expects " + players + " players to play the game.</p>";
    problem.question += "<p>Each person will pay &pound;" + price + " to play the game.</p>";
    problem.question += "<p>Can " + person.name + " expect to make a profit? Show clearly how you decide.</p>";
    problem.answer = "The game is estimated to generate " + players + " &#215; &pound;" + price + " = &pound;" + income + ".</p>"
    problem.answer += "<p>P(Win &pound;" + prize1 + ") = <sup>" + p1 + "</sup>&frasl;<sub>" + outcomes + "</sub>.</p>";
    problem.answer += "<p><sup>" + p1 + "</sup>&frasl;<sub>" + outcomes + "</sub> of " + players + " players &#215; &pound;" + prize1 + " = &pound;" + cost1 + "</sub>.</p>";
    problem.answer += "<p>P(Win &pound;" + prize2 + ") = <sup>" + p2 + "</sup>&frasl;<sub>" + outcomes + "</sub>.</p>";
    problem.answer += "<p><sup>" + p2 + "</sup>&frasl;<sub>" + outcomes + "</sub> of " + players + " players &#215; &pound;" + prize2 + " = &pound;" + cost2 + "</sub>.</p>";
    problem.answer += "<p>Total payouts = &pound;" + (cost1 + cost2) + ".</p>";
    if (profit > 0) {
        problem.answer += "<p>" + person.name + " can expect to make &pound;" + profit + " profit on the game.</p>";
    } else if (profit < 0) {
        problem.answer += "<p>" + person.name + " can expect to make a &pound;" + Math.abs(profit) + " loss on the game.</p>";
    } else {
        problem.answer += "<p>" + person.name + " can expect to break even on the game.</p>";
    }
    return problem;
}
function testingPythagoras() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var rightAngled = false;
    var s1 = {};
    var s2 = {};
    var s3 = {};
    s1.let = "AB";
    s2.let = "BC";
    s3.let = "AC";
    do {
        s1.length = getRandom(3, 13);
        s2.length = getRandom(3, 13);
        s3.length = getRandom(3, 13);
    } while (s1.length === s2.length || s1.length === s3.length || s2.length === s3.length);
    var hyp = Math.max(s1.length, s2.length, s3.length);
    if (s1.length * s1.length + s2.length * s2.length == s3.length * s3.length) {
        rightAngled = true;
    }
    if (s1.length * s1.length + s3.length * s3.length == s2.length * s2.length) {
        rightAngled = true;
    }
    if (s2.length * s2.length + s3.length * s3.length == s1.length * s1.length) {
        rightAngled = true;
    }
    var perimeter = s1.length + s2.length + s3.length;
    var unit = "m";
    if (Math.random() < 0.5) {
        unit = "cm";
    }
    problem.question = "<p>Triangle ABC has perimeter " + perimeter + " " + unit + ".</p>";
    problem.question += "<p>AB = " + s1.length + " " + unit + " and BC = " + s2.length + " " + unit + ".</p>";
    problem.question += "<p>Is triangle ABC is a right-angled triangle? Show clearly how you decide.</p>";
    problem.answer = "<p>AC is given by " + perimeter + " - (" + s1.length + " + " + s2.length + ")" + " = " + s3.length + " " + unit + ".</p>";
    problem.answer += "<p>If ABC is right angled, then " + hyp + " " + unit + " is the length of the hypotenuse.</p>";
    switch (hyp) {
        case s1.length:
            problem.answer += "<p>By Pythagoras, " + s2.let + "&sup2; + " + s3.let + "&sup2;  = " + s1.let + "&sup2;.</p>";
            problem.answer += "<p>" + s2.length + "&sup2; + " + s3.length + "&sup2;  = " + s1.length + "&sup2;.</p>";
            problem.answer += "<p>" + s2.length * s2.length + " + " + s3.length * s3.length + "  = " + s1.length * s1.length + ".</p>";
            break;
        case s2.length:
            problem.answer += "<p>By Pythagoras, " + s1.let + "&sup2; + " + s3.let + "&sup2;  = " + s2.let + "&sup2;.</p>";
            problem.answer += "<p>" + s1.length + "&sup2; + " + s3.length + "&sup2;  = " + s2.length + "&sup2;.</p>";
            problem.answer += "<p>" + s1.length * s1.length + " + " + s3.length * s3.length + "  = " + s2.length * s2.length + ".</p>";
            break;
        case s3.length:
            problem.answer += "<p>By Pythagoras, " + s1.let + "&sup2; + " + s2.let + "&sup2;  = " + s3.let + "&sup2;.</p>";
            problem.answer += "<p>" + s1.length + "&sup2; + " + s2.length + "&sup2;  = " + s3.length + "&sup2;.</p>";
            problem.answer += "<p>" + s1.length * s1.length + " + " + s2.length * s2.length + "  = " + s3.length * s3.length + ".</p>";
            break;
    }
    if (!rightAngled) {
        problem.answer += "<p>Since this is false, the triangle is not right angled.</p>"
    } else {
        problem.answer += "<p>Since this is true, the triangle is right angled.</p>";
    }
    return problem;
}
function multipleRatiosAndPercentages() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = true;
    var t = getRandom(1, 3);
    var s = getRandom(10, 30);
    var m = getRandom(3, 8);
    do {
        var f = getRandom(3, 8);
    } while (f === m);
    var dec = Math.round((s / (t + s)) * (f / (m + f)) * 100000000) / 100000000;
    problem.question = "<p>On a school trip the ratio of the number of teachers to the number of students is " + t + ":" + s + ".</p>";
    problem.question += "<p>The ratio of the number of male students to the number of female students is " + m + ":" + f + ".</p>";
    problem.question += "<p>Work out what percentage of all the people on the trip are female students.</p>";
    problem.question += "<p>Give your answer correct to the nearest whole number.</p>";
    problem.answer = "<p><sup>" + s + "</sup>&frasl;<sub>" + (t + s) + "</sub> &#215; <sup>" + f + "</sup>&frasl;<sub>" + (m + f) + "</sub> = " + dec + "</p>";
    problem.answer += "<p>" + dec + " = " + Math.round(dec * 100) + "% (nearest whole number).</p>";
    return problem;
}
function nonCalcReversePercentage() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "FH";
    problem.calc = false;
    var tax = 10 * getRandom(1, 3);
    var item = itemPicker("large");
    var originalPrice = 100 * getRandom(2, 6);
    var newPrice = originalPrice + (originalPrice * tax / 100);
    var person = namePicker();
    problem.question = "<p>" + person.name + " buys a " + item + ".</p>";
    problem.question += "<p>A " + tax + "% tax is added to the price of the " + item + ".</p>";
    problem.question += "<p>" + person.name + " then has to pay a total of &pound;" + newPrice + ".</p>";
    problem.question += "<p>What is the price of the " + item + " with no tax added?</p>";
    problem.answer = "<p>" + (100 + tax) + "% is worth &pound;" + newPrice + ".</p>";
    problem.answer += "<p>10% would be &pound" + newPrice + " &divide " + (100 + tax) / 10 + " = &pound;" + originalPrice / 10 + ".</p>";
    problem.answer += "<p>The price before tax is &pound;" + originalPrice / 10 + " &#215 10 = &pound;" + originalPrice + ".</p>";
    return problem;
}
function productOfPrimes() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "FH";
    problem.calc = false;
    var primesLeft = getRandom(3, 6);
    var primeList = new Array(2, 3, 5, 7, 11, 13, 17, 19);
    var primeQuantity = [];
    var product = 1;
    var factorisation = "";
    for (var i = 0; i < primeList.length; i++) {
        var amount = getRandom(0, primesLeft);
        primeQuantity[i] = amount;
        primesLeft -= amount;
        product *= Math.pow(primeList[i], primeQuantity[i]);
        if (primeQuantity[i] > 1) {
            factorisation += primeList[i] + "<sup>" + primeQuantity[i] + "</sup> &#215; ";
        } else if (primeQuantity[i] === 1) {
            factorisation += primeList[i] + " &#215; ";
        }
        if (i === primeList.length && primesLeft !== 0) {
            i = 0;
        }
    }
    factorisation = factorisation.slice(0, -8);
    problem.question = "<p>Express " + product + " as the product of its prime factors.";
    problem.answer = "<p>" + product + " = " + factorisation + ".</p>";
    return problem;
}
function multiplyingDecimals() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var dec1 = 10 * getRandom(1, 9) + getRandom(1, 9);
    var dec2 = 100 * getRandom(1, 9) + 10 * getRandom(1, 9) + getRandom(1, 9);
    dec1 /= 10;
    dec2 /= Math.pow(10, 2);
    if (Math.random() < 0.5) {
        var temp = dec1;
        dec1 = dec2;
        dec2 = temp;
    }
    problem.question = "<p>Work out " + dec1 + " &#215; " + dec2 + ".</p>";
    problem.answer = "<p>" + dec1 + " &#215; " + dec2 + " = " + roundError(dec1 * dec2) + ".</p>";
    return problem;
}
function areaOfSquareExpressions() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var units = unitPicker("length");
    do {
        var area = 5 * getRandom(2, 8);
    } while (area === 25);
    var side = getRandom(1, Math.floor(Math.sqrt(area)));
    problem.question = "<img src='/media/gcseQuestions/84-" + getRandom(0, 1) + ".jpg'>";
    problem.question += "<p>The area of square ABCD is " + area + " " + units + "&sup2;.</p>";
    problem.question += "<p>AE = AF = " + side + " " + units + ".</p>";
    problem.question += "<p>EB = DF = x " + units + ".</p>";
    problem.question += "<p>Show that x&sup2 + " + (2 * side) + "x = " + (area - side * side) + ".</p>";
    problem.answer = "<p>x&sup2 + " + side + "x + " + side + "x + " + (side * side) + " = " + area + ".</p>";
    problem.answer += "<p>x&sup2 + " + (2 * side) + "x + " + (side * side) + " = " + area + ".</p>";
    problem.answer += "<p>x&sup2 + " + (2 * side) + "x = " + (area - side * side) + ".</p>";
    return problem;
}
function framingMetal() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "FH";
    problem.calc = false;
    switch (getRandom(0, 3)) {
        case 0:
            var frameHeight = 3;
            var frameLength = 4;
            break;
        case 1:
            frameHeight = 6;
            frameLength = 8;
            break;
        case 2:
            frameHeight = 9;
            frameLength = 12;
            break;
        case 3:
            frameHeight = 5;
            frameLength = 12;
            break;
    }
    var material = "metal";
    if (Math.random() < 0.5) {
        material = "wood";
    }
    var frameDiagonal = Math.sqrt(frameHeight * frameHeight + frameLength * frameLength);
    var weightPerKG = 0.5 + getRandom(1, 3);
    var totalLength = 2 * (frameHeight + frameLength) + frameDiagonal;
    var totalWeight = totalLength * weightPerKG;
    problem.question = "<p>This rectangular frame is made from 5 straight pieces of " + material + ".</p>";
    problem.question += "<p>The frame is " + frameLength + " m long and " + frameHeight + " m wide.</p>";
    problem.question += "<img src='/media/gcseQuestions/85-" + getRandom(0, 1) + ".jpg'>";
    problem.question += "<p>The weight of the " + material + " is " + weightPerKG + " kg per metre.</p>";
    problem.question += "<p>Work out the total weight of the " + material + " in the frame.</p>";
    problem.answer = "<p>Frame diagonal is given by &radic;<span style='text-decoration:overline;'>" + frameHeight + "&sup2; + " + frameLength + "&sup2;</span> = " + frameDiagonal + " m.</p>";
    problem.answer += "<p>The total length of " + material + " needed is 2(" + frameHeight + " + " + frameLength + ") + " + frameDiagonal + " = " + totalLength + " m.</p>";
    problem.answer += "<p>Total weight = " + totalLength + " &#215; " + weightPerKG + " = " + totalWeight + "kg.</p>";
    return problem;
}
function showingIfParallel() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "FH";
    problem.calc = false;
    var l1 = {};
    var l2 = {};
    do {
        l1.m = getRandom(1, 3);
        l2.m = getRandom(1, 3);
        l1.c = getRandom(-15, 15);
        l2.c = getRandom(-15, 15);
        l1.mult = getRandom(1, 5);
        l2.mult = getRandom(1, 5);
    } while (l1.m * l1.mult === l2.m * l2.mult || l1.c === 0 || l2.c === 0);
    l1.eq = fixTerm(l1.mult, "y", true) + " = " + fixTerm(l1.m * l1.mult, "x ", true) + fixTerm(l1.c * l1.mult, "", false);
    l2.eq = fixTerm(l2.mult, "y ", true) + fixTerm(-l2.m * l2.mult, "x", false) + " = " + fixTerm(l2.c * l2.mult, "", true);
    problem.question = "<p>The equation of the line L<sub>1</sub> is " + l1.eq + ".</p>";
    problem.question += "<p>The equation of the line L<sub>2</sub> is " + l2.eq + ".</p>";
    if (l1.m === l2.m) {
        problem.question += "<p>Show that these two lines are parallel.</p>";
    } else {
        problem.question += "<p>Show that these two lines are not parallel.</p>";
    }
    problem.answer = "";
    if (l1.mult !== 1) {
        problem.answer += "<p>Dividing L<sub>1</sub> by " + l1.mult + " gives " + fixTerm(1, "y", true) + " = " + fixTerm(l1.m, "x ", true) + fixTerm(l1.c, "", false) + ".</p>";
    }
    problem.answer += "<p>The gradient of L<sub>1</sub> is " + l1.m + ".</p>";
    problem.answer += "<p>Dividing L<sub>2</sub> by " + l2.mult + " gives " + fixTerm(1, "y ", true) + fixTerm(-l2.m, "x", false) + " = " + fixTerm(l2.c, "", true) + ".</p>";
    problem.answer += "<p>Now rearranging gives " + fixTerm(1, "y", true) + " = " + fixTerm(l2.m, "x ", true) + fixTerm(l2.c, "", false) + ".</p>";
    problem.answer += "<p>The gradient of L<sub>2</sub> is " + l2.m + ".</p>";
    if (l1.m === l2.m) {
        problem.answer += "<p>Therefore L<sub>1</sub> and L<sub>2</sub> are parallel.</p>";
    } else {
        problem.answer += "<p>Therefore L<sub>1</sub> and L<sub>2</sub> are not parallel.</p>";
    }
    return problem;
}
function vectorsInParallelograms() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var vector = new Array("AC", "CA", "BD", "DB", "AB", "BA", "DC", "CD", "AD", "DA", "BC", "CB");
    var solution = new Array("-2a", "2a", "-2b", "2b", "-a + b", "a - b", "-a + b", "a - b", "-a - b", "a + b", "-a - b", "a + b");
    problem.question = "<img src='/media/gcseQuestions/87-" + getRandom(0, 3) + ".jpg'>";
    problem.question += "<p>ABCD is a parallelogram.</p>";
    problem.question += "<p>The diagonals of the parallelogram intersect at O.</p>";
    var q1 = getRandom(0, 3);
    var q2 = getRandom(4, 7);
    var q3 = getRandom(8, 11);
    if (q1 < 2) {
        problem.question += "<p>a) Find in terms of <strong>a</strong>, the vector " + vector[q1] + ".</p>";
    } else {
        problem.question += "<p>a) Find in terms of <strong>b</strong>, the vector " + vector[q1] + ".</p>";
    }
    problem.question += "<p>b) Find in terms of <strong>a</strong> and <strong>b</strong>, the vector " + vector[q2] + ".</p>";
    problem.question += "<p>c) Find in terms of <strong>a</strong> and <strong>b</strong>, the vector " + vector[q3] + ".</p>";
    problem.answer = "<p>a) " + vector[q1] + " = " + solution[q1] + ".</p>";
    problem.answer += "<p>b) " + vector[q2] + " = " + solution[q2] + ".</p>";
    problem.answer += "<p>c) " + vector[q3] + " = " + solution[q3] + ".</p>";
    return problem;
}
function expectedFrequency() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = true;
    var person = namePicker();
    do {
        var missingNum = getRandom(0, 5);
        var chosenNum = getRandom(0, 5);
    } while (missingNum >= chosenNum);
    var trials = 50 * getRandom(2, 8);
    var probs = [];
    var total = 0;
    for (var i = 0; i < 6; i++) {
        probs.push(getRandom(10, 30));
        total += probs[i];
    }
    for (i = 0; i < 6; i++) {
        probs[i] /= total;
        probs[i] = Math.round(probs[i] * 100) / 100;
    }
    probs[missingNum] = 0;
    total = 0;
    for (i = 0; i < 6; i++) {
        total += probs[i];
    }
    var knownProb = roundError(total);
    probs[missingNum] = roundError(1 - total);
    var combinedProb = roundError(probs[missingNum] + probs[chosenNum]);
    problem.question = "<p>The table shows the probabilities that a biased six-sided dice will land on the numbers one to six.</p>";
    problem.question += "<p>The probability of rolling a " + (missingNum + 1) + " is missing from the table.</p>";
    problem.question += "<table><tr><th>Number on dice</th><th>1</th><th>2</th><th>3</th><th>4</th><th>5</th><th>6</th></tr><tr><th>Probability</th>";
    total = 0;
    for (i = 0; i < 6; i++) {
        if (i != missingNum) {
            problem.question += "<td>" + probs[i] + "</td>";
        } else {
            problem.question += "<td></td>";
        }
        total += probs[i];
    }
    total = roundError(total);
    problem.question += "</tr></table>";
    problem.question += "<p>" + person.name + " rolls the biased dice " + trials + " times.</p>";
    problem.question += "<p>Work out an estimate for the total number of times the dice will land on a " + (missingNum + 1) + " or a " + (chosenNum + 1) + ".</p>";
    problem.answer = "<p>P(Rolling a " + (missingNum + 1) + ") = 1 - " + knownProb + " = " + probs[missingNum] + ".</p>";
    problem.answer += "<p>P(Rolling a " + (missingNum + 1) + " or " + (chosenNum + 1) + ") = " + probs[missingNum] + " + " + probs[chosenNum] + " = " + combinedProb + ".</p>";
    problem.answer += "<p>" + trials + " &#215; " + combinedProb + " = " + roundError(trials * combinedProb) + ".</p>";
    problem.answer += "<p>" + person.name + " can expect to roll a " + (missingNum + 1) + " or a " + (chosenNum + 1) + " an estimated " + Math.round(trials * combinedProb) + " times.</p>";
    return problem;
}
function theatreSeats89() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "FH";
    problem.calc = true;
    var day = dayPicker();
    do {
        var seatPercentage = 5 * getRandom(8, 15);
        var seatsTaken = seatPercentage * getRandom(5, 20);
        var totalSeats = seatsTaken / seatPercentage * 100;
        var adultParts = getRandom(2, 5);
        var childParts = getRandom(2, 5);
        var totalParts = adultParts + childParts;
        var people = 2 * (Math.floor(totalSeats / totalParts) + (totalParts * (getRandom(10, 30))));
        var adults = people / totalParts * adultParts;
        var children = people / totalParts * childParts;
        var den = childParts * getRandom(1, 4);
        var num = getRandom(1, den);
        var hcf = HCF(den, num);
        den /= hcf;
        num /= hcf;
        var stallChildren = roundError(children / den * num);
        var circleChildren = children - stallChildren;
    } while (stallChildren !== Math.round(stallChildren) || circleChildren !== Math.round(circleChildren) || num >= den || den % num === 0 || adultParts === childParts);
    problem.question = "<p>On " + day + ", some adults and children were at the theatre.</p>";
    problem.question += "<p>The ratio of the number of adults to children was " + adultParts + ":" + childParts + ".</p>";
    problem.question += "<p>Each person had a seat in the Circle or had a seat in the Stalls.</p>";
    problem.question += "<p><sup>" + num + "</sup>&frasl;<sub>" + den + "</sub> of the children had seats in the Stalls.</p>";
    problem.question += "<p>" + circleChildren + " children had seats in the Circle.</p>";
    problem.question += "<p>There are exactly " + totalSeats + " seats in the theatre.</p>";
    problem.question += "<p>On this particular " + day + ", were there people on more than " + seatPercentage + "% of the seats?</p>";
    problem.question += "<p>You must show how you get your answer.</p>";
    problem.answer = "<p><sup>" + (den - num) + "</sup>&frasl;<sub>" + den + "</sub> represents the " + circleChildren + " children in the Circle so <sup>" + num + "</sup>&frasl;<sub>" + den + "</sub> represents the " + stallChildren + " children in the stalls.</p>";
    problem.answer += "<p>There were " + circleChildren + " + " + stallChildren + " = " + children + " children in total which represents " + childParts + " parts of the total number of people.</p>";
    problem.answer += "<p>One part represents " + children + " &divide; " + childParts + " = " + children / childParts + " people so there were " + people / totalParts + " &#215; " + adultParts + " = " + adults + " adults.</p>";
    problem.answer += "<p>There were " + adults + " + " + children + " = " + (adults + children) + " people in total at the theatre.</p>";
    problem.answer += "<p>" + seatPercentage + "% of " + totalSeats + " = " + seatsTaken + " seats.</p>";
    if ((adults + children) > seatsTaken) {
        problem.answer += "<p>Yes, more than " + seatPercentage + "% of the seats were taken.</p>";
    } else {
        problem.answer += "<p>No, less than " + seatPercentage + "% of the seats were taken.</p>";
    }
    return problem;
}
function combinedAverageSpeed90() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = true;
    var person = namePicker();
    do {
        var town1 = townPicker();
        var town2 = townPicker();
        var town3 = townPicker();
    } while (town1 === town2 || town1 === town3 || town2 === town3);
    do {
        var time1 = 6 * getRandom(5, 25) / 60;
        var time2 = 6 * getRandom(5, 25) / 60;
        var speed1 = 5 * getRandom(8, 16);
        var speed2 = 5 * getRandom(8, 16);
        var dis1 = roundError(time1 * speed1);
        var dis2 = roundError(time2 * speed2);
        var totalTime = roundError(time1 + time2);
        var totalDistance = dis1 + dis2;
        var averageSpeed = roundError(totalDistance / totalTime);
    } while (speed1 === speed2 || time1 === time2 || averageSpeed !== Math.round(averageSpeed));
    problem.question = "<p>" + person.name + " drove " + dis1 + " km from " + town1 + " to " + town2 + ".</p>";
    problem.question += "<p>" + capitalFirst(person.subject) + " then drove " + dis2 + " km from " + town2 + " to " + town3 + ".</p>";
    problem.question += "<p>" + person.name + "'s average speed from " + town1 + " to " + town2 + " was " + speed1 + " km/h.</p>";
    problem.question += "<p>" + person.name + " took " + (time2 * 60) + " minutes to drive from " + town2 + " to " + town3 + ".</p>";
    problem.question += "<p>Work out " + person.name + "'s average speed for his total drive from " + town1 + " to " + town3 + ".</p>";
    problem.answer = "<p>Time taken to get from  " + town1 + " to " + town2 + " was " + (time1 * 60) + " minutes (" + time1 + " hours).</p>";
    problem.answer += "<p>Total time taken was " + (totalTime * 60) + " minutes (" + totalTime + " hours).</p>";
    problem.answer += "<p>Total distance travelled was " + totalDistance + " km.</p>";
    problem.answer += "<p>Average speed was " + averageSpeed + " km/h.</p>";
    return problem;
}
function similarTriangles91() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = true;

    var units = unitPicker("length");

    var sf = 0.5 * getRandom(3, 6);
    var BC = roundError(0.1 * getRandom(10, 50));
    var DC = roundError(0.1 * getRandom(10, 50));
    var DB = roundError(0.1 * getRandom(10, 50));
    var AC = roundError(BC * sf);
    var EC = roundError(DC * sf);
    var AE = roundError(DB * sf);
    var AB = roundError(AC - BC);

    problem.question = "<img src='/media/gcseQuestions/91-" + getRandom(0, 1) + ".jpg'>";
    problem.question += "<p>ABC and EDC are straight lines.</p>";
    problem.question += "<p>EA is parallel to DB.</p>";
    problem.question += "<p>EC = " + EC + " " + units + ". DC = " + DC + " " + units + ".</p>";
    problem.question += "<p>DB = " + DB + " " + units + ". AC = " + AC + " " + units + ".</p>";
    problem.question += "<p>a) Work out the length of AE.</p>";
    problem.question += "<p>b) Work out the length of AB.</p>";
    problem.answer = "<p>a) Length scale factor is " + EC + " &divide; " + DC + " = " + sf + ".</p>";
    problem.answer += "<p>AE = " + DB + " &#215; " + sf + " = " + AE + " " + units + ".</p>";
    problem.answer += "<p>b) BC = " + AC + " &divide; " + sf + " = " + BC + " " + units + ".</p>";
    problem.answer += "<p>AB = " + AC + " - " + BC + " = " + AB + " " + units + ".</p>";
    return problem;
}
function squareInACircle92() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "H";
    problem.calc = true;
    var units = unitPicker("length");
    var area = getRandom(2, 20);
    area *= area;
    var radius = Math.sqrt(area) / Math.sqrt(Math.PI);
    var diagonal = 2 * radius;
    var x = Math.sqrt(diagonal * diagonal / 2);
    var accuracy = getRandom(2, 4);
    problem.question = "<p>A square, with sides of length x " + units + ", is inside a circle.</p>";
    problem.question += "<p>Each vertex of the square is on the circumference of the circle.</p>";
    problem.question += "<p>The area of the circle is " + area + " " + units + "&sup2;.</p>";
    problem.question += "<p>Work out the value of x correct to " + accuracy + " significant figures.</p>";
    problem.answer = "<p>Radius of the circle is <sup>" + Math.sqrt(area) + "</sup>&frasl;<sub>" + "&radic;&pi;</sub> &asymp; " + radius.toPrecision(accuracy + 1) + ".</p>";
    problem.answer += "<p>The diagonal of the square is twice the radius of the circle, <sup>" + 2 * Math.sqrt(area) + "</sup>&frasl;<sub>" + "&radic;&pi;</sub> &asymp; " + (2 * radius).toPrecision(accuracy + 1) + ".</p>";
    problem.answer += "<p>By Pythagoras, 2x&sup2 = <sup>" + (2 * Math.sqrt(area)) * (2 * Math.sqrt(area)) + "</sup>&frasl;<sub>" + "&pi;</sub>.</p>";
    problem.answer += "<p>x = " + x.toPrecision(accuracy) + " " + units + ".</p>";
    return problem;
}
function reversePercentages93() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "FH";
    problem.calc = false;
    do {
        var percent = 10 * getRandom(2, 12);
    } while (percent % 50 === 0);
    var given = percent * getRandom(2, 10);
    var whole = roundError(given / percent * 100);
    problem.question = "<p>" + percent + "% of a number is " + given + ".</p>";
    problem.question += "<p>Work out the number.</p>";
    problem.answer = "<p>10% is given by " + given + " &divide; " + (percent / 10) + " = " + (10 * given / percent) + ".</p>";
    problem.answer += "<p>100% is " + (10 * given / percent) + " &#215; 10 = " + whole + ".</p>";
    return problem;
}
function sandEquations94() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    switch (getRandom(0, 5)) {
        case 0:
            var material = "sand";
            break;
        case 1:
            var material = "gravel";
            break;
        case 2:
            var material = "pebbles";
            break;
        case 3:
            var material = "potatoes";
            break;
        case 4:
            var material = "cement";
            break;
        case 5:
            var material = "soil";
            break;
    }
    if (Math.random() < 0.5) {
        var bag = "sack";
    } else {
        bag = "bag";
    }
    var diff = 10 * getRandom(1, 5) + 5;
    var total = diff + 10 * getRandom(4, 12);
    var small = (total - diff) / 2;

    problem.question = "<p>A pile of " + material + " has a weight of " + total + " kg.</p>";
    problem.question += "<p>Some of the " + material + "  put into a small " + bag + ".</p>";
    problem.question += "<p>The rest of the " + material + " is put into a large " + bag + ".</p>";
    if (Math.random() < 0.5) {
        problem.question += "<p>The " + material + " in the small " + bag + " weighs " + diff + " kg less than the " + material + " in the large " + bag + ".</p>";
    } else {
        problem.question += "<p>The " + material + " in the large " + bag + " weighs " + diff + " kg more than the " + material + " in the small " + bag + ".</p>";
    }
    var findLarge = false;
    if (Math.random() < 0.5) {
        findLarge = true;
        problem.question += "<p>What is the weight of the " + material + " in the large " + bag + "?</p>";
    } else {
        problem.question += "<p>What is the weight of the " + material + " in the small " + bag + "?</p>";
    }

    problem.answer = "<p>Let the " + material + " in the small " + bag + " weigh x kg.</p>";
    problem.answer += "<p>The " + material + " in the large " + bag + " weighs x + " + diff + " kg.</p>";
    problem.answer += "<p>2x + " + diff + " = " + total + ".</p>";
    problem.answer += "<p>2x = " + (total - diff) + ".</p>";
    problem.answer += "<p>x = " + small + ".</p>";
    if (findLarge) {
        problem.answer += "<p>There is " + (small + diff) + " kg of " + material + " in the large " + bag + ".</p>";
    } else {
        problem.answer += "<p>There is " + small + " kg of " + material + " in the small " + bag + ".</p>";
    }
    return problem;
}
function ratiosOnALine95() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    var l = [];
    var choice = getRandom(1, 18);
    for (var i = 0; i < 4; i++) {
        l.push(letterPicker(choice + i, true));
    }
    do {
        var base = getRandom(2, 10);
        var a = getRandom(1, base - 1);
        var b = base - a;

        var mult = getRandom(2, 6);
        var c = getRandom((a + 1) * mult, base * mult - 1);
        var d = base * mult - c;
    } while (a / b === c / d || a === b || c === d || a * b * c * d === 0);

    problem.question = "<p>The points <em>" + l[0] + "</em>, <em>" + l[1] + "</em>, <em>" + l[2] + "</em> and <em>" + l[3] + "</em> lie in order on a straight line.</p>";
    problem.question += "<p><em>" + l[0] + l[1] + "</em> : <em>" + l[1] + l[3] + "</em> = " + a + " : " + b + "</p>";
    problem.question += "<p><em>" + l[0] + l[2] + "</em> : <em>" + l[2] + l[3] + "</em> = " + c + " : " + d + "</p>";
    problem.question += "<p>Work out <em>" + l[0] + l[1] + "</em> : <em>" + l[1] + l[2] + "</em> : <em>" + l[2] + l[3] + ".</em></p>";
    problem.answer = "<p><em>" + l[0] + l[1] + "</em> : <em>" + l[1] + l[3] + "</em> is split into " + base + " parts.</p>";
    problem.answer += "<p><em>" + l[0] + l[2] + "</em> : <em>" + l[2] + l[3] + "</em> is split into " + base * mult + " parts.</p>";
    problem.answer += "<p>" + base * mult + " &divide; " + base + " = " + mult + ".</p>";
    problem.answer += "<p><em>" + l[0] + l[1] + "</em> : <em>" + l[1] + l[3] + "</em> = " + a * mult + " : " + b * mult + ".</p>";
    problem.answer += "<p><em>" + l[1] + l[2] + "</em> is represented by " + (c - (a * mult)) + " parts.</p>";
    problem.answer += "<p><em>" + l[0] + l[1] + "</em> : <em>" + l[1] + l[2] + "</em> : <em>" + l[2] + l[3] + "</em> = " + (a * mult) + " : " + (c - (a * mult)) + " : " + d + ".</p>";
    return problem;
}
function surfaceAreaVolumeCube96() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = true;
    var units = unitPicker("length");
    var side = getRandom(2, 15);
    var area = side * side;
    var sa = 6 * side * side;
    var volume = side * side * side;
    if (Math.random() < 0.5) {
        problem.question = "<p>The total surface area of a cube is " + sa + " " + units + "&sup2;.</p>";
        problem.question += "<p>Work out the volume of the cube.</p>";
        problem.answer = "<p>The area of one face is " + sa + " &divide; 6 = " + area + " " + units + "&sup2;.<p>";
        problem.answer += "<p>The side length of the cube is &radic;" + area + " = " + side + " " + units + ".<p>";
        problem.answer += "<p>The total volume is " + side + " &#215; " + side + " &#215; " + side + " = " + volume + " " + units + "&sup3;.<p>";
    } else {
        problem.question = "<p>The volume of a cube is " + volume + " " + units + "&sup3;.</p>";
        problem.question += "<p>Work out the total surface area of the cube.</p>";
        problem.answer = "<p>The side length of the cube is &#8731;" + volume + " = " + side + " " + units + ".<p>";
        problem.answer += "<p>The area of one face is " + side + " &#215; " + side + " = " + area + " " + units + "&sup2;.<p>";
        problem.answer += "<p>The total surface area is 6 &#215; " + area + " = " + sa + " " + units + "&sup2;.<p>";
    }
    return problem;
}
function percentageProfit97() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = true;
    switch (getRandom(0, 2)) {
        case 0:
            var product = "water";
            break;
        case 1:
            product = "cola";
            break;
        case 2:
            product = "lemonade";
            break;
    }
    var bottles = 4 * getRandom(2, 6);
    var buyPrice = 2 * getRandom(10, 40);
    var packPrice = bottles * buyPrice;
    var sellPrice = Math.round(buyPrice / 10) * 10 + 10;
    var profit = sellPrice - buyPrice;
    var percent = Math.round(1000 * profit / buyPrice) / 10;
    var person = namePicker();
    problem.question = "<p>" + person.name + " buy a pack of " + bottles + " bottles of " + product + ".<br>";
    problem.question += "The pack costs &pound;" + (packPrice / 100).toFixed(2) + ".</p>";
    problem.question += "<p>" + person.name + " sells all the bottles for " + sellPrice + "p each.</p>";
    problem.question += "<p>Work out " + person.name + "'s percentage profit.<br>";
    problem.question += "Give your answer correct to 1 decimal place.</p>";
    problem.answer = "<p>" + person.name + " paid &pound;" + (packPrice / 100).toFixed(2) + " &divide; " + bottles + " = " + buyPrice + "p per bottle.<p>";
    problem.answer += "<p>" + capitalFirst(person.subject) + " made " + sellPrice + " - " + buyPrice + " = " + profit + "p proft per bottle.</p>";
    problem.answer += "<p>Percentage profit is s<sup>" + profit + "</sup>&frasl;<sub>" + buyPrice + "</sub> &#215 100 = " + percent + "%.</p>";
    return problem;
}
function sameDistanceDifferentTime98() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "H";
    problem.calc = true;
    var n = getRandom(0, 1000);
    var person1 = namePicker(n);
    var person2 = namePicker(n + 1);
    do {
        var dist = 10 * (getRandom(2, 12));
        var t1 = getRandom(3, 9) / 2;
        var s1 = dist / t1;
        var delay = 5 * getRandom(1, 5);
        var catchUpDist = 5 * getRandom(1, 6);
        var catchUpTime = catchUpDist / s1;
        var p2catchUpTime = (catchUpTime - delay / 60);
        var s2 = catchUpDist / p2catchUpTime;
    } while (s1 !== Math.round(s1) || s2 !== Math.round(s2) || catchUpTime * 60 !== Math.round(catchUpTime * 60) || p2catchUpTime <= 0);
    problem.question = "<p>" + person1.name + " and " + person2.name + " cycled along the same " + dist + " km route.<br>";
    problem.question += person1.name + " took " + t1 + " hours to cycle the " + dist + " km.</p>";
    problem.question += "<p>" + person2.name + " started to cycle " + delay + " minutes after " + person1.name + " started to cycle.<br>";
    problem.question += person2.name + " caught up with " + person1.name + " when they had both cycled " + catchUpDist + " km.</p>";
    problem.question += "<p>" + person1.name + " and " + person2.name + " both cycled at constant speeds.</p>";
    problem.question += "<p>Work out " + person2.name + "'s speed.</p>";
    problem.answer = "<p>" + person1.name + "'s speed = " + s1 + " km/h.</p>";
    problem.answer += "<p>" + person1.name + "'s time for " + catchUpDist + " km = " + catchUpTime * 60 + " minutes.</p>";
    problem.answer += "<p>" + person2.name + "'s time for " + catchUpDist + " km = " + p2catchUpTime * 60 + " minutes.</p>";
    problem.answer += "<p>" + person2.name + "'s speed = " + s2 + " km/h.</p>";
    return problem;
}
function proportionalWages99() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = true;
    do {
        var totalTime = 6 * getRandom(3, 10);
        var initialCleaners = getRandom(3, 10);
        var newCleaners = getRandom(3, 12);
        var wage = getRandom(7, 12) + getRandom(1, 9) / 10;
        var initialTime = totalTime / initialCleaners;
        var hours = Math.floor(initialTime);
        var minutes = roundError(60 * (initialTime - hours));
    } while (initialCleaners === newCleaners || totalTime % initialCleaners === 0 || 10 * Math.round(minutes / 10) !== minutes);
    problem.question = "<p>Yesterday it took " + initialCleaners + " cleaners " + hours + " hours and " + minutes + " minutes to clean a hotel.</p>";
    problem.question += "<p>Today, there are " + newCleaners + " cleaners to clean all the rooms in the hotel.</p>";
    problem.question += "<p>Each cleaner is paid &pound;" + wage.toFixed(2) + " for each hour or part of an hour they work.</p>";
    problem.question += "<p>How much will each cleaner be paid today?";
    problem.answer = "<p>1 cleaner would take " + initialTime * initialCleaners + " hours.</p>";
    problem.answer += "<p>" + newCleaners + " cleaners would take " + Math.round(1000 * (initialTime * initialCleaners) / newCleaners) / 1000 + " hours.";
    problem.answer += "<p>" + Math.ceil((initialTime * initialCleaners) / newCleaners) + " hours &#215; &pound;" + wage.toFixed(2) + " = &pound;" + roundError(Math.ceil((initialTime * initialCleaners) / newCleaners) * wage).toFixed(2) + ".</p?";
    return problem;
}
function ageEquationsWithRatio100() {
    var problem = {};
    problem.marks = 4;
    problem.tier = "FH";
    problem.calc = false;
    var n = getRandom(0, 1000);
    var p1 = namePicker(n);
    var p2 = namePicker(n + 1);
    var p3 = namePicker(n + 2);
    do {
        p1.age = getRandom(2, 20);
        var diff = getRandom(-12, 12);
        p2.age = p1.age + diff;
        var mult = getRandom(2, 6);
        p3.age = p2.age * mult;
    } while (p3.age > 90 || diff === 0 || p2.age < 1);
    var sum = p1.age + p2.age + p3.age;
    if (diff > 0) {
        problem.question = "<p>" + p2.name + " is " + diff + " years older than " + p1.name + ".<br>";
    } else {
        problem.question = "<p>" + p2.name + " is " + Math.abs(diff) + " years younger than " + p1.name + ".<br>";
    }
    if (mult !== 2) {
        problem.question += p3.name + " is " + mult + " times as old as " + p2.name + ".<br>";
    } else {
        problem.question += p3.name + " is twice as old as " + p2.name + ".<br>";
    }
    problem.question += "The sum of their ages is " + sum + ".</p>";
    problem.question += "<p>Work out the ratio of " + p1.name + "'s age to " + p2.name + "'s age to " + p3.name + "'s age.</p>";
    problem.answer = "<p>Let " + p1.name + "'s age be x.</p>";
    if (diff > 0) {
        problem.answer += "<p>x + (x + " + diff + ") + " + mult + "(x + " + diff + ") = " + sum + ".</p>";
        problem.answer += "<p>" + (2 + mult) + "x + " + (1 + mult) * diff + " = " + sum + ".</p>";
    } else {
        problem.answer += "<p>x + (x - " + Math.abs(diff) + ") + " + mult + "(x - " + Math.abs(diff) + ") = " + sum + ".</p>";
        problem.answer += "<p>" + (2 + mult) + "x - " + Math.abs((1 + mult) * diff) + " = " + sum + ".</p>";
    }
    problem.answer += "<p>x = " + p1.age + ".</p>";
    problem.answer += "<p>" + p1.age + ":" + p2.age + ":" + p3.age + ".</p>";
    return problem;
}
function missingConstantsInFunctions101() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "H";
    problem.calc = true;
    var f = new Function(getRandom(2, 8), getRandom(1, 20));
    var g = new Function(getRandom(2, 8), getRandom(1, 20));
    do {
        var term = getRandom(1, 8);
        var term2 = getRandom(1, 8);
    } while (term >= term2);
    problem.question = "<p>The functions f and g are such that:</p>";
    problem.question += "<p>f(x) = " + f.disp + " and ";
    problem.question += "g(x) = ax + b where a and b are constants.</p>";
    problem.question += "<p>g(" + term + ") = " + g.value(term) + " and f<sup>-1</sup>(" + (f.a * (g.a * term2 + g.b) + f.b) + ") = g(" + term2 + ").</p>";
    problem.question += "<p>Find the value of a and b.</p>";
    function Function(a, b) {
        if (toss()) {
            a *= -1;
        }
        if (toss()) {
            b *= -1;
        }
        this.a = a;
        this.b = b;
        if (b > 0) {
            this.disp = a + "x + " + b;
        } else {
            this.disp = a + "x - " + Math.abs(b);
        }
        if (b > 0) {
            if (a > 0) {
                this.inv = "<sup>(x - " + b + ")</sup>&frasl;<sub>" + a + "</sub>";
            } else {
                this.inv = "<sup>-(x - " + b + ")</sup>&frasl;<sub>" + Math.abs(a) + "</sub>";
            }
        } else {
            if (a > 0) {
                this.inv = "<sup>(x + " + Math.abs(b) + ")</sup>&frasl;<sub>" + a + "</sub>";
            } else {
                this.inv = "<sup>-(x + " + Math.abs(b) + ")</sup>&frasl;<sub>" + Math.abs(a) + "</sub>";
            }
        }
        this.value = function (x) {
            return a * x + b;
        };
        this.inverse = function (x) {
            return (x - b) / a;
        };
    }
    problem.answer = "<p>f<sup>-1</sup>(x) = " + f.inv + ".</p>";
    problem.answer += "<p>f<sup>-1</sup>(" + (f.a * (g.a * term2 + g.b) + f.b) + ") = " + f.inverse((f.a * (g.a * term2 + g.b) + f.b)) + ".</p>";
    problem.answer += "<p>g(" + term + ") = " + g.value(term) + " and g(" + term2 + ") = " + g.value(term2) + ".</p>";
    if (g.a > 0) {
        var type = "increases";
    } else {
        type = "decreases";
    }
    problem.answer += "<p>g(x) " + type + " by " + g.a + " as x increases by 1.</p>";
    problem.answer += "<p>g(x) = " + g.disp + ".</p>";
    problem.answer += "<p>a = " + g.a + " and b = " + g.b + ".</p>";
    return problem;
}
function transfromingTrigValues102() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "H";
    problem.calc = false;
    var a = 2 * getRandom(1, 5);
    var b = getRandom(2, 10);
    var x = [0, 30, 60, 90, 120, 150, 180];
    var y = {};

    y.display = [];
    if (toss()) {
        b *= -1;
    }
    if (toss()) {
        var ratio = "sin";
    } else {
        ratio = "cos";
    }
    for (var i = 0; i < x.length; i++) {
        var co = a / 2;
        if (co === 1) {
            co = "";
        }
        if (ratio === "sin") {
            if (x[i] === 60) {
                y.display.push(b + " + " + co + "&radic;3");
            } else if (x[i] === 120) {
                y.display.push(b + " + " + co + "&radic;3");
            } else {
                y.display.push(roundError(a * Math.sin(toRadians(x[i])) + b));
            }
        } else {
            if (x[i] === 30) {
                y.display.push(b + " + " + co + "&radic;3");
            } else if (x[i] === 150) {
                y.display.push(b + " - " + co + "&radic;3");
            } else {
                y.display.push(roundError(a * Math.cos(toRadians(x[i])) + b));
            }
        }
    }
    problem.question = "<p>The table belows shows some values of x and y that satisfy the equation <em>y</em> = <em>a</em>" + ratio + " <em>x</em>&deg;+ <em>b</em>.</p>";
    problem.question += "<table><tr><th>x</th>";
    for (var i = 0; i < x.length; i++) {
        problem.question += "<td>" + x[i] + "</td>";
    }
    problem.question += "</tr><tr><th>y</th>";
    for (i = 0; i < y.display.length; i++) {
        problem.question += "<td>" + y.display[i] + "</td>";
    }
    problem.question += "</table>";
    problem.question += "<p>Find the value of a and b.</p>";
    if (ratio === "sin") {
        problem.answer = "<p>When x = 0, y = " + y.display[0] + " and sin(0&deg;) = 0.</p>";
        problem.answer += "<p>" + y.display[0] + " = a(0) + b.</p>";
        problem.answer += "<p>Therefore b = " + b + ".</p>";
        problem.answer += "<p>When x = 90, y = " + y.display[3] + "; sin(90&deg;) = 1.</p>";
        problem.answer += "<p>" + y.display[3] + " = a(1) + " + b + ".</p>";
        problem.answer += "<p>Therefore a = " + a + ".</p>";
    } else {
        problem.answer = "<p>When x = 90, y = " + y.display[3] + " and cos(90&deg;) = 0.</p>";
        problem.answer += "<p>" + y.display[3] + " = a(0) + b.</p>";
        problem.answer += "<p>Therefore b = " + b + ".</p>";
        problem.answer += "<p>When x = 0, y = " + y.display[0] + "; cos(0&deg;) = 1.</p>";
        problem.answer += "<p>" + y.display[0] + " = a(1) + " + b + ".</p>";
        problem.answer += "<p>Therefore a = " + a + ".</p>";
    }
    problem.answer += "<p>a = " + a + " and b = " + b + ".</p>";
    return problem;
}
function cuttingWire103() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = false;
    var person = namePicker();
    var wireLength = 10 * getRandom(20, 50);
    do {
        var preCuts = getRandom(2, 4);
        var preCutLength = 5 * getRandom(2, 9);
        var newCutLength = 5 * getRandom(2, 9);
        var newCuts = (wireLength - (preCuts * preCutLength)) / newCutLength;
    } while (newCuts < 2 || newCuts % 1 === 0);
    var answer = Math.floor(newCuts);
    problem.question = "<p>A piece of wire is " + wireLength + " cm long.</p>";
    problem.question += "<p>" + person.name + " cuts " + wordedNumber(preCuts) + " " + preCutLength + " cm lengths off the wire.</br>";
    problem.question += capitalFirst(person.subject) + " then cuts the rest of the wire into as many " + newCutLength + " cm lengths as possible.</p>";
    problem.question += "<p>Work out how many " + newCutLength + " cm lengths of wire " + person.name + " cuts.</p>";
    problem.answer = "<p>Wire left after the initial cuts is " + (wireLength - (preCuts * preCutLength)) + " cm.</p>";
    problem.answer += "<p>" + (wireLength - (preCuts * preCutLength)) + " &divide; " + newCutLength + " = " + (Math.round(newCuts * 1000) / 1000) + ".</p>";
    problem.answer += "<p>" + person.name + " cuts " + answer + " more lengths of wire.</p>";
    return problem;
}
function evenOddMultiples104() {
    var problem = {};
    problem.marks = 1;
    problem.tier = "F";
    problem.calc = false;
    var base = 2 * getRandom(2, 15) + 1;
    problem.question = "<p>Write down the first even multiple of " + base + ".</p>";
    problem.answer = "<p>" + (base * 2) + ".</p>";
    return problem;
}
function countersInABag105() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "F";
    problem.calc = false;

    do {
        var co = [];
        var base = getRandom(0, 20);
        var total = 0;
        for (var i = 0; i < 4; i++) {
            co.push({});
            co[i].colour = colourPicker(base + i);
            co[i].quantity = getRandom(2, 10);
            total += co[i].quantity;
        }
        var num = co[2].quantity + co[3].quantity;
        var hcf = HCF(num, total);
    } while (hcf === 1);
    var prob = "<sup>" + num / hcf + "</sup>&frasl;<sub>" + total / hcf + "</sub>";
    var person = namePicker();
    problem.question = "<p>There are " + total + " counters in  a bag.</p>";
    problem.question += "<p>" + co[0].quantity + " of the counters are " + co[0].colour + ".<br>";
    problem.question += co[1].quantity + " of the counters are " + co[1].colour + ".<br>";
    problem.question += co[2].quantity + " of the counters are " + co[2].colour + ".<br>";
    problem.question += "The rest of the counters are " + co[3].colour + ".</p>";
    problem.question += "<p>" + person.name + " takes a counter at random from the bag.</p>";
    problem.question += "<p>Show that the probability that this counter is " + co[2].colour + " or " + co[3].colour + " is " + prob + ".</p>";
    problem.answer = "<p>There must be " + co[3].quantity + " " + co[3].colour + " counters.</p>";
    problem.answer += "<p>There are " + (co[2].quantity + co[3].quantity) + " " + co[2].colour + " or " + co[3].colour + " counters.</p>";
    problem.answer += "<p>P(" + co[2].colour + " or " + co[3].colour + ") = <sup>" + num + "</sup>&frasl;<sub>" + total + "</sub> = " + prob + "</p>";
    return problem;
}
function wordedProbabilityScale106() {
    var problem = {};
    problem.marks = 2;
    problem.tier = "F";
    problem.calc = false;
    var p = [];
    p.push({letter: 'A', prob: "impossible"});
    p.push({letter: 'E', prob: "certain"});
    p.push({letter: 'C', prob: "evens"});
    p.push({letter: 'B', prob: "unlikely"});
    p.push({letter: 'D', prob: "likely"});
    do {
        var opt1 = getRandom(0, 2);
        var opt2 = getRandom(2, 4);
    } while (opt1 >= opt2);
    problem.question = "<p>Here is a probability scale.<br>";
    problem.question += "<p>It shows the probability of the events A, B, C, D and E.</p>";
    problem.question += "<img src='/media/gcseQuestions/106.jpg'>";
    problem.question += "<p>a) Write down the letter of the event that is " + p[opt1].prob + ".</p>";
    problem.question += "<p>b) Write down the letter of the event that is " + p[opt2].prob + ".</p>";
    problem.answer = "<p>a) " + p[opt1].letter + ".</p>";
    problem.answer += "<p>b) " + p[opt2].letter + ".</p>";
    return problem;
}
function squaresOnAnAxes107() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "FH";
    problem.calc = false;
    var squares = getRandom(3, 5);
    var sideLength = getRandom(3, 10);
    var disp = getRandom(1, sideLength - 1);
    var ax = getRandom(1, 6);
    var ay = getRandom(1, 6);
    var bx = ax + (squares * sideLength);
    var by = ay + (squares * sideLength) - disp;
    var cx = ax + (2 * sideLength);
    var cy = ay + (2 * sideLength) - disp;
    problem.question = "<p>A pattern is made from " + wordedNumber(squares) + " identical squares.</p>";
    problem.question += "<p>The sides of the squares are parallel to the axes.</p>";
    problem.question += "<img src='/media/gcseQuestions/107-" + (squares - 3) + ".jpg'>";
    problem.question += "<p>";
    problem.question += "Point A has coordinates (" + ax + ", " + ay + ").<br>";
    problem.question += "Point B has coordinates (" + bx + ", " + by + ").<br>";
    problem.question += "</p>";
    problem.question += "<p>Work out the coordinates of C.</p>";
    problem.answer = "<p>Each square has a side length of (" + bx + " - " + ax + ") &divide " + squares + " = " + sideLength + " units.</p>";
    problem.answer += "<p>Point C is (" + ay + " + " + squares + " &times " + sideLength + ") - " + by + " = " + disp + " units from the top right vertex of the square.</p>";
    problem.answer += "<p>Point C has coordinates (" + cx + ", " + cy + ").</p>";
    return problem;
}
function interiorExteriorAngles108() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var fact180 = [3, 4, 5, 6, 9, 10, 12, 15, 18, 20, 30, 36, 45, 60, 90];
    var x = fact180[getRandom(0, fact180.length - 1)];
    var multiple = x - 1;
    var exterior = (180 / x);
    var interior = 180 - exterior;
    var sides = 360 / exterior;
    var diff = interior - exterior;
    var difference = false;
    if (toss()) {
        difference = true;
    }
    if (difference) {
        problem.question = "<p>The interior angle of a regular polygon is " + diff + "&deg; more than the size of its exterior angle.</p>";
        problem.question += "<p>Work out how many sides the polygon has.</p>";
    } else {
        problem.question = "<p>The interior angle of a regular polygon is " + multiple + " times the size of its exterior angle.</p>";
        problem.question += "<p>Work out how many sides the polygon has.</p>";
    }

    problem.answer = "<p>Interior and exterior angles sum to 180&deg;.</p>";
    if (difference) {
        problem.answer += "<p>(x + " + diff + ") + x = 180&deg;.</p>";
        problem.answer += "<p>2x = " + (180 - diff) + "&deg;.</p>";
    } else {
        problem.answer += "<p>x + " + multiple + "x = 180&deg;.</p>";
        problem.answer += "<p>" + x + "x = 180&deg;.</p>";
    }
    problem.answer += "<p>x = " + exterior + "&deg.</p>";
    problem.answer += "<p>The polygon has 360 &divide " + exterior + " = " + sides + " sides.</p>";
    return problem;
}
function percentageWageBonus109() {
    var problem = {};
    problem.marks = 5;
    problem.tier = "FH";
    problem.calc = false;
    do {
        var bonus = 100 * getRandom(11, 41);
        var totalStaff = getRandom(8, 20);
        var managers = getRandom(2, totalStaff / 2);
        var salesmen = totalStaff - managers;
        var managerPart = 10 * getRandom(2, 5);
        var managerBonus = bonus * (managerPart / 100) / managers;
        var salesmenBonus = (bonus - (managerBonus * managers)) / salesmen;
        var fairBonus = bonus / totalStaff;
        var comparePercent = 5 * getRandom(1, 6);
        var compareBonus = salesmenBonus * (comparePercent / 100);
    } while (managerBonus <= salesmenBonus || managerBonus !== Math.round(managerBonus) || fairBonus !== Math.round(fairBonus) || salesmenBonus !== Math.round(salesmenBonus) || compareBonus !== Math.round(compareBonus));
    problem.question = "<p>A bonus of &pound;" + bonus + " is shared by " + totalStaff + " people who work for a company.</p>";
    problem.question += "<p>" + managerPart + "% of the bonus is shared equally between " + managers + " managers.<br>";
    problem.question += "The rest of the bonus is shared equally between " + salesmen + " salesmen.</p>";
    problem.question += "<p>A salesmen says, \"If the bonus is shared equally between all " + totalStaff + " people I will get at least " + comparePercent + "% more money.\"</p>";
    problem.question += "<p>Is the salesman correct? Show how you get your answer.</p>";

    problem.answer = "<p>Currently the bonus would be spilt as follows:</p>";
    problem.answer += "<p>Managers receive " + managers + " &times &pound" + managerBonus + ".<br>";
    problem.answer += "Salesmen receive " + salesmen + " &times &pound" + salesmenBonus + ".</p>";
    problem.answer += "<p>" + comparePercent + "% of &pound;" + salesmenBonus + " = &pound" + compareBonus + ".<br>";
    problem.answer += "Salesman bonus + " + comparePercent + "% = &pound;" + (salesmenBonus + compareBonus) + ".</p>";
    problem.answer += "<p>If the bonus was divided equally each person would receive &pound" + fairBonus + ".</p>";
    if ((salesmenBonus + compareBonus) < fairBonus) {
        problem.answer += "<p>Yes, the salesman is correct.</p>";
    } else {
        problem.answer += "<p>No, the salesman is not correct.</p>";
    }
    return problem;
}
function estimatingWithSpeedOfPlane110() {
    var problem = {};
    problem.marks = 3;
    problem.tier = "FH";
    problem.calc = false;
    var hours = 1;
    var seconds = hours * 3600;
    var speed = 100 * getRandom(1, 4);
    var adjust = getRandom(1, 15);
    if (toss()) {
        speed += adjust;
    } else {
        speed -= adjust;
    }
    var roundSpeed = Math.round(speed / 100) * 100;
    var estTime = seconds / roundSpeed;
    var unit = "mile";
    if (toss()) {
        unit = "kilometre";
    }
    problem.question = "<p>A plane is travelling at a speed of " + speed + " " + unit + "s per hour.</p>";
    problem.question += "<p>Work out an estimate for the number of seconds the plane takes to travel 1 " + unit + ".</p>";
    problem.question += "<p>State whether your answer is an overestimate or underestimate. You must give a reason.</p>";
    problem.answer = "<p>1 hour is 60 &times; 60 = 3600 seconds.</p>";
    problem.answer += "<p>" + speed + " &asymp; " + roundSpeed + ".</p>";
    problem.answer += "<p>Estimated time to travel 1 " + unit + " is 3600 &divide; " + roundSpeed + " = " + estTime + " seconds.</p>";
    if (speed < roundSpeed) {
        problem.answer += "<p>This is an underestimate as the speed has been rounded up.</p>";
    } else {
        problem.answer += "<p>This is an overstimate as the speed has been rounded down.</p>";
    }
    return problem;
}