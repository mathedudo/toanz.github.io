function fourOps(x,y,type){var problem={};switch(type){case "+":problem.question=x+" + "+y;problem.answer=x+y;break;case "-":problem.question=x+" &minus; "+y;problem.answer=x-y;break;case "*":problem.question=x+" &#215; "+y;problem.answer=x*y;break;case "/":problem.question=x+" &divide; "+y;problem.answer=x/y;break;}
problem.answer=roundError(problem.answer);return problem;}
function fractionOfAmount(num,den,amount){var problem={};problem.answer=roundError(amount*num/den);var whole=Math.floor(num/den);if(whole<0){whole++;if(whole!==0){num=Math.abs(num);}}
num=num%den;var hcf=HCF(num,den);num/=hcf;den/=hcf;var fraction="";if(whole!==0){fraction+=whole;}
fraction+="\\( \\frac{"+num+"}{"+den+"} \\)";problem.question=fraction+" of "+amount;return problem;}
function fractionalChange(num,den,amount,decrease){var problem={};if(decrease){problem.answer=amount-roundError(amount*num/den);}else{problem.answer=amount+roundError(amount*num/den);}
var whole=Math.floor(num/den);if(whole<0){whole++;if(whole!==0){num=Math.abs(num);}}
num=num%den;var hcf=HCF(num,den);num/=hcf;den/=hcf;var fraction="";if(whole!==0){fraction+=whole;}
fraction+="<sup>"+num+"</sup>/<sub>"+den+"</sub>";if(decrease){problem.question="Decrease "+amount+" by "+fraction;}else{problem.question="Increase "+amount+" by "+fraction;}
return problem;}
function percentageOfAmount(percentage,amount){var problem={};problem.question=percentage+"% of "+amount;problem.answer=roundError(percentage*amount/100);return problem;}
function percentageIncreaseDecrease(percentage,amount,increase,reverse){var problem={};if(increase){var newAmount=roundError(amount+percentage*amount/100);}else{newAmount=roundError(amount-percentage*amount/100);}
if(!reverse){if(increase){problem.question="Increase "+amount+" by "+percentage+"%";}else{problem.question="Decrease "+amount+" by "+percentage+"%";}
problem.answer=newAmount;}else{problem.question="<div class='smaller'>An amount was ";if(increase){problem.question+="increased";}else{problem.question+="decreased";}
problem.question+=" by "+percentage+"% to "+newAmount+".<br>";problem.question+="What was the original amount?</div>";problem.answer=amount;}
return problem;}
function percentageMultipliers(percentage,type){var problem={};problem.question="<div class='smaller'>";switch(type){case 0:problem.question+="What would you multiply by to find "+percentage+"% of an amount?";problem.answer=roundError(percentage/100);break;case 1:problem.question+="What would you multiply by to increase an amount by "+percentage+"%?";problem.answer=roundError((100+percentage)/100);break;case 2:problem.question+="What would you multiply by to decrease an amount by "+percentage+"%?";problem.answer=roundError((100-percentage)/100);break;}
problem.question+="</div>";return problem;}
function percentageChange(oldAmount,newAmount){var problem={};problem.question="<div class='smaller'>";if(oldAmount>newAmount){problem.question+="An amount was decreased from "+oldAmount+" to "+newAmount+".";problem.question+="<br>Work out the percentage decrease.";}else{problem.question+="An amount was increased from "+oldAmount+" to "+newAmount+".";problem.question+="<br>Work out the percentage increase.";}
problem.answer=roundError(100*Math.abs(oldAmount-newAmount)/oldAmount)+"%";problem.question+="</div>";return problem;}
function repeatedPercentageChange(originalAmount,percentage,iterations,increase){var problem={};var units=["second","minute","hour","day","week","year"];var timeUnit=units[getRandom(0,units.length-1)];var newAmount;problem.question="<div class='smaller'>";if(increase){problem.question+="An amount of "+originalAmount+" is increased by "+percentage+"% every "+timeUnit+".<br>";problem.question+="How much will it be worth after "+iterations+" "+timeUnit+"s?";newAmount=originalAmount*Math.pow(1+percentage/100,iterations);}else{problem.question+="An amount of "+originalAmount+" is decreased by "+percentage+"% every "+timeUnit+".<br>";problem.question+="How much will it be worth after "+iterations+" "+timeUnit+"s?";newAmount=originalAmount*Math.pow(1-percentage/100,iterations);}
problem.question+="</div>";problem.answer=Math.round(100*newAmount)/100;return problem;}
function halving(x){var problem={};problem.question="Half of "+x
problem.answer=roundError(x/2);return problem;}
function doubling(x){var problem={};problem.question="Double "+x
problem.answer=roundError(x*2);return problem;}
function rounding(x,accuracy){var problem={};var suffix=accuracy;if(accuracy==1){suffix="the nearest whole number";}
if(accuracy>1){suffix="the nearest "+accuracy;}
if(accuracy<1){suffix=-Math.round(Math.log(accuracy)/Math.log(10))+" d.p";}
problem.question="Round "+x+" to "+suffix+"";problem.answer=roundError(Math.round(x/accuracy)*accuracy);if(accuracy<1){problem.answer=problem.answer.toFixed(-Math.round(Math.log(accuracy)/Math.log(10)));}
return problem;}
function sigFigs(x,accuracy){var problem={};problem.question="Round "+x+" to "+accuracy+" s.f";problem.answer=x.toPrecision(accuracy)-0;return problem;}
function ratioShare(amount,ratio){var problem={};problem.answer="";var parts=0;problem.question="Share "+amount+" in the ratio ";for(var i=0;i<ratio.length;i++){parts+=ratio[i];problem.question+=ratio[i]+":";}
problem.question=problem.question.slice(0,-1);var amountPerPart=amount/parts;for(i=0;i<ratio.length;i++){problem.answer+=ratio[i]*amountPerPart+":";}
problem.answer=problem.answer.slice(0,-1);return problem;}
function ratioReverse(amount,ratio){var problem={};problem.answer="";var parts=0;problem.question="<div class='smaller'>An amount was shared in the ratio ";for(var i=0;i<ratio.length;i++){parts+=ratio[i];problem.question+=ratio[i]+":";}
problem.question=problem.question.slice(0,-1);var amountPerPart=amount/parts;switch(getRandom(0,3)){case 0:problem.question+=". The largest share was "+Math.max.apply(Math,ratio)*amountPerPart+".<br>";problem.question+="What was the smallest share?</div>";problem.answer=Math.min.apply(Math,ratio)*amountPerPart;break;case 1:problem.question+=". The smallest share was "+Math.min.apply(Math,ratio)*amountPerPart+".<br>";problem.question+="What was the largest share?</div>";problem.answer=Math.max.apply(Math,ratio)*amountPerPart;break;case 2:problem.question+=". The largest share was "+Math.max.apply(Math,ratio)*amountPerPart+".<br>";problem.question+="What was the total amount shared?</div>";problem.answer=amount;break;case 3:problem.question+=". The smallest share was "+Math.min.apply(Math,ratio)*amountPerPart+".<br>";problem.question+="What was the total amount shared?</div>";problem.answer=amount;break;}
return problem;}
function ratioDifference(amount,ratio){var problem={};problem.answer="";var parts=0;var person=[];var ratioDisp="";var seed=getRandom(0,20);for(var i=0;i<ratio.length;i++){parts+=ratio[i];ratioDisp+=ratio[i]+":";person.push(namePicker(i+seed));}
ratioDisp=ratioDisp.slice(0,-1);var amountPerPart=amount/parts;if(ratio.length<3){problem.question="<div class='smaller'>"+person[0].name+" and "+person[1].name+" shared some money in the ratio "+ratioDisp;}else{problem.question="<div class='smaller'>"+person[0].name+", "+person[1].name+" and "+person[2].name+" shared some money in the ratio "+ratioDisp;}
do{var c1=getRandom(0,ratio.length-1);var c2=getRandom(0,ratio.length-1);}while(c1===c2);var c3=getRandom(0,ratio.length-1);var c1Amount=ratio[c1]*amountPerPart;var c2Amount=ratio[c2]*amountPerPart;var diff=c2Amount-c1Amount;if(diff<0){var adj="more than";}else if(diff>0){adj="less than";}else{adj="the same as";}
problem.question+=".<br>";problem.question+=person[c1].name+" gets &pound;"+Math.abs(diff)+" "+adj+" "+person[c2].name+".<br>";problem.question+="How much does "+person[c3].name+" receive?</div>";problem.answer="&pound;"+ratio[c3]*amountPerPart;return problem;}
function convertFDP(type,num,den){var problem={};var decimal=roundError(num/den);var percentage=roundError(decimal*100);num=roundError(num);den=roundError(den);var whole=Math.floor(num/den);if(whole<0){whole++;if(whole!=0){num=Math.abs(num);}}
num=num%den;var hcf=HCF(num,den);num/=hcf;den/=hcf;var fraction="";var typedFraction="";if(whole!=0){fraction+=whole;typedFraction+=whole;}
if(whole!=0&&num!=0){typedFraction+=" ";}
if(num!=0){fraction+="<sup>"+num+"</sup>&frasl;<sub>"+den+"</sub>";typedFraction+=num+"/"+den;}
if(whole==0&&num==0){fraction+="0";typedFraction="0";}
problem.question="";switch(type){case "PD":problem.question+=percentage+"% as a decimal";problem.answer=decimal;break;case "DP":problem.question+=decimal+" as a percentage";problem.answer=percentage+"%";break;case "DF":problem.question+=decimal+" as a fraction";problem.answer=fraction;problem.typedAnswer=typedFraction;break;case "PF":problem.question+=percentage+"% as a fraction";problem.answer=fraction;problem.typedAnswer=typedFraction;break;case "FD":problem.question+=fraction+" as a decimal";problem.answer=decimal;break;case "FP":problem.question+=fraction+" as a percentage";problem.answer=percentage+"%";break;}
return problem;}
function collectingTerms(letters,variables,coeff){var problem={};var totalTerms=coeff.length;problem.question="<div>Simplify</div>\\(";for(var i=0;i<totalTerms;i++){if(coeff[i]>0&&i>0){problem.question+=" + ";}
if(coeff[i]<0){problem.question+=" - ";}
if(Math.abs(coeff[i])>1){problem.question+=Math.abs(coeff[i]);}
if(coeff[i]!=0){problem.question+=variables[i];}}
problem.question+="\\)";var collected=new Array();for(i=0;i<letters.length;i++){var count=0;for(var j=0;j<totalTerms;j++){if(variables[j]==letters[i]){count+=coeff[j];}}
collected.push(count);}
var answer="";for(i=0;i<letters.length;i++){if(collected[i]>0&&i>0){answer+=" + ";}
if(collected[i]<0){answer+=" - ";}
if(Math.abs(collected[i])>1){answer+=Math.abs(collected[i]);}
if(collected[i]!=0){answer+=letters[i];}}
if(answer===""){answer="0";}
problem.typedAnswer=answer;problem.answer="\\("+answer+"\\)";return problem;}
function multiplyingTerms(type,negatives){var problem={};var l=[];var choice=getRandom(0,20);for(var i=0;i<4;i++){l.push(letterPicker(choice+i));}
var c=[];for(i=0;i<4;i++){c.push(getRandom(2,8+i));if(negatives&&toss()){c[i]=-c[i];}}
problem.question="Simplify:<br>";if(type>5){type=5;}
switch(type){case 0:if(toss()){problem.question+=c[0]+l[0]+" &#215; "+c[1];}else{problem.question+=c[0]+" &#215; "+c[1]+l[0];}
problem.answer=(c[0]*c[1])+l[0];break;case 1:if(toss()){problem.question+=l[0]+" &#215; "+l[0];problem.answer=l[0]+"&sup2;";problem.typedAnswer=l[0]+"^2";}else if(toss()){problem.question+=l[0]+" &#215; "+l[0]+" &#215; "+l[0];problem.answer=l[0]+"&sup3;";problem.typedAnswer=l[0]+"^3";}else{problem.question+=l[0]+" &#215; "+l[0]+" &#215; "+l[0]+" &#215; "+l[0];problem.answer=l[0]+"<sup>4</sup>";problem.typedAnswer=l[0]+"^4";}
break;case 2:if(toss()){problem.question+=l[0]+" &#215; "+l[1];problem.answer=l[0]+l[1];}else{problem.question+=l[0]+" &#215; "+l[1]+" &#215; "+l[2];problem.answer=l[0]+l[1]+l[2];}
break;case 3:if(toss()){problem.question+=c[0]+l[0]+" &#215; "+c[1]+l[1];problem.answer=(c[0]*c[1])+l[0]+l[1];}else{problem.question+=c[0]+l[0]+" &#215; "+c[1]+l[0];problem.answer=(c[0]*c[1])+l[0]+"&sup2;";problem.typedAnswer=(c[0]*c[1])+l[0]+"^2";}
break;case 4:if(toss()){problem.question+=c[0]+l[0]+l[1]+" &#215; "+c[1]+l[0];problem.answer=(c[0]*c[1])+l[0]+"&sup2;"+l[1];}else{problem.question+=c[0]+l[0]+l[1]+" &#215; "+c[1]+l[0]+l[1];problem.answer=(c[0]*c[1])+l[0]+"&sup2;"+l[1]+"&sup2;";}
break;case 5:if(toss()){problem.question+=c[0]+l[0]+"&sup2;"+l[1]+" &#215; "+c[1]+l[0]+" &#215; "+l[1]+l[2];problem.answer=(c[0]*c[1])+l[0]+"&sup3;"+l[1]+"&sup2;"+l[2];}else{problem.question+=c[0]+l[1]+l[2]+" &#215; "+c[1]+l[1]+" &#215; "+c[2]+l[0]+l[2];problem.answer=(c[0]*c[1]*c[2])+l[0]+l[1]+"&sup2;"+l[2]+"&sup2;";}
break;}
return problem;}
function factors(maxFactors,minNumber,maxNumber){var problem={};var totalFactors=maxFactors+1;while(totalFactors>maxFactors){totalFactors=1;var answer="1";var x=getRandom(minNumber,maxNumber);if(x%2==1&&Math.random()<0.5&&x<maxNumber){x++;}
for(var i=2;i<=x;i++){if(x%i==0){answer+=","+i;totalFactors++;}}}
problem.question="Factors of "+x;problem.answer=answer;return problem;}
function multiples(multiple,x){var problem={};problem.question=multiple+ordinal(multiple)+" multiple of "+x;problem.answer=x*multiple;return problem;}
function hcf(x,y,z){var problem={};if(z){problem.question="HCF of "+x+", "+y+" and "+z;problem.answer=HCF(HCF(x,y),z);}else{problem.question="HCF of "+x+" and "+y;problem.answer=HCF(x,y);}
return problem;}
function lcm(x,y,z){var problem={};if(z){var temp=x*y/(HCF(x,y));problem.question="LCM of "+x+", "+y+" and "+z;problem.answer=temp*z/HCF(temp,z);}else{problem.question="LCM of "+x+" and "+y;problem.answer=x*y/(HCF(x,y));}
return problem;}
function simplifyingRatios(terms,maxPrime){var problem={};var simplifiedRatio=Array(terms);var ratio=new Array(terms);var multiplier=getRandom(2,maxPrime);for(var i=0;i<ratio.length;i++){simplifiedRatio[i]=getRandom(1,maxPrime);while(!isPrime(simplifiedRatio[i])){simplifiedRatio[i]=getRandom(1,maxPrime);}
ratio[i]=simplifiedRatio[i]*multiplier;}
while(simplifiedRatio[0]==simplifiedRatio[1]){simplifiedRatio[1]=getRandom(1,maxPrime);while(!isPrime(simplifiedRatio[1])){simplifiedRatio[1]=getRandom(1,maxPrime);}
ratio[1]=simplifiedRatio[1]*multiplier;}
problem.question="Simplify ";problem.answer="";for(i=0;i<ratio.length-1;i++){problem.question+=ratio[i]+":";problem.answer+=simplifiedRatio[i]+":";}
problem.question+=ratio[i];problem.answer+=simplifiedRatio[i];return problem;}
function simplifyingFractions(maxPrime){var problem={};var numerator=getRandom(1,maxPrime/2);var denominator=getRandom(2,maxPrime);while(denominator<=numerator||HCF(numerator,denominator)!=1){denominator=getRandom(1,maxPrime);}
var multiplier=getRandom(maxPrime/4,maxPrime);problem.question="Simplify <sup>"+numerator*multiplier+"</sup>/<sub>"+denominator*multiplier+"</sub>";problem.answer=numerator+"/"+denominator;return problem;}
function nthTermFinding(a,b,c){var problem={};var terms=[];for(var i=1;i<5;i++){terms.push((a*i*i)+(b*i)+(c));}
problem.question="<div class='smaller'>Find the n<sup>th</sup> term of<br>";for(var i=0;i<terms.length;i++){problem.question+=terms[i]+", ";}
problem.question+="...</div>";problem.answer="n<sup>th</sup> term = ";problem.typedAnswer="";var firstTerm=true;problem.answer+=fixTerm(a,"n&sup2;",firstTerm);problem.typedAnswer+=fixTerm(a,"n^2",firstTerm);if(a!=0){firstTerm=false;}
problem.answer+=fixTerm(b,"n",firstTerm);problem.typedAnswer+=fixTerm(b,"n",firstTerm);if(b!=0){firstTerm=false;}
problem.answer+=fixTerm(c,"",firstTerm);problem.typedAnswer+=fixTerm(c,"",firstTerm);return problem;}
function sequencesNextTerm(a,b,c){var problem={};var terms=[];var sequence="";for(var i=1;i<5;i++){terms.push(roundError((a*i*i)+(b*i)+(c)));sequence+=terms[i-1]+", ";}
sequence+=" ?";problem.question=sequence;problem.answer=(a*5*5)+(b*5)+(c);return problem;}
function nthTermGenerating(a,b,c){var problem={};var term=getRandom(1,10);var nthTerm="";var firstTerm=true;nthTerm+=fixTerm(a,"n&sup2;",firstTerm);if(a!==0){firstTerm=false;}
nthTerm+=fixTerm(b,"n",firstTerm);if(b!==0){firstTerm=false;}
nthTerm+=fixTerm(c,"",firstTerm);problem.question="<div class='smaller'> Find the "+term+ordinal(term)+" term given:<br>n<sup>th</sup> term =  "+nthTerm+"</div>";problem.answer=(a*term*term)+(b*term)+c;return problem;}
function addingCoins(coins){var problem={};var coin=new Array("1p","2p","5p","10p","20p","50p","&pound;1","&pound;2");var value=new Array(1,2,5,10,20,50,100,200);var quantity=new Array(0,0,0,0,0,0,0,0);var total=0;var coinsUsed=0;var plural="";for(var i=0;i<coins;i++){quantity[Math.floor(Math.random()*coin.length)]+=1;}
problem.question="<div class='smaller'>Add together:<br>";var singleValue=true;for(i=0;i<coin.length;i++){if(quantity[i]>0){if(quantity[i]>1){plural="'s";}else{plural="";}
coinsUsed+=quantity[i];if(coinsUsed===coins&&!singleValue){problem.question+="and "+wordedNumber(quantity[i])+" "+coin[i]+plural+". ";}else{problem.question+=wordedNumber(quantity[i])+" "+coin[i]+plural+", ";}
singleValue=false;}
total+=value[i]*quantity[i];}
problem.question=problem.question.slice(0,-2);problem.question+=".</div>";problem.answer=toPounds(total);problem.typedAnswer=(total/100).toFixed(2);return problem;}
function countingCoins(quantity){var problem={};var coin=new Array("2p","5p","10p","20p","50p","&pound;2");var value=new Array(2,5,10,20,50,200);var currentCoin=Math.floor(Math.random()*coin.length);var total=quantity*value[currentCoin];problem.question="<div class='smaller'>How many "+coin[currentCoin]+" coins are in "+toPounds(total)+"?</div>";problem.answer=quantity;return problem;}
function speedDistTime(speed,time,type){var problem={};var distanceUnit="m";var timeUnit="s";if(Math.random()<0.5){distanceUnit="km";timeUnit="h";}
var speedUnit=distanceUnit+"/"+timeUnit;var distance=speed*time;problem.question="<div class='smaller'>";switch(type){case 0:problem.question+="An object travels at "+speed+" "+speedUnit+" for "+time+" "+timeUnit+".<br>How far does it travel?";problem.answer=distance+" "+distanceUnit;problem.typedAnswer=distance+" "+distanceUnit;break;case 1:problem.question+="An object travels at "+speed+" "+speedUnit+" for "+distance+" "+distanceUnit+".<br>How long did it take?";problem.answer=time+" "+timeUnit;problem.typedAnswer=time+timeUnit;break;case 2:problem.question+="An object travels "+distance+" "+distanceUnit+" in "+time+" "+timeUnit+".<br>What speed was it travelling?";problem.answer=speed+" "+speedUnit;problem.typedAnswer=speed+speedUnit;break;}
problem.question+="</div>";return problem;}
function powersAndRoots(x,a,b){var problem={};if(a==0){problem.question=x+"<sup>"+a+"</sup>";}else if(b==2&&a==1){problem.question="&radic; "+x;}else if(b==3&&a==1){problem.question="&#8731; "+x;}else if(b!=1){problem.question=x+"<sup>"+a+"&frasl;"+b+"</sup>";}else{problem.question=x+"<sup>"+a+"</sup>";}
if(a<0&&x!=1){x=roundError(Math.pow(x,Math.abs(a)/b));problem.answer="<sup>1</sup>&frasl;<sub>"+x+"</sub>";problem.typedAnswer=1+"/"+x;}else{x=roundError(Math.pow(x,a/b));problem.answer=x;}
return problem;}
function ordering(length,decimal,negative,descending,range){var list=new Array(length);var problem={};var sequence="";for(var i=0;i<list.length;i++){list[i]=Math.floor(Math.random()*range);if(decimal){list[i]/=Math.pow(10,getRandom(0,2));}
if(negative){list[i]=-list[i];}}
problem.question="<div class='smaller'>Write in ";if(descending){problem.question+="descending";}else{problem.question+="ascending";}
problem.question+=" order:<br>";for(i=0;i<list.length-1;i++){problem.question+=list[i]+", ";}
problem.question+=list[i];if(descending){list.sort(function(a,b){return b-a});}else{list.sort(function(a,b){return a-b});}
for(i=0;i<list.length-1;i++){sequence+=list[i]+", ";}
sequence+=list[i];problem.question+=".</div>";problem.answer=list;return problem;}
function oneStepEquations(type,x,answer,inequality){var problem={};var letter=letterPicker();var side1,side2;var symbol="=";if(inequality){switch(getRandom(0,3)){case 0:symbol="&lt;";break;case 1:symbol="&le;";break;case 2:symbol="&gt;";break;case 3:symbol="&ge;";break;}
if(type===7){type=getRandom(0,4);}}
switch(type){case 0:side1=letter+" + "+x;side2=x+answer;break;case 1:side1=x+" + "+letter;side2=x+answer;break;case 2:side1=x+letter;side2=x*answer;break;case 3:side1=letter+" - "+x;side2=answer-x;break;case 4:side1=x+" - "+letter;side2=x-answer;break;case 5:side1="<sup>"+letter+"</sup>&frasl;<sub>"+x+"</sub>";side2=answer/x;break;case 6:side1="<sup>"+x+"</sup>&frasl;<sub>"+letter+"</sub>";side2=x/answer;break;case 7:side1=letter+"<sup>"+x+"</sup>";side2=Math.pow(answer,x);break;}
side2=roundError(side2);problem.question="Solve:<br>";if(Math.random()<0.5||inequality){problem.question+=side1+" "+symbol+" "+side2;}else{problem.question+=side2+" "+symbol+" "+side1;}
answer=roundError(answer);if(!inequality){problem.answer=letter+" "+symbol+" "+answer;problem.typedAnswer=letter+symbol+answer;}else{problem.answer=answer;}
return problem;}
function twoStepEquations(type,x,y,answer,inequality){var problem={};var letter=letterPicker();var side1,side2;var symbol="=";if(inequality){switch(getRandom(0,3)){case 0:symbol="&lt;";break;case 1:symbol="&le;";break;case 2:symbol="&gt;";break;case 3:symbol="&ge;";break;}
if(type>6){type=getRandom(0,6);}}
switch(type){case 0:side1=x+letter+" + "+y;side2=answer*x+y;break;case 1:side1=x+letter+" - "+y;side2=answer*x-y;break;case 2:side1=y+" + "+x+letter;side2=answer*x+y;break;case 3:side1="<sup>"+letter+"</sup>&frasl;<sub>"+x+"</sub> + "+y;side2=answer/x+y;break;case 4:side1="<sup>"+letter+"</sup>&frasl;<sub>"+x+"</sub> - "+y;side2=answer/x-y;break;case 5:side1=y+" + <sup>"+letter+"</sup>&frasl;<sub>"+x+"</sub>";side2=answer/x+y;break;case 6:side1=y+" - "+x+letter;side2=-(answer*x-y);break;case 7:side1=letter+"<sup>"+x+"</sup> + "+y;side2=Math.pow(answer,x)+y;break;case 8:side1=letter+"<sup>"+x+"</sup> - "+y;side2=Math.pow(answer,x)-y;break;}
side2=roundError(side2);problem.question="Solve:<br>";if(Math.random()<0.5||inequality){problem.question+=side1+" "+symbol+" "+side2;}else{problem.question+=side2+" "+symbol+" "+side1;}
answer=roundError(answer);if(!inequality){problem.answer=letter+" "+symbol+" "+answer;problem.typedAnswer=letter+symbol+answer;}else{problem.answer=answer;}
return problem;}
function threeStepEquations(x,y,z,answer,reversable,inequality){var problem={};var letter=letterPicker();var side1,side2;var symbol="=";if(inequality){switch(getRandom(0,3)){case 0:symbol="&lt;";break;case 1:symbol="&le;";break;case 2:symbol="&gt;";break;case 3:symbol="&ge;";break;}}
if(reversable&&Math.random()<0.5){side1=fixTerm(z,"",true)+fixTerm((x+y),letter,false);}else{side1=fixTerm((x+y),letter,true)+fixTerm(z,"",false);}
if(reversable&&Math.random()<0.5){side2=fixTerm(roundError(x*answer+z),"",true)+fixTerm(y,letter,false);}else{side2=fixTerm(y,letter,true)+fixTerm(roundError(x*answer+z),"",false);}
problem.question="Solve:<br>";if((reversable&&Math.random()<0.5)||inequality){problem.question+=side1+" "+symbol+" "+side2;}else{problem.question+=side2+" "+symbol+" "+side1;}
answer=roundError(answer);if(!inequality){problem.answer=letter+" "+symbol+" "+answer;problem.typedAnswer=letter+symbol+answer;}else{problem.answer=answer;}
return problem;}
function equationsWithBrackets(x,y,z,answer,reversable){var problem={};var letter=letterPicker();var side1,side2;if(reversable){side1="\\("+fixTerm(x,"",true)+"("+fixTerm(z,"",true)+fixTerm(y,letter,false)+") \\)";}else{side1="\\("+fixTerm(x,"",true)+"("+fixTerm(y,letter,true)+fixTerm(z,"",false)+") \\)";}
side2=roundError(x*(y*answer+z));problem.question="Solve:<br>";if(Math.random()<0.5&&reversable){problem.question+=side2+" = "+side1;}else{problem.question+=side1+" = "+side2;}
answer=roundError(answer);problem.answer=letter+" = "+answer;problem.typedAnswer=letter+"="+answer;return problem;}
function equationsWithBracketsBoth(a,b,c,d,e,f,answer,reversable){var problem={};var letter=letterPicker();var side1,side2;if(reversable){side1=fixTerm(a,"",true)+"("+fixTerm(c,"",true)+fixTerm(b,letter,false)+")";}else{side1=fixTerm(a,"",true)+"("+fixTerm(b,letter,true)+fixTerm(c,"",false)+")";}
side2=fixTerm(d,"",true)+"("+fixTerm(e,letter,true)+fixTerm(f,"",false)+")";problem.question="Solve:<br>";if(Math.random()<0.5&&reversable){problem.question+=side2+" = "+side1;}else{problem.question+=side1+" = "+side2;}
answer=roundError(answer);problem.answer=letter+" = "+answer;problem.typedAnswer=letter+"="+answer;return problem;}
function numberBonds(type,bond,x){var problem={};switch(type){case 0:problem.question=x+" + &#9634; = "+bond;break;case 1:problem.question="&#9634; + "+x+" = "+bond;break;case 2:problem.question=bond+" - "+" &#9634; = "+x;break;case 3:problem.question=bond+" - "+x+" = &#9634;";break;case 4:problem.question=bond+"+"+x+"+&#9634; = "+bond+"+"+bond;break;case 5:problem.question=bond+"+"+"&#9634;+"+x+" = "+bond+"+"+bond;break;case 6:problem.question=bond+"+"+bond+"-"+"&#9634; = "+bond+"+"+x;break;case 7:problem.question=bond+"+"+bond+"-"+x+" = "+bond+"+&#9634;";break;}
problem.answer="&#9634; = "+roundError(bond-x);problem.typedAnswer=roundError(bond-x);return problem;}
function fourOpsFractions(w1,n1,d1,w2,n2,d2,w3,n3,d3,o1,o2){var problem={};if(w1===0){w1="";}
if(w2===0){w2="";}
if(w3===0){w3="";}
var f1=w1+"<sup>"+n1+"</sup>"+"&frasl;<sub>"+d1+"</sub>";var f2=w2+"<sup>"+n2+"</sup>"+"&frasl;<sub>"+d2+"</sub>";var f3=w3+"<sup>"+n3+"</sup>"+"&frasl;<sub>"+d3+"</sub>";n1=w1*d1+n1;n2=w2*d2+n2;n3=w3*d3+n3;if(o1=="+"){var num=n1*d2+n2*d1;var den=d1*d2;}else if(o1=="-"){num=n1*d2-n2*d1;den=d1*d2;}else if(o1=="&#215;"){num=n1*n2;den=d1*d2;}else if(o1=="&divide;"){num=n1*d2;den=d1*n2;}
if(o2=="+"){num=num*d3+n3*den;den*=d3;}else if(o2=="-"){num=num*d3-n3*den;den*=d3;}else if(o2=="&#215;"){num=num*n3;den=den*d3;}else if(o2=="&divide;"){num=num*d3;den=den*n3;}
problem.question=f1+" "+o1+" "+f2;if(o2){problem.question+=" "+o2+" "+f3;}
var whole=Math.floor(num/den);if(whole<0){whole++;if(whole!=0){num=Math.abs(num);}}
num=num%den;var hcf=HCF(num,den);num/=hcf;den/=hcf;problem.answer="";problem.typedAnswer="";if(whole!=0){problem.answer+=whole;problem.typedAnswer+=whole;}
if(whole!=0&&num!=0){problem.typedAnswer+=" ";}
if(num!=0){problem.answer+="<sup>"+num+"</sup>&frasl;<sub>"+den+"</sub>";problem.typedAnswer+=num+"/"+den;}
if(whole==0&&num==0){problem.answer+="0";problem.typedAnswer="0";}
return problem;}
function mean(data){var problem={};var total=0;for(var i=0;i<data.length;i++){total+=data[i];}
var mean=total/data.length;problem.question="<div class='smaller'>Find the mean of:<br>"
for(var i=0;i<data.length;i++){problem.question+=data[i]+", ";}
problem.question=problem.question.slice(0,-2);problem.question+="</div>";problem.answer=mean;return problem;}
function median(data){var problem={};var median;problem.question="<div class='smaller'>Find the median of:<br>"
for(var i=0;i<data.length;i++){problem.question+=data[i]+", ";}
problem.question=problem.question.slice(0,-2);problem.question+="</div>";data.sort(function(a,b){return a-b;});if(data.length%2==1){median=data[(data.length+1)/2-1];}else{median=roundError((data[data.length/2]+data[data.length/2-1])/2);}
problem.answer=median;return problem;}
function range(data){var problem={};problem.question="<div class='smaller'>Find the range of:<br>"
for(var i=0;i<data.length;i++){problem.question+=data[i]+", ";}
problem.question=problem.question.slice(0,-2);problem.question+="</div>";data.sort(function(a,b){return a-b;});var range=data[data.length-1]-data[0];problem.answer=range;return problem;}
function mode(data){var problem={};problem.question="<div class='smaller'>Find the mode of:<br>"
for(var i=0;i<data.length;i++){problem.question+=data[i]+", ";}
problem.question=problem.question.slice(0,-2);problem.question+="</div>";var mode=[];var count=[];var maxFrequency=1;var current=0;for(var i=0;i<data.length;i++){for(var j=0;j<data.length;j++){if(data[i]==data[j]){current++;}}
count.push(current);if(current>maxFrequency){maxFrequency=current;}
current=0;}
for(var i=0;i<data.length;i++){if(count[i]==maxFrequency&&count[i]>1){mode.push(data[i]);}}
if(!isNaN(mode[0])){mode.sort(function(a,b){return a-b;});}else{mode.sort();}
if(mode.length==0){problem.answer="no mode";}else{var currentMode="";problem.answer="";for(i=0;i<mode.length;i++){if(mode[i]!=currentMode){problem.answer+=mode[i]+", ";currentMode=mode[i];}}
problem.answer=problem.answer.slice(0,-2);}
return problem;}
function standardForm(x,y,op){var problem={};var a={};switch(op){case "*":op="&#215;";a.co=x.co*y.co;a.pow=x.pow+y.pow;break;case "/":op="&divide;";a.co=x.co/y.co;a.pow=x.pow-y.pow;break;case "+":op="+";a.co=x.co*Math.pow(10,x.pow)+y.co*Math.pow(10,y.pow);a.pow=0;break;case "-":op="-";a.co=x.co*Math.pow(10,x.pow)-y.co*Math.pow(10,y.pow);a.pow=0;break;}
problem.question="("+x.co+" &#215; 10<sup>"+x.pow+"</sup>) "+op+" ("+y.co+" &#215; 10<sup>"+y.pow+"</sup>)";while(a.co>=10){a.co/=10;a.pow++;}
while(a.co<1&&a.co>0){a.co*=10;a.pow--;}
a.co=roundError(a.co);problem.answer=a.co+" &#215; 10<sup>"+a.pow+"</sup>";problem.typedAnswer=a.co+"*10^"+a.pow;return problem;}
function convertingStandardForm(x,type){var problem={};problem.question="<div class='smaller'>";switch(type){case 0:problem.question+="Write "+roundError(x.co*Math.pow(10,x.pow))+" in standard form.";checkCo(x);problem.answer=roundError(x.co)+" &#215; 10<sup>"+x.pow+"</sup>";problem.typedAnswer=roundError(x.co)+"*10^"+x.pow;break;case 1:problem.question+="Write "+roundError(x.co)+" &#215; 10<sup>"+x.pow+"</sup> as an ordinary number.";checkCo(x);problem.answer=roundError(x.co*Math.pow(10,x.pow));break;case 2:problem.question+="Write "+roundError(x.co)+" &#215; 10<sup>"+x.pow+"</sup> in standard form.";checkCo(x);problem.answer=roundError(x.co)+" &#215; 10<sup>"+x.pow+"</sup>";problem.typedAnswer=roundError(x.co)+"*10^"+x.pow;break;}
function checkCo(term){while(term.co>=10){term.co/=10;term.pow++;}
while(term.co<1&&term.co>0){term.co*=10;term.pow--;}
roundError(term.co);return term;}
problem.question+="</div>";return problem;}
function convertingFractions(num,den,toMixed){var problem={};var hcf=HCF(num,den);num/=hcf;den/=hcf;var improper="<sup>"+num+"</sup>&frasl;<sub>"+den+"</sub>"
var mixed=Math.floor(num/den)+"<sup>"+(num%den)+"</sup>&frasl;<sub>"+den+"</sub>";if(toMixed){problem.question=improper+" as a mixed number";problem.answer=mixed;problem.typedAnswer="";}else{problem.question=mixed+"</sub> as an improper fraction";problem.answer=improper;problem.typedAnswer="";}
return problem;}
function convertingMetricLength(m,from,to){var problem={};var unit=new Array("mm","cm","m","km");var cm=roundError(m*100);var mm=roundError(cm*10);var km=roundError(m/1000);var value=new Array(mm,cm,m,km);problem.question="Convert "+value[from]+" "+unit[from]+" to "+unit[to];switch(to){case 0:problem.answer=mm;break;case 1:problem.answer=cm;break;case 2:problem.answer=m;break;case 3:problem.answer=km;break;}
problem.answer+=" "+unit[to];return problem;}
function convertingMetricWeight(kg,from,to){var problem={};var unit=new Array("mg","g","kg","tonnes");var g=roundError(kg*1000);var mg=roundError(g*1000);var tonnes=roundError(kg/1000);var value=new Array(mg,g,kg,tonnes);problem.question="Convert "+value[from]+" "+unit[from]+" to "+unit[to];switch(to){case 0:problem.answer=mg;break;case 1:problem.answer=g;break;case 2:problem.answer=kg;break;case 3:problem.answer=tonnes;break;}
problem.answer+=" "+unit[to];return problem;}
function convertingMetricVolume(l,from,to){var problem={};var unit=new Array("ml","cl","litres");var cl=roundError(l*100);var ml=roundError(cl*10);var value=new Array(ml,cl,l);problem.question="Convert "+value[from]+" "+unit[from]+" to "+unit[to];switch(to){case 0:problem.answer=ml;break;case 1:problem.answer=cl;break;case 2:problem.answer=l;break;}
problem.answer+=" "+unit[to];return problem;}
function basicProbability(type){var problem={};problem.question="<div class='smaller'>";switch(type){case 0:var side="heads";if(Math.random()<0.5){side="tails";}
problem.question+="A fair coin is flipped. What is the probability of getting "+side+"?";problem.answer="<sup>1</sup>&frasl;<sub>2</sub>";problem.typedAnswer="1/2";break;case 1:problem.question+="A fair six sided dice is rolled. What is the probability of rolling a "+getRandom(1,6)+"?";problem.answer="<sup>1</sup>&frasl;<sub>6</sub>";problem.typedAnswer="1/6";break;case 2:var sides=2*getRandom(2,6);var number=getRandom(2,sides);var noun="less";var outcomes=number-1;if(Math.random()<0.5){noun="more";outcomes=sides-number;}
problem.question+="A fair "+sides+" sided spinner labelled 1 to "+sides+" is spun. What is the probability of spinning a number "+noun+" than "+number+"?";problem.answer="<sup>"+outcomes+"</sup>&frasl;<sub>"+sides+"</sub>";problem.typedAnswer=outcomes+"/"+sides;break;case 3:switch(getRandom(0,4)){case 0:noun="two heads";outcomes=1;break;case 1:noun="two tails";outcomes=1;break;case 2:noun="at least one heads";outcomes=3;break;case 3:noun="at least one tails";outcomes=3;break;case 4:noun="exactly one head and tails";outcomes=2;break;}
problem.question+="A fair coin is flipped twice. What is the probability of getting "+noun+"?";problem.answer="<sup>"+outcomes+"</sup>&frasl;<sub>4</sub>";problem.typedAnswer=outcomes+"/4";break;}
problem.question+="</div>";return problem;}
function expectedFrequency(trials){var problem={};var number=getRandom(1,6);problem.question="<div class='smaller'>";problem.question+="A fair six sided dice is rolled "+trials+" times. How many times would you expect to roll a "+number+"?";problem.answer=Math.round(trials/6);problem.question+="</div>";return problem;}
function substitution(type,negatives,v1,v2){var problem={};var choice=getRandom(0,21);var l1=letterPicker(choice);var l2=letterPicker(choice+1);var x=getRandom(2,10);var y=getRandom(1,10);var z=getRandom(2,10);if(negatives&&Math.random()<0.5){x=-x;}
if(negatives&&Math.random()<0.5){y=-y;}
var answer=0;problem.question="<div class='smaller'>If \\("+l1+" = "+v1+"\\)";if(type>4){problem.question+=" and \\("+l2+" = "+v2+"\\)";}
switch(getRandom(0,2)){case 0:problem.question+=", work out: </div><div class='smaller'>";break;case 1:problem.question+=", evaluate: </div><div class='smaller'>";break;case 2:problem.question+=", calculate: </div><div class='smaller'>";break;}
switch(type){case 0:if(Math.random()<0.5){problem.question+="\\("+fixTerm(1,l1,true)+fixTerm(x,"",false)+"\\)";}else{problem.question+="\\("+fixTerm(x,"",true)+fixTerm(1,l1,false)+"\\)";}
answer=v1+x;break;case 1:if(x<v1){problem.question+="\\("+fixTerm(1,l1,true)+fixTerm(-x,"",false)+"\\)";answer=v1-x;}else{problem.question+="\\("+fixTerm(x,"",true)+fixTerm(-1,l1,false)+"\\)";answer=x-v1;}
break;case 2:problem.question+="\\("+fixTerm(x,l1,true)+"\\)";answer=v1*x;break;case 3:if(Math.random()<0.5){problem.question+="\\("+fixTerm(y,"",true)+fixTerm(x,l1,false)+"\\)";}else{problem.question+="\\("+fixTerm(x,l1,true)+fixTerm(y,"",false)+"\\)";}
answer=v1*x+y;break;case 4:if(v1%x===0){problem.question+="\\( \\frac{"+fixTerm(1,l1,true)+"}{"+fixTerm(x,"",true)+"}\\)";answer=v1/x;}else{x*=v1;problem.question+="\\( \\frac{"+fixTerm(x,"",true)+"}{"+fixTerm(1,l1,true)+"}\\)";answer=x/v1;}
break;case 5:if(v1*x<v2*y){problem.question+="\\("+fixTerm(x,l1,true)+fixTerm(y,l2,false)+"\\)";answer=v1*x+v2*y;}else{problem.question+="\\("+fixTerm(x,l1,true)+fixTerm(-y,l2,false)+"\\)";answer=v1*x-v2*y;}
break;case 6:if(Math.random()<0.5){problem.question+="\\("+fixTerm(1,l1,true)+"&sup2;"+fixTerm(x,l2,false)+"\\)";answer=v1*v1+x*v2;}else{problem.question+="\\("+fixTerm(1,l1+l2,true)+"&sup2;"+"\\)";answer=v1*v2*v2;}
break;case 7:if(Math.random()<0.5){problem.question+="\\("+fixTerm(1,l1+l2,true)+fixTerm(x,"",false)+"\\)";answer=v1*v2+x;}else{problem.question+="\\("+fixTerm(1,x+l1+l2,true)+"\\)";answer=x*v1*v2;}
break;case 8:switch(getRandom(0,2)){case 0:problem.question+="\\("+z+"("+fixTerm(x,l1,true)+fixTerm(y,l2,false)+")\\)";answer=z*(v1*x+v2*y);break;case 1:problem.question+="\\("+z+"("+fixTerm(1,l1,true)+"&sup2;"+fixTerm(y,l2,false)+")\\)";answer=z*(v1*v1+v2*y);break;case 2:problem.question+="\\("+fixTerm(1,l1,true)+"("+fixTerm(x,l1,true)+fixTerm(y,l2,false)+")\\)";answer=v1*(x*v1+y*v2);break;}
break;}
problem.question+="</div>";problem.answer=roundError(answer);return problem;}
function unitaryMethod(cost,quantity,newQuantity){var problem={};var noun={};noun.name=itemPicker("small");noun.cost=cost;noun.quantity=quantity;noun.newQuantity=newQuantity;noun.total=toPounds(noun.cost*noun.quantity);noun.newTotal=toPounds(noun.cost*noun.newQuantity);problem.question="<div class='smaller'>"+noun.quantity+" "+noun.name+"s costs "+noun.total+".<br>";problem.question+="How much would "+noun.newQuantity+" "+noun.name+"s cost?</div>";problem.answer=noun.newTotal;problem.typedAnswer=((noun.cost*noun.newQuantity)/100).toFixed(2);return problem;}
function difference(a,b){var problem={};problem.question="<div class='smaller'>Find the difference between:<br>"+a+" and "+b+".</div>";problem.answer=roundError(Math.abs(a-b));return problem;}
function changingTemperatures(original,change){var problem={};var newTemp=roundError(original+change);var time=getRandom(1,12);if(change>0){var verb="increased";}else{verb="decreased";}
problem.question="<div class='smaller'>At "+time+" o'clock the temperature was "+original+"&deg;C. ";problem.question+="The temperature "+verb+" by "+change+"&degC.<br>What is the new temperature?</div>";problem.answer=newTemp+"&deg;C";problem.typedAnswer=newTemp;return problem;}
function polygonSides(maxPol){var problem={};var polygon=[];polygon.push({name:"a triangle",sides:3});polygon.push({name:"an equilateral triangle",sides:3});polygon.push({name:"an isosceles triangle",sides:3});polygon.push({name:"a scalene triangle",sides:3});polygon.push({name:"a quadrilateral",sides:4});polygon.push({name:"a square",sides:4});polygon.push({name:"a rectangle",sides:4});polygon.push({name:"a parallelogram",sides:4});polygon.push({name:"a rhombus",sides:4});polygon.push({name:"a trapezium",sides:4});polygon.push({name:"a kite",sides:4});polygon.push({name:"a pentagon",sides:5});polygon.push({name:"a hexagon",sides:6});polygon.push({name:"a heptagon",sides:7});polygon.push({name:"an octagon",sides:8});polygon.push({name:"a nonagon",sides:9});polygon.push({name:"a decagon",sides:10});polygon.push({name:"a hendecagon",sides:11});polygon.push({name:"a dodecagon",sides:12});polygon.push({name:"a tridecagon",sides:13});polygon.push({name:"a tetradecagon",sides:14});polygon.push({name:"a pentadecagon",sides:15});polygon.push({name:"a hexadecagon",sides:16});polygon.push({name:"a heptadecagon",sides:17});polygon.push({name:"a octadecagon",sides:18});polygon.push({name:"a enneadecagon",sides:19});polygon.push({name:"an icosagon",sides:20});polygon.push({name:"a triacontagon",sides:30});polygon.push({name:"a tetracontagon",sides:40});polygon.push({name:"a pentacontagon",sides:50});polygon.push({name:"a hexacontagon",sides:60});polygon.push({name:"a heptacontagon",sides:70});polygon.push({name:"an octacontagon",sides:80});polygon.push({name:"an enneacontagon",sides:90});polygon.push({name:"a hectogon",sides:100});polygon.push({name:"a chiliagon",sides:1000});polygon.push({name:"a myriagon",sides:10000});polygon.push({name:"a megagon",sides:1000000});temp=getRandom(0,maxPol);problem.question="<div class='smaller'>How many sides does "+polygon[temp].name+" have?</div>";problem.answer=polygon[temp].sides;return problem;}
function singleBrackets(type,negatives){var problem={};var choice=getRandom(0,21);var x=letterPicker(choice);var y=letterPicker(choice+1);var z=letterPicker(choice+2);var a=getRandom(2,10);var b=getRandom(2,10);var c=getRandom(2,10);var pow=getRandom(2,5);var pow2=getRandom(2,5);var sign=" + ";var sign2=" + ";if(toss()){sign=" - ";}
if(toss()){sign2=" - ";}
var exp="";var expansion="";if(type>5){type=5;}
if(negatives){a=-a;}
switch(type){case 0:if(toss()){exp=a+"("+x+sign+b+")";expansion=a+x+sign+(a*b);}else{exp=a+"("+b+sign+x+")";expansion=(a*b)+sign+a+x;}
break;case 1:if(toss()){exp=a+"("+c+x+sign+b+")";expansion=(a*c)+x+sign+(a*b);}else{exp=a+"("+b+sign+c+x+")";expansion=(a*b)+sign+(a*c)+x;}
break;case 2:exp=a+"("+x+sign+y+sign2+b+")";expansion=a+x+sign+a+y+sign2+(a*b);break;case 3:if(toss()){exp=x+"("+x+sign+a+")";expansion=x+"&sup2; "+sign+a+x;}else{exp=x+"("+a+sign+x+")";expansion=a+x+sign+x+"&sup2;";}
case 4:if(toss()){exp=a+x+"("+b+x+sign+c+y+")";expansion=(a*b)+x+"&sup2; "+sign+(a*c)+x+y;}else{exp=a+x+"("+c+y+sign+b+x+")";expansion=(a*c)+x+y+sign+(a*b)+x+"&sup2;";}
case 5:if(toss()){exp=a+x+"<sup>"+pow+"</sup>"+"("+b+x+"<sup>"+pow2+"</sup>"+sign+c+y+z+")";expansion=(a*b)+x+"<sup>"+(pow+pow2)+"</sup>"+sign+(a*c)+x+"<sup>"+(pow)+"</sup>"+y+z;}else{exp=a+x+"<sup>"+pow+"</sup>"+"("+c+y+z+sign+b+x+"<sup>"+pow2+"</sup>"+")";expansion=(a*c)+x+"<sup>"+(pow)+"</sup>"+y+z+sign+(a*b)+x+"<sup>"+(pow+pow2)+"</sup>";}
break;}
problem.question="Expand:<br>"+exp;problem.answer=expansion;return problem;}
function expandSimplifySingleBrackets(type,max){var problem={};var choice=getRandom(0,21);var x=letterPicker(choice);var y=letterPicker(choice+1);if(toss()){y="";}
if(toss()&&type>2){x+="&sup2;";}
if(toss()&&y!==""&&type>3){y+="&sup2;";}
var a=getRandom(2,max);var b=getRandom(2,max);var c=getRandom(2,max);var d=getRandom(2,max);var e=getRandom(2,max);var f=getRandom(2,max);var exp="";var expansion="";if(type>6){type=6;}
switch(type){case 0:exp=a+"("+x+" + "+b+") + "+c+"("+x+" + "+d+")";expansion=(a+c)+x+" + "+(a*b+c*d);break;case 1:exp=a+"("+b+x+" + "+c+") + "+d+"("+e+x+" + "+f+")";expansion=(a*b+d*e)+x+" + "+(a*c+d*f);break;case 2:exp=a+"("+x+" + "+b+y+") + "+c+"("+x+" - "+d+y+")";if(a*b<c*d){expansion=(a+c)+x+" - "+Math.abs(a*b-c*d)+y;}else{expansion=(a+c)+x+" + "+(a*b-c*d)+y;}
break;case 3:exp=a+"("+x+" - "+b+y+") + "+c+"("+x+" - "+d+y+")";expansion=(a+c)+x+" - "+(a*b+c*d)+y;break;case 4:while(a*b<=d*e){b++;}
exp=a+"("+b+x+" + "+c+y+") - "+d+"("+e+x+" + "+f+y+")";if(a*c<d*f){expansion=(a*b-d*e)+x+" - "+Math.abs(a*c-d*f)+y;}else{expansion=(a*b-d*e)+x+" + "+(a*c-d*f)+y;}
break;case 5:while(a*b<=d*e){b++;}
exp=a+"("+b+x+" + "+c+y+") - "+d+"("+e+x+" - "+f+y+")";expansion=(a*b-d*e)+x+" + "+(a*c+d*f)+y;break;case 6:while(a*b<=d*e){b++;}
exp=a+"("+b+x+" - "+c+y+") - "+d+"("+e+x+" - "+f+y+")";if(a*c<d*f){expansion=(a*b-d*e)+x+" + "+(d*f-a*c)+y;}else{expansion=(a*b-d*e)+x+" - "+Math.abs(d*f-a*c)+y;}
break;}
problem.question="Expand and simplify:<br>"+exp;problem.answer=expansion;return problem;}
function interchangingFDP(x,y,amount,type){var problem={};var givenAmount=roundError(x*amount);var newAmount=roundError(y*amount);problem.question="<div class='smaller'>";switch(type){case "random":if(toss()){problem.question+="If "+toFraction(x)+" of an amount is "+givenAmount+",<br>";problem.question+=" what is "+toPercentage(y)+"?";}else{problem.question+="If "+toPercentage(x)+" of an amount is "+givenAmount+",<br>";problem.question+=" what is "+toFraction(y)+"?";}
break;case "fraction":problem.question+="If "+toFraction(x)+" of an amount is "+givenAmount+",<br>";problem.question+=" what is "+toFraction(y)+"?";break;case "percentage":problem.question+="If "+toPercentage(x)+" of an amount is "+givenAmount+",<br>";problem.question+=" what is "+toPercentage(y)+"?";break;}
problem.question+="</div>";problem.answer=newAmount;return problem;}
function fibonacci(f0,f1,given1,given2,find){var problem={};var s=[];s[0]=f0;s[1]=f1;for(var i=2;i<Math.max(given2,find)+1;i++){s.push(roundError(s[i-1]+s[i-2]));}
problem.question="<div class='smaller'>A fibonacci sequence begins:<br>";for(var i=0;i<s.length;i++){if(i===given1||i===given2){problem.question+=s[i]+", ";}else{problem.question+="&#9634;, ";}}
problem.question+="...<br>";problem.question+="Find the "+(find+1)+ordinal(find+1)+" term.</div>";problem.answer=s[find];return problem;}
function geometricSequence(a,r,given1,given2,find){var problem={};var s=[];s[0]=a;for(var i=1;i<Math.max(given2,find)+1;i++){s.push(roundError(s[i-1]*r));}
problem.question="<div class='smaller'>A geometric sequence begins:<br>";for(var i=0;i<s.length;i++){if(i===given1||i===given2){problem.question+=s[i]+", ";}else{problem.question+="&#9634;, ";}}
problem.question+="...<br>";problem.question+="Find the "+(find+1)+ordinal(find+1)+" term.</div>";problem.answer=s[find];return problem;}
function convertingTime(from,to,x){var units=["seconds","minutes","hours","days","weeks"];var mutliplier=[1,60,60,24,7];var problem={};problem.question="Convert "+x+" "+units[from]+" to "+units[to];if(to>from){for(var i=from+1;i<=to;i++){x/=mutliplier[i];}}
if(from>to){for(var i=to+1;i<=from;i++){x*=mutliplier[i];}}
problem.answer=roundError(x)+" "+units[to];return problem;}
function gradientFromTwoPoints(x1,y1,x2,y2){var problem={};var num=y2-y1;var den=x2-x1;var gradient=num/den;var answer=gradient;if(gradient!==Math.round(gradient)){var hcf=HCF(num,den);num/=hcf;den/=hcf;if(num<0&&den<0){num*=-1;den*=-1;}
if(num>0&&den<0){num*=-1;den*=-1;}
answer="<sup>"+num+"</sup>&frasl;<sub>"+den+"</sub>";}
problem.question="<div class='smaller'>A straight line passes through the points ("+x1+", "+y1+") and ("+x2+", "+y2+").</div>";problem.question+="<div class='smaller'>Find the gradient of the line.</div>";problem.answer=answer;return problem;}
function midpointFromTwoPoints(x1,y1,x2,y2){var problem={};var ym=roundError((y2+y1)/2);var xm=roundError((x2+x1)/2);problem.question="<div class='smaller'>A line segment passes from ("+x1+", "+y1+") to ("+x2+", "+y2+").</div>";problem.question+="<div class='smaller'>Find the midpoint of the line segment.</div>";problem.answer="("+xm+", "+ym+")";return problem;}
function completingSquare(a,b,c){var problem={};problem.question="<div class='smaller'>Complete the square for:</div>";if(a!==1){problem.question+=a;}
problem.question+="x&sup2; ";if(b>0){problem.question+=" + "+b;}else if(b!==0){problem.question+=" - "+Math.abs(b);}
problem.question+="x";if(c>0){problem.question+=" + "+c;}else if(c!==0){problem.question+=" - "+Math.abs(c);}
b/=a;var xCo=b/2;var constant=c-(((b/2)*(b/2))*a);problem.answer="";if(a!==1){problem.answer=a+"(x";}else{problem.answer="(x";}
if(xCo>0){problem.answer+=" + "+xCo+")&sup2;";}else{problem.answer+=" - "+Math.abs(xCo)+")&sup2;";}
if(constant>0){problem.answer+=" + "+constant;}else{problem.answer+=" - "+Math.abs(constant);}
return problem;}
function turningPointToQuadratic(xTurn,yTurn,min){var problem={};var type=min?"minimum":"maximum";problem.question="<div class='smaller'>The "+type+" turning point of a quadratic curve is ";problem.question+="("+xTurn+", "+yTurn+").<br>";if(type==="minimum"){problem.question+="Write an equation for this in the form:<br>y = x&sup2; + ax + b.</div>";}else{problem.question+="Write an equation for this in the form:<br>y = -x&sup2; + ax + b.</div>";}
var a=(type==="minimum")?1:-1;var b=-2*xTurn*a;var c=xTurn*xTurn*a+yTurn;problem.answer="y = ";if(a===-1){problem.answer+="-";}
problem.answer+="x&sup2; ";if(b>0){problem.answer+=" + "+b;}else if(b!==0){problem.answer+=" - "+Math.abs(b);}
problem.answer+="x";if(c>0){problem.answer+=" + "+c;}else if(c!==0){problem.answer+=" - "+Math.abs(c);}
return problem;}
function factoriseExpandQuadratics(a,b,c,d,expanding){var problem={};var let=letterPicker();var exp="";var co=[];co[0]=a*c;co[1]=a*d+b*c;co[2]=b*d;if(Math.abs(co[0])>1){exp+=co[0]+let+"&sup2;";}else{if(co[0]<0){exp+="-";}
exp+=let+"&sup2;";}
if(co[1]<0){if(co[1]<-1){exp+=" - "+Math.abs(co[1])+let;}else{exp+=" - "+let;}}else{if(co[1]>1){exp+=" + "+co[1]+let;}else if(co[1]!==0){exp+=" + "+let;}}
if(co[2]<0){exp+=" - "+Math.abs(co[2]);}else{exp+=" + "+co[2];}
var fact="(";if(a<0){fact+="-";}
if(Math.abs(a)>1){fact+=Math.abs(a);}
fact+=let;if(b>0){fact+=" + "+b;}else{fact+=" - "+Math.abs(b);}
fact+=")(";if(c<0){fact+="-";}
if(Math.abs(c)>1){fact+=Math.abs(c);}
fact+=let;if(d>0){fact+=" + "+d;}else{fact+=" - "+Math.abs(d);}
fact+=")";if(!expanding){problem.question="Factorise:<br>"+exp;problem.answer=fact;}else{problem.question="Expand and simplify:<br>"+fact;problem.answer=exp;}
return problem;}
function indexLawMultiply(base,ex1,shift1,ex2,shift2){var problem={};problem.question="Simplify:<br>";var exp=Math.pow(base,shift1)+"<sup>"+(ex1)+"</sup>";exp+=" &times; ";exp+=Math.pow(base,shift2)+"<sup>"+(ex2)+"</sup>";var sol=base+"<sup>"+((ex1*shift1)+(ex2*shift2));problem.question+=exp;problem.answer=sol;return problem;}
function indexLawDivide(base,ex1,shift1,ex2,shift2){var problem={};problem.question="Simplify:<br>";var exp=Math.pow(base,shift1)+"<sup>"+(ex1)+"</sup>";exp+=" &divide; ";exp+=Math.pow(base,shift2)+"<sup>"+(ex2)+"</sup>";var sol=base+"<sup>"+((ex1*shift1)-(ex2*shift2));problem.question+=exp;problem.answer=sol;return problem;}
function indexLawPowerOfPower(base,ex1,shift1,ex2){var problem={};problem.question="Write ";var exp="("+Math.pow(base,shift1)+"<sup>"+(ex1)+"</sup>)<sup>"+ex2+"</sup>";exp+=" as a power of "+base+".";var sol=base+"<sup>"+((ex1*shift1)*ex2);problem.question+=exp;problem.answer=sol;return problem;}
function combiningRatios(max){var problem={};var seed=getRandom(0,30);var x=letterPicker(seed);var y=letterPicker(seed+1);var z=letterPicker(seed+2);var a=getRandom(1,max);var c=getRandom(1,max);do{var b=getRandom(1,max);var d=getRandom(1,max);}while(a===b||c===d);problem.question="<div class='smaller'>The ratio of "+x+" to "+y+" is "+a+" : "+b+".<br>The ratio of "+y+" to "+z+" is "+c+" : "+d+".</div>";problem.question+="<div class='smaller'>Find the ratio "+x+" : "+y+" : "+z+" in its simplest form.</div>";var hcf=HCF(HCF(a*c,b*c),b*d);problem.answer=a*c/hcf+" : "+b*c/hcf+" : "+b*d/hcf;return problem;}
function stateEquationOfCircle(xShift,yShift,radius){var problem={};var equation="\\( ";if(xShift===0){equation+="x^2 + ";}else if(xShift>0){equation+="(x - "+xShift+")^2 + ";}else{equation+="(x + "+Math.abs(xShift)+")^2 + ";}
if(yShift===0){equation+="y^2 = ";}else if(yShift>0){equation+="(y - "+yShift+")^2 = ";}else{equation+="(y + "+Math.abs(yShift)+")^2 = ";}
equation+=radius+"^2 \\)";problem.question="<div class='smaller'>A circle has centre ("+xShift+",  "+yShift+") and  radius "+radius+".</div>";problem.question+="<div class='smaller'>State the equation of the circle.</div>";problem.answer=equation;return problem;}
function orderOfOpsTimesDivide(pairs,max){var problem={};var m=[];var d=[];var seed=getRandom(1,max);var answer=seed;for(var i=0;i<pairs;i++){var x=getRandom(1,max);d.push(x);m.push(x*getRandom(2,5));answer*=m[i]/d[i];}
m.sort(()=>Math.random()-0.5);d.sort(()=>Math.random()-0.5);var data=seed;for(var i=0;i<m.length;i++){data+=" &times "+m[i]+" &divide; "+d[i];}
problem.question=data;problem.answer=answer;return problem;}
function orderOfOpsAddSubtract(pairs,max){var problem={};var a=[];var s=[];var seed=getRandom(1,max);var answer=seed;for(var i=0;i<pairs;i++){var x=getRandom(1,max);a.push(x);var x=getRandom(1,max);s.push(x);answer+=a[i];answer-=s[i];}
a.sort(()=>Math.random()-0.5);s.sort(()=>Math.random()-0.5);var data=seed;for(var i=0;i<a.length;i++){data+=" &minus; "+s[i]+" + "+a[i];}
problem.question=data;problem.answer=answer;return problem;}